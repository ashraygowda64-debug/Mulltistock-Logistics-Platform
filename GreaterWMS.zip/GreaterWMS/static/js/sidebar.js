document.addEventListener('DOMContentLoaded', function() {
    const sidebar = document.getElementById('sidebar');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const mainContent = document.querySelector('.main-content');
    const footer = document.querySelector('.footer');
    
    // Check initial sidebar state from classes
    let sidebarOpen = !sidebar.classList.contains('closed');
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', function() {
            sidebarOpen = !sidebarOpen;
            
            if (sidebarOpen) {
                sidebar.classList.remove('closed');
                if (mainContent) {
                    mainContent.classList.remove('sidebar-closed');
                    mainContent.style.left = '280px';
                }
            } else {
                sidebar.classList.add('closed');
                if (mainContent) {
                    mainContent.classList.add('sidebar-closed');
                    mainContent.style.left = '0';
                }
            }
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                if (!sidebar.contains(event.target) && !sidebarToggle.contains(event.target)) {
                    sidebarOpen = false;
                    sidebar.classList.add('closed');
                    if (mainContent) {
                        mainContent.classList.add('sidebar-closed');
                        mainContent.style.left = '0';
                    }

                }
            }
        });
    }
});