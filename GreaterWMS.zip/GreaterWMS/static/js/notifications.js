/**
 * Notifications Module
 * Handles notification dropdown, marking notifications as read
 */

/**
 * Toggle notifications dropdown visibility
 */
function toggleNotifications() {
    const dropdown = document.getElementById('notificationsDropdown');
    const icon = document.getElementById('notificationIcon');
    const isVisible = dropdown.style.display === 'block';
    dropdown.style.display = isVisible ? 'none' : 'block';
    if (!isVisible) {
        icon.classList.add('fa-shake');
        setTimeout(() => icon.classList.remove('fa-shake'), 500);
    }
}

/**
 * Mark a single notification as read
 * @param {number} id - Notification ID
 */
function markAsRead(id) {
    fetch(`/notifications/mark-read/${id}/`, {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadNotifications();
            if (typeof showAlert === 'function') {
                showAlert('Notification marked as read', 'success', 2000);
            }
        }
    })
    .catch(error => {
        console.error('Error marking notification as read:', error);
    });
}

/**
 * Mark all notifications as read
 */
function markAllRead() {
    fetch('/notifications/mark-all-read/', {
        method: 'POST',
        headers: {
            'X-CSRFToken': getCookie('csrftoken')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            loadNotifications();
            if (typeof showAlert === 'function') {
                showAlert('All notifications marked as read', 'success', 2000);
            }
        }
    })
    .catch(error => {
        console.error('Error marking all notifications as read:', error);
    });
}

/**
 * Load notifications from server
 * This function should be implemented based on your API
 */
function loadNotifications() {
    // Placeholder - implement based on your notification API
    fetch('/api/notifications/')
        .then(response => response.json())
        .then(data => {
            // Update notification UI
            updateNotificationUI(data);
        })
        .catch(error => {
            console.error('Error loading notifications:', error);
        });
}

/**
 * Update notification UI with new data
 * @param {Object} data - Notification data from API
 */
function updateNotificationUI(data) {
    // Placeholder - implement UI update logic
    const notificationsList = document.getElementById('notificationsList');
    if (notificationsList && data.notifications) {
        // Update notification count badge
        const countBadge = document.getElementById('notificationCount');
        if (countBadge) {
            const unreadCount = data.notifications.filter(n => !n.is_read).length;
            if (unreadCount > 0) {
                countBadge.textContent = unreadCount;
                countBadge.style.display = 'block';
            } else {
                countBadge.style.display = 'none';
            }
        }
    }
}

// Close notifications dropdown when clicking outside
document.addEventListener('click', function(event) {
    const dropdown = document.getElementById('notificationsDropdown');
    const notificationBtn = document.getElementById('notificationBtn');
    
    if (dropdown && notificationBtn) {
        if (!dropdown.contains(event.target) && !notificationBtn.contains(event.target)) {
            dropdown.style.display = 'none';
        }
    }
});
