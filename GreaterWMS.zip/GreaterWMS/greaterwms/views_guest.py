"""
Guest Access Views - Redesigned with Animated Landing Page
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from permissions.decorators import get_user_role


def home(request):
    """Landing page - handles guest mode entry"""
    
    # Check if user clicked "Continue as Guest"
    if request.GET.get('guest_mode') == 'true':
        request.session['guest_mode'] = True
        request.session['is_guest'] = True
        request.session.modified = True
        return redirect('/guest/dashboard/')
    
    # Otherwise, show login selection page
    return render(request, 'auth/login_selection.html')


def guest_dashboard(request):
    """
    Guest landing page with animated stat cards
    Shows: Marketplace, Auctions, Forums, About cards
    """
    # If not in guest mode yet, set it now (allows direct access)
    if not request.session.get('guest_mode', False):
        request.session['guest_mode'] = True
        request.session['is_guest'] = True
        request.session.modified = True
    
    # Redirect authenticated users
    if request.user.is_authenticated:
        return redirect('/dashboard/')
    
    # Get counts for stat cards
    try:
        from multistock.models import Listing, Auction, Forum
        marketplace_count = Listing.objects.filter(is_active=True).count()
        auction_count = Auction.objects.filter(is_active=True).count()
        forum_count = Forum.objects.count()
    except Exception as e:
        marketplace_count = 0
        auction_count = 0
        forum_count = 0
    
    return render(request, 'guest/dashboard.html', {
        'is_guest': True,
        'guest_mode_active': True,
        'stats': {
            'marketplace': marketplace_count,
            'auctions': auction_count,
            'forums': forum_count,
        }
    })


def guest_marketplace(request):
    """Guest marketplace page - beautiful design like uploaded image"""
    # If not in guest mode yet, set it now
    if not request.session.get('guest_mode', False):
        request.session['guest_mode'] = True
        request.session['is_guest'] = True
        request.session.modified = True
    
    if request.user.is_authenticated:
        return redirect('/multistock/')
    
    try:
        from multistock.models import Listing
        listings = Listing.objects.filter(is_active=True)[:20]
        total_count = Listing.objects.filter(is_active=True).count()
    except Exception as e:
        listings = []
        total_count = 0
    
    return render(request, 'guest/marketplace.html', {
        'listings': listings,
        'is_guest': True,
        'guest_mode_active': True,
        'total_count': total_count
    })


def guest_auctions(request):
    """Guest auctions page - matches uploaded image design"""
    # If not in guest mode yet, set it now
    if not request.session.get('guest_mode', False):
        request.session['guest_mode'] = True
        request.session['is_guest'] = True
        request.session.modified = True
    
    if request.user.is_authenticated:
        return redirect('/multistock/auctions/')
    
    try:
        from multistock.models import Auction
        auctions = Auction.objects.filter(is_active=True)[:20]
        total_count = Auction.objects.filter(is_active=True).count()
    except Exception as e:
        auctions = []
        total_count = 0
    
    # Categories for browse section
    categories = [
        {'name': 'Electronics', 'icon': 'fa-laptop'},
        {'name': 'Fashion', 'icon': 'fa-shirt'},
        {'name': 'Home & Garden', 'icon': 'fa-home'},
        {'name': 'Sports', 'icon': 'fa-basketball-ball'},
        {'name': 'Collectibles', 'icon': 'fa-gem'},
        {'name': 'Automotive', 'icon': 'fa-car'},
    ]
    
    return render(request, 'guest/auctions.html', {
        'auctions': auctions,
        'categories': categories,
        'is_guest': True,
        'guest_mode_active': True,
        'total_count': total_count
    })


def guest_forums(request):
    """Guest forums page - matches uploaded image design"""
    # If not in guest mode yet, set it now
    if not request.session.get('guest_mode', False):
        request.session['guest_mode'] = True
        request.session['is_guest'] = True
        request.session.modified = True
    
    if request.user.is_authenticated:
        return redirect('/multistock/forums/')
    
    try:
        from multistock.models import Forum, ForumPost
        forums = Forum.objects.all()[:10]
        recent_posts = ForumPost.objects.select_related('forum', 'author').order_by('-created_at')[:10]
    except Exception as e:
        forums = []
        recent_posts = []
    
    # Forum categories with colors
    forum_categories = [
        {
            'name': 'General Discussion',
            'icon': 'fa-comments',
            'description': 'Platform-wide chat, announcements, and casual interaction',
            'topics': 15,
            'posts': 127,
            'color': 'primary',
            'latest': 'Latest: 2h ago by John Smith'
        },
        {
            'name': 'Product Reviews',
            'icon': 'fa-star',
            'description': 'Honest feedback and user experiences',
            'topics': 12,
            'posts': 89,
            'color': 'success',
            'latest': 'Latest: 4h ago by Sarah Wilson'
        },
        {
            'name': 'Technical Support',
            'icon': 'fa-tools',
            'description': 'Get help with technical issues and troubleshooting',
            'topics': 18,
            'posts': 156,
            'color': 'warning',
            'latest': 'Latest: 1h ago by Tech Support'
        },
        {
            'name': 'Business Tips',
            'icon': 'fa-lightbulb',
            'description': 'Share strategies and business insights',
            'topics': 10,
            'posts': 74,
            'color': 'info',
            'latest': 'Latest: 3h ago by Business Pro'
        },
    ]
    
    return render(request, 'guest/forums.html', {
        'forums': forums,
        'recent_posts': recent_posts,
        'forum_categories': forum_categories,
        'is_guest': True,
        'guest_mode_active': True
    })


def guest_about(request):
    """Guest about page"""
    return render(request, 'guest/about.html', {
        'is_guest': request.session.get('guest_mode', False),
        'guest_mode_active': request.session.get('guest_mode', False)
    })


def exit_guest_mode(request):
    """Exit guest mode and return to login selection"""
    if 'guest_mode' in request.session:
        del request.session['guest_mode']
    return redirect('/')
