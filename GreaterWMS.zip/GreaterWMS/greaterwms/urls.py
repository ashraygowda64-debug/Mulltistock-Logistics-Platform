from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static
from django.shortcuts import render, redirect
from django.http import JsonResponse
from . import views, views_superadmin, views_dashboards, views_purge, views_guest
from supplier.views import supplier_management_view

urlpatterns = [
    path('admin-panel/', lambda request: render(request, 'admin/admin_panel.html'), name='admin_panel'),
    path('admin/purge/', views_purge.purge_data, name='purge_data'),
    path('admin/', admin.site.urls),
    path('', views_guest.home, name='home'),
    path('dashboard/', views_superadmin.superadmin_dashboard, name='dashboard'),
    path('dashboard/staff/', views_dashboards.staff_dashboard, name='staff_dashboard'),
    path('dashboard/customer/', views_dashboards.customer_dashboard, name='customer_dashboard'),
    path('api/dashboard-metrics/', views_superadmin.dashboard_metrics_api, name='dashboard_metrics'),
    path('api/dashboard-charts/', views_superadmin.dashboard_charts_api, name='dashboard_charts'),
    path('api/dashboard-heatmap/', views_superadmin.dashboard_heatmap_api, name='dashboard_heatmap'),
    path('api/dashboard-bubble/', views_superadmin.dashboard_bubble_api, name='dashboard_bubble'),
    path('auth/', include('auth_system.urls')),
    
    # Guest Access URLs - Animated Dashboard & Beautiful Pages
    path('guest/dashboard/', views_guest.guest_dashboard, name='guest_dashboard'),
    path('guest/marketplace/', views_guest.guest_marketplace, name='guest_marketplace'),
    path('guest/auctions/', views_guest.guest_auctions, name='guest_auctions'),
    path('guest/forums/', views_guest.guest_forums, name='guest_forums'),
    path('guest/about/', views_guest.guest_about, name='guest_about'),
    path('exit-guest-mode/', views_guest.exit_guest_mode, name='exit_guest_mode'),
    
    path('api/goods/', include('goods.urls')),
    path('products/', include('products.urls')),
    path('stock/', include('stock.urls')),
    path('api/warehouse/', include('warehouse.urls')),
    path('warehouses/', include('warehouse.urls')),
    path('api/customer/', include('customer.urls')),
    path('customers/', include('customers.urls')),
    path('api/supplier/', include('supplier.urls')),
    path('suppliers/', include('suppliers.urls')),
    path('suppliers/manage/', supplier_management_view, name='suppliers_manage_direct'),
    path('team/', include('team.urls')),
    path('multistock/', include('multistock.urls')),
    path('barcode/', include('barcode.urls')),
    path('orders/', include('orders.urls')),
    path('reports/', include('reports.urls')),
    path('pos/', include('pos.urls')),
    path('expenses/', include('expenses.urls')),
    path('inventory/', lambda request: redirect('/products/'), name='inventory_redirect'),
    path('inventory/', include('inventory.urls')),
    path('dashboard/', include('dashboard.urls')),
    path('profile/', include('profile.urls')),
    path('pages/', include('pages.urls')),
    path('messages/', include('messaging.urls')),
    path('adjustments/', include('adjustments.urls')),
    path('automation/', include('automation.urls')),
    path('quotations/', include('quotations.urls')),
    path('returns/', include('returns.urls')),
    path('transfers/', include('transfers.urls')),
    path('users/', include('users.urls')),
    path('system-settings/', include('settings.urls')),
    path('rentals/', include('rentals.urls')),
    path('subscriptions/', include('subscriptions.urls')),
    path('storage/', include('storage.urls')),
    path('lockers/', include('lockers.urls')),
    path('credit/', include('credit.urls')),
    path('coupons/', include('coupons.urls')),
    path('audit/', include('audit.urls')),
    path('gamification/', include('gamification.urls')),
    path('categories/', include('categories.urls')),
    path('billing/', include('billing.urls')),
    path('permissions/', include('permissions.urls')),
    path('analytics/', include('analytics.urls')),
    path('api/notifications/', include('notifications.urls')),
    path('cart/', include('cart.urls')),
    path('wishlist/', include('wishlist.urls')),
    path('payments/', include('payments.urls')),
    path('webhooks/', include('webhooks.urls')),
    path('support/', include('support.urls')),
    path('accounts/', include('allauth.urls')),
    # Unified pages
    path('unified-dashboard/', lambda request: render(request, 'unified_dashboard.html'), name='unified_dashboard'),
    path('system-overview/', lambda request: render(request, 'system_overview.html'), name='system_overview'),
    # Static pages
    path('verification/', lambda request: render(request, 'verification_page.html'), name='verification'),
    path('about/', lambda request: render(request, 'about.html'), name='about'),
    path('contact/', lambda request: render(request, 'contact.html'), name='contact'),
    path('careers/', lambda request: render(request, 'careers.html'), name='careers'),
    path('terms/', lambda request: render(request, 'terms.html'), name='terms'),
    path('privacy/', lambda request: render(request, 'privacy.html'), name='privacy'),
    path('help/', lambda request: redirect('/about/#faq'), name='help'),
    path('chatbot/', lambda request: render(request, 'help/chatbot.html'), name='chatbot'),
    # User pages
    path('mine/', lambda request: render(request, 'mine.html'), name='mine'),
    # path('profile/', views.profile_view, name='profile'),  # Using apps.profile.urls instead
    path('settings/', views.settings_view, name='settings'),
    path('notifications/', lambda request: render(request, 'notifications.html'), name='notifications_page'),
    # System pages
    path('system-status/', lambda request: render(request, 'system_status.html'), name='system_status'),
    path('mobile/api-docs/', lambda request: render(request, 'mobile/api_docs.html'), name='mobile_api_docs'),
    # API endpoints
    path('api/', include('api.urls')),
    path('search/', include('search.urls')),
    path('api/search/', views.search_api, name='search_api'),
    path('api/automation/', views.automation_api, name='automation_api'),
    path('api/reports/', views.reports_api, name='reports_api'),
    path('health/', lambda request: JsonResponse({'status': 'healthy'}), name='health_check'),

]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)