from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Q
from django.utils import timezone
from datetime import timedelta

@login_required
def staff_dashboard(request):
    from goods.models import ListModel as Product
    from stock.models import StockListModel, StockMovement
    from orders.models import Order
    from customer.models import ListModel as Customer
    
    today = timezone.now().date()
    week_ago = timezone.now() - timedelta(days=7)
    
    # Staff Metrics
    assigned_tasks = Order.objects.filter(status__in=['pending', 'confirmed']).count()
    completed_orders = Order.objects.filter(status='delivered', updated_at__date=today).count()
    low_stock_items = StockListModel.objects.filter(can_order_stock__lte=10, can_order_stock__gt=0).count()
    total_products = Product.objects.count()
    
    # Recent Activity
    recent_orders = Order.objects.select_related('customer_user').only(
        'order_number', 'order_type', 'status', 'total_amount', 'created_at'
    ).order_by('-created_at')[:5]
    
    recent_movements = StockMovement.objects.select_related('stock').only(
        'movement_type', 'quantity', 'reason', 'created_at'
    ).order_by('-created_at')[:5]
    
    context = {
        'user_role': 'Staff Member' if request.user.is_staff else 'Team Member',
        'assigned_tasks': assigned_tasks,
        'completed_orders': completed_orders,
        'low_stock_items': low_stock_items,
        'total_products': total_products,
        'recent_orders': recent_orders,
        'recent_movements': recent_movements,
    }
    
    return render(request, 'staff_dashboard.html', context)

@login_required
def customer_dashboard(request):
    from orders.models import Order
    from cart.models import CartItem
    from wishlist.models import WishlistItem
    from multistock.models import Listing
    
    # Customer Metrics
    my_orders = Order.objects.filter(customer_user=request.user).count()
    pending_orders = Order.objects.filter(customer_user=request.user, status__in=['pending', 'confirmed']).count()
    cart_items = CartItem.objects.filter(user=request.user).count()
    wishlist_items = WishlistItem.objects.filter(user=request.user).count()
    
    # Recent Orders
    recent_orders = Order.objects.filter(customer_user=request.user).only(
        'order_number', 'status', 'total_amount', 'created_at'
    ).order_by('-created_at')[:5]
    
    # Featured Products
    featured_products = Listing.objects.filter(is_active=True).order_by('-created_at')[:6]
    
    context = {
        'my_orders': my_orders,
        'pending_orders': pending_orders,
        'cart_items': cart_items,
        'wishlist_items': wishlist_items,
        'recent_orders': recent_orders,
        'featured_products': featured_products,
    }
    
    return render(request, 'customer_dashboard.html', context)
