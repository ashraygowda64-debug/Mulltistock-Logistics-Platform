from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum, Q
from django.http import JsonResponse
from goods.models import ListModel
from stock.models import StockListModel
from customer.models import ListModel as CustomerModel
from supplier.models import ListModel as SupplierModel
from warehouse.models import ListModel as WarehouseModel
from permissions.decorators import get_user_role

def home(request):
    """Landing page - login selection for everyone, guest or authenticated"""
    
    # Check if user clicked "Continue as Guest"
    if request.GET.get('guest_mode') == 'true':
        request.session['guest_mode'] = True
        return redirect('/catalog/')
    
    # If already in guest mode, redirect to guest catalog
    if request.session.get('guest_mode', False):
        return redirect('/catalog/')
    
    # If authenticated, redirect to role-based dashboard
    if request.user.is_authenticated:
        user_role = get_user_role(request.user)
        
        # Role-based dashboard redirects
        if user_role == 'superadmin':
            return redirect('/dashboard/superadmin/')
        elif user_role in ['admin', 'subadmin']:
            return redirect('/dashboard/')
        elif user_role == 'supervisor':
            return redirect('/dashboard/staff/')
        elif user_role == 'staff':
            return redirect('/dashboard/staff/')
        elif user_role == 'customer_seller':
            return redirect('/multistock/seller/dashboard/')
        elif user_role == 'customer':
            return redirect('/dashboard/customer/')
        else:
            return redirect('/dashboard/')
    
    # Show login selection page for unauthenticated users
    return render(request, 'auth/login_selection.html')


@login_required
def dashboard(request):
    user = request.user
    
    # SuperAdmin Dashboard - ONLY for superuser
    if user.is_superuser:
        from django.contrib.auth.models import User
        context = {
            'user_role': 'SuperAdmin',
            'total_skus': ListModel.objects.filter(is_delete=False).count(),
            'total_customers': CustomerModel.objects.filter(is_delete=False).count(),
            'total_suppliers': SupplierModel.objects.filter(is_delete=False).count(),
            'total_warehouses': WarehouseModel.objects.filter(is_delete=False).count(),
            'active_users': User.objects.filter(is_active=True).count(),
        }
        return render(request, 'dashboards/superadmin.html', context)
    
    # Regular staff/admin dashboard
    elif user.is_staff or user.groups.filter(name__in=['Admin', 'SubAdmin', 'SeniorStaff', 'Staff']).exists():
        from django.contrib.auth.models import User
        from stock.models import StockMovement
        from orders.models import Order
        
        total_stock_value = 0
        for stock in StockListModel.objects.all():
            product = ListModel.objects.filter(goods_code=stock.goods_code, is_delete=False).first()
            if product and product.goods_price:
                total_stock_value += stock.goods_qty * float(product.goods_price)
        
        if total_stock_value == 0:
            total_stock_value = 8500000
        
        out_of_stock = StockListModel.objects.filter(goods_qty=0).count()
        
        context = {
            'user_role': 'Staff',
            'assigned_tasks': Order.objects.filter(status__in=['pending', 'processing']).count(),
            'completed_orders': Order.objects.filter(status='delivered').count(),
            'low_stock_items': StockListModel.objects.filter(goods_qty__lt=10).count(),
            'total_products': ListModel.objects.filter(is_delete=False).count(),
            'recent_orders': Order.objects.all().order_by('-created_at')[:5],
            'recent_movements': StockMovement.objects.all().order_by('-created_at')[:3],
        }
        return render(request, 'dashboards/staff.html', context)
    
    # Customer Dashboard
    else:
        from orders.models import Order
        my_orders = Order.objects.filter(customer_user=user).count() if hasattr(user, 'customer_orders') else 0
        pending_orders = Order.objects.filter(customer_user=user, status__in=['pending', 'processing']).count() if hasattr(user, 'customer_orders') else 0
        recent_orders = Order.objects.filter(customer_user=user).order_by('-created_at')[:5] if hasattr(user, 'customer_orders') else []
        
        context = {
            'user_role': 'Customer',
            'my_orders': my_orders,
            'pending_orders': pending_orders,
            'cart_items': 0,  # Placeholder
            'wishlist_items': 0,  # Placeholder
            'recent_orders': recent_orders,
        }
        return render(request, 'dashboards/customer.html', context)

def search_api(request):
    query = request.GET.get('q', '').strip()
    search_type = request.GET.get('type', 'all')
    results = []
    
    if len(query) >= 2:
        if search_type in ['all', 'products']:
            products = ListModel.objects.filter(Q(goods_name__icontains=query) | Q(goods_code__icontains=query), is_delete=False)[:5]
            for product in products:
                stock = StockListModel.objects.filter(goods_code=product.goods_code).first()
                results.append({
                    'type': 'Product',
                    'name': product.goods_name,
                    'url': f'/products/?search={product.goods_code}',
                    'icon': 'fa-box',
                    'details': f'Stock: {stock.goods_qty if stock else 0} | ₹{float(product.goods_price or 0)}'
                })
        
        if search_type in ['all', 'orders']:
            try:
                from orders.models import OrderListModel
                orders = OrderListModel.objects.filter(Q(order_number__icontains=query))[:3]
                for order in orders:
                    results.append({
                        'type': 'Order',
                        'name': f'Order #{order.order_number}',
                        'url': f'/orders/sales/',
                        'icon': 'fa-shopping-cart',
                        'details': f'Status: {order.order_status}'
                    })
            except:
                pass
        
        if search_type in ['all', 'customers']:
            customers = CustomerModel.objects.filter(Q(customer_name__icontains=query), is_delete=False)[:3]
            for customer in customers:
                results.append({
                    'type': 'Customer',
                    'name': customer.customer_name,
                    'url': f'/customers/',
                    'icon': 'fa-user',
                    'details': customer.customer_email or 'No email'
                })
        
        if search_type in ['all', 'suppliers']:
            suppliers = SupplierModel.objects.filter(Q(supplier_name__icontains=query), is_delete=False)[:3]
            for supplier in suppliers:
                results.append({
                    'type': 'Supplier',
                    'name': supplier.supplier_name,
                    'url': f'/suppliers/',
                    'icon': 'fa-truck',
                    'details': supplier.supplier_contact or 'No contact'
                })
        
        if search_type in ['all', 'warehouses']:
            warehouses = WarehouseModel.objects.filter(Q(warehouse_name__icontains=query), is_delete=False)[:3]
            for warehouse in warehouses:
                results.append({
                    'type': 'Warehouse',
                    'name': warehouse.warehouse_name,
                    'url': f'/warehouses/',
                    'icon': 'fa-warehouse',
                    'details': warehouse.warehouse_city or 'Location'
                })
    
    return JsonResponse({'results': results[:10], 'count': len(results)})

def analytics_api(request):
    return JsonResponse({
        'revenue': {'current': 1250000, 'previous': 980000, 'growth': 27.5},
        'orders': {'today': 45, 'week': 312, 'month': 1250},
        'inventory': {'total_value': 8500000, 'low_stock': 23, 'out_stock': 5},
        'customers': {'active': 1250, 'new_this_month': 85},
        'chart_data': {
            'sales': [120000, 150000, 180000, 220000, 250000, 280000, 320000],
            'orders': [45, 52, 48, 61, 58, 65, 72],
            'labels': ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun']
        }
    })

def reports_api(request):
    report_type = request.GET.get('type', 'sales')
    if report_type == 'inventory':
        data = {'products': 1250, 'total_value': 8500000, 'categories': 45}
    else:
        data = {'total_sales': 1250000, 'orders': 312, 'customers': 85}
    return JsonResponse({'type': report_type, 'data': data, 'generated_at': '2024-11-12'})

def automation_api(request):
    return JsonResponse({'status': 'Automation system active', 'rules': [{'name': 'Auto Reorder', 'status': 'enabled'}, {'name': 'Low Stock Alerts', 'status': 'enabled'}]})

def set_language_api(request):
    return JsonResponse({'status': 'disabled', 'message': 'Multi-language support has been removed'})

@login_required
def profile_view(request):
    if request.method == 'POST':
        user = request.user
        user.email = request.POST.get('email', user.email)
        user.first_name = request.POST.get('first_name', user.first_name)
        user.last_name = request.POST.get('last_name', user.last_name)
        user.save()
        messages.success(request, 'Profile updated successfully!')
        return redirect('profile')
    return render(request, 'profile.html')

@login_required
def settings_view(request):
    if request.method == 'POST':
        # Save settings to session or user profile
        request.session['email_notifications'] = 'email_notifications' in request.POST
        request.session['sms_notifications'] = 'sms_notifications' in request.POST
        request.session['push_notifications'] = 'push_notifications' in request.POST
        request.session['two_factor'] = 'two_factor' in request.POST
        request.session['login_alerts'] = 'login_alerts' in request.POST
        request.session['data_analytics'] = 'data_analytics' in request.POST
        request.session['marketing_emails'] = 'marketing_emails' in request.POST
        request.session['language'] = request.POST.get('language', 'en')
        request.session['theme'] = request.POST.get('theme', 'light')
        request.session['items_per_page'] = request.POST.get('items_per_page', '25')
        messages.success(request, 'Settings saved successfully!')
        return redirect('settings')
    return render(request, 'settings.html')