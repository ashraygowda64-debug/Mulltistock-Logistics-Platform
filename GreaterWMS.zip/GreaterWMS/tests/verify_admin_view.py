#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from messaging.models import Message, Conversation
from django.contrib.auth.models import User
from django.db.models import Q, Max

print("=== SIMULATING MESSAGING HOME VIEW FOR ADMIN ===\n")

# Simulate as admin user
admin_user = User.objects.get(username='admin')
print(f"Logged in as: {admin_user.username}\n")

# Get conversations (same as messaging_home view)
conversations = admin_user.conversations.select_related('created_by').prefetch_related(
    'members'
).annotate(
    last_msg_time=Max('messages__timestamp')
).order_by('-last_msg_time')

print(f"Total Conversations for {admin_user.username}: {conversations.count()}\n")

# Calculate unread for each conversation (same as view)
conv_list = []
for conv in conversations:
    # Query unread messages
    unread = Message.objects.filter(
        conversation=conv
    ).exclude(sender=admin_user).exclude(read_by=admin_user).exclude(deleted_for=admin_user).count()
    
    # Get last message
    last_msg = Message.objects.filter(conversation=conv).order_by('-timestamp').first()
    other_user = conv.get_other_user(admin_user) if not conv.is_group else None
    
    conv_list.append({
        'conversation': conv,
        'unread': unread,
        'last_message': last_msg,
        'other_user': other_user,
        'is_pinned': conv.pinned_by.filter(id=admin_user.id).exists()
    })
    
    members = ', '.join([u.username for u in conv.members.all()])
    print(f"Conversation #{conv.id}: {conv.name}")
    print(f"  Members: {members}")
    print(f"  Is Group: {conv.is_group}")
    print(f"  Unread: {unread}")
    print(f"  Last Message: {last_msg.content[:80] if last_msg else 'None'}...")
    print(f"  Updated: {conv.updated_at}")
    print()

print("\n=== FULL MESSAGE CONTENT ===")
guest_conv = Conversation.objects.filter(name__contains='Guest Messages', members=admin_user).first()
if guest_conv:
    print(f"\nGuest Messages Conversation #{guest_conv.id}")
    messages = Message.objects.filter(conversation=guest_conv).order_by('-timestamp')
    print(f"Total Messages: {messages.count()}\n")
    for msg in messages:
        print(f"Message #{msg.id} from {msg.sender.username}:")
        print(msg.content)
        print("-" * 80)
