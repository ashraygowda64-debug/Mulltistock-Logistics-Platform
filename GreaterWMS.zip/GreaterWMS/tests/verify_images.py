#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from stock.models import StockListModel
from goods.models import ListModel

print('=== PRODUCT IMAGE VERIFICATION ===')

total_products = ListModel.objects.filter(is_delete=False).count()
products_with_images = 0

for product in ListModel.objects.filter(is_delete=False):
    stock = StockListModel.objects.filter(
        goods_code=product.goods_code,
        goods_image__isnull=False
    ).exclude(goods_image='').first()
    
    if stock:
        products_with_images += 1

print(f'Total products: {total_products}')
print(f'Products with images: {products_with_images}')
print(f'Coverage: {(products_with_images/total_products)*100:.1f}%')

if products_with_images == total_products:
    print('SUCCESS: All products now have images!')
else:
    print(f'MISSING: {total_products - products_with_images} products still need images')