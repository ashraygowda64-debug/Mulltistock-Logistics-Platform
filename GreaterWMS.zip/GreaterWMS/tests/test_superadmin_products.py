#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User

print('=== TESTING SUPERADMIN PRODUCTS ACCESS ===')

# Create test client
client = Client()

# Test without login
response = client.get('/products/')
print(f'Public access status: {response.status_code}')
print(f'Template used: products_full.html (expected for non-authenticated)')

# Login as admin (superuser)
admin_user = User.objects.get(username='admin')
client.force_login(admin_user)

# Test with superadmin login
response = client.get('/products/')
print(f'Superadmin access status: {response.status_code}')

if response.status_code == 200:
    content = response.content.decode()
    if 'productDetailModal' in content:
        print('SUCCESS: Enhanced template with modals is being used')
    elif 'Product Details' in content:
        print('SUCCESS: Enhanced template detected')
    else:
        print('WARNING: Basic template might be in use')
    
    # Check for key features
    features = [
        ('Product Detail Modal', 'productDetailModal' in content),
        ('Edit Product Modal', 'editProductModal' in content),
        ('View Product Function', 'viewProduct(' in content),
        ('Edit Product Function', 'editProduct(' in content),
        ('Image Upload', 'editImageFile' in content),
        ('Image URL Input', 'editImageUrl' in content)
    ]
    
    print('\nFeature Check:')
    for feature, present in features:
        status = 'PRESENT' if present else 'MISSING'
        print(f'  - {feature}: {status}')

print(f'\nSuperadmin user: {admin_user.username} (Staff: {admin_user.is_staff}, Super: {admin_user.is_superuser})')
print('Access /products/ as superadmin to see enhanced interface')