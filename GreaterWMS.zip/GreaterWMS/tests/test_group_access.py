#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from messaging.models import Conversation
from django.contrib.auth.models import User

print('=== TESTING GROUP ACCESS ===')

# Get admin user
admin_user = User.objects.get(username='admin')
print(f'Admin User: {admin_user.username} (Staff: {admin_user.is_staff}, Super: {admin_user.is_superuser})')

# Get all groups
groups = Conversation.objects.filter(is_group=True)
print(f'\nTotal Groups: {groups.count()}')

for group in groups:
    print(f'\n--- Group: {group.name} ---')
    print(f'Creator: {group.created_by.username}')
    print(f'Members: {group.members.count()}')
    print(f'Admins: {group.admins.count()}')
    print(f'Is admin user an admin? {group.is_admin(admin_user)}')
    print(f'Can admin view? {group.can_view(admin_user)}')
    print(f'Visibility: {group.visibility}')
    
    # List all members
    print('Members:')
    for member in group.members.all():
        is_admin = group.admins.filter(id=member.id).exists()
        print(f'  - {member.username} (Admin: {is_admin})')
    
    # List all admins
    print('Admins:')
    for admin in group.admins.all():
        print(f'  - {admin.username}')

print('\n=== GROUP SETTINGS URLs ===')
for group in groups:
    print(f'Group "{group.name}": /messages/groups/{group.id}/settings/')