#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.test import Client
from goods.models import ListModel as Product

print('=== TESTING BARCODE GENERATION FIX ===')

client = Client()
client.login(username='admin', password='admin123')

# Test barcode generation
products = Product.objects.filter(is_delete=False)[:1]
if products:
    product = products[0]
    print(f'Testing barcode for product: {product.goods_desc}')
    
    response = client.get(f'/barcode/generate/{product.id}/')
    print(f'Barcode generation status: {response.status_code}')
    
    if response.status_code == 200:
        content = response.content.decode()
        if 'Product Barcode' in content and product.goods_code in content:
            print('SUCCESS: Barcode generation working correctly')
            print(f'  - Contains product name: YES')
            print(f'  - Contains SKU: YES')
            print(f'  - Contains price: YES')
        else:
            print('WARNING: Barcode generated but content may be incomplete')
    else:
        print(f'ERROR: {response.content.decode()[:100]}')
else:
    print('No products found to test')

print('\nBARCODE GENERATION SHOULD NOW WORK!')