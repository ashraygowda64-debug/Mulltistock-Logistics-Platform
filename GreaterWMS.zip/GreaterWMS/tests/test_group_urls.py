#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from messaging.models import Conversation

print('=== TESTING GROUP SETTINGS ACCESS ===')

# Create test client
client = Client()

# Get admin user and login
admin_user = User.objects.get(username='admin')
client.force_login(admin_user)

# Get a group
group = Conversation.objects.filter(is_group=True, created_by=admin_user).first()

if group:
    print(f'Testing group: {group.name} (ID: {group.id})')
    
    # Test group settings URL
    url = f'/messages/groups/{group.id}/settings/'
    print(f'Testing URL: {url}')
    
    try:
        response = client.get(url)
        print(f'Response status: {response.status_code}')
        
        if response.status_code == 200:
            print('SUCCESS: Group settings page accessible')
        elif response.status_code == 302:
            print(f'REDIRECT: Status 302 - redirected to {response.url if hasattr(response, "url") else "unknown"}')
        elif response.status_code == 404:
            print('ERROR: URL not found - check URL patterns')
        elif response.status_code == 500:
            print('ERROR: Server error - check view implementation')
        else:
            print(f'UNEXPECTED: Status {response.status_code}')
            
    except Exception as e:
        print(f'ERROR: Exception accessing URL: {str(e)}')
        
    # Test chat URL with group settings dropdown
    chat_url = f'/messages/chat/{group.id}/'
    print(f'\nTesting chat URL: {chat_url}')
    
    try:
        response = client.get(chat_url)
        print(f'Chat response status: {response.status_code}')
        
        if response.status_code == 200:
            print('SUCCESS: Chat page accessible')
            # Check if group settings link is in the response
            if 'group_settings' in response.content.decode():
                print('SUCCESS: Group settings link found in chat page')
            else:
                print('WARNING: Group settings link not found in chat page')
        else:
            print(f'ERROR: Chat page error: {response.status_code}')
            
    except Exception as e:
        print(f'ERROR: Exception accessing chat: {str(e)}')
        
else:
    print('ERROR: No groups found for admin user')

print('\n=== URL PATTERNS CHECK ===')
from messaging.urls import urlpatterns
for pattern in urlpatterns:
    if 'settings' in str(pattern.pattern):
        print(f'Settings URL pattern: {pattern.pattern}')