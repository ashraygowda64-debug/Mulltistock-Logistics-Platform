#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from goods.models import ListModel

print('=== TESTING PRODUCT API ===')

# Create test client
client = Client()

# Login as admin
admin_user = User.objects.get(username='admin')
client.force_login(admin_user)

# Get a product to test
product = ListModel.objects.filter(is_delete=False).first()
if product:
    print(f'Testing with product: {product.goods_code} - {product.goods_desc}')
    
    # Test product detail API
    response = client.get(f'/products/api/detail/{product.id}/')
    print(f'Detail API status: {response.status_code}')
    
    if response.status_code == 200:
        data = response.json()
        print(f'Product data loaded: {data.get("goods_name", "N/A")}')
        print(f'Image URL: {data.get("goods_image", "No image")}')
    
    # Test products list API
    response = client.get('/products/api/')
    print(f'List API status: {response.status_code}')
    
    if response.status_code == 200:
        data = response.json()
        print(f'Products loaded: {len(data.get("results", []))}')
    
    print('✓ API endpoints are working')
else:
    print('❌ No products found to test')