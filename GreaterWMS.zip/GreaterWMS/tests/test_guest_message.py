#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from messaging.models import Message, Conversation
from django.contrib.auth.models import User
from django.utils import timezone
from django.db.models import Q

print('=== SIMULATING GUEST MESSAGE FROM LEO JACKSON ===')

# Create or get system user for guest messages
system_user, created = User.objects.get_or_create(
    username='system_guest_messages',
    defaults={
        'email': 'system@multistock.com',
        'first_name': 'Guest',
        'last_name': 'Messages',
        'is_active': True
    }
)
print(f'System User: {system_user.username} (Created: {created})')

# Get team members
team_users = User.objects.filter(
    Q(is_superuser=True) | Q(is_staff=True)
).distinct()

print(f'\nTeam Members Found: {team_users.count()}')
for user in team_users:
    print(f'  - {user.username}')

# Simulate message from Leo Jackson
name = "Leo Jackson"
email = "leo.jackson@example.com"
subject = "Product Inquiry"
message_text = "I would like to know more about your inventory management system."

formatted_message = f"""🔔 New Guest Message

From: {name}
Email: {email}
Subject: {subject}

Message:
{message_text}

---
This message was sent via the contact form."""

messages_sent = 0
# Send to each team member
for team_user in team_users:
    try:
        # Find existing conversation between system user and team member
        existing_conv = Conversation.objects.filter(
            is_group=False,
            members=system_user
        ).filter(
            members=team_user
        ).first()
        
        if existing_conv:
            conv = existing_conv
            print(f'\n  Using existing conversation #{conv.id} with {team_user.username}')
        else:
            # Create new conversation
            conv = Conversation.objects.create(
                name=f'Guest Messages - {team_user.username}',
                created_by=system_user,
                is_group=False
            )
            conv.members.add(system_user, team_user)
            print(f'\n  Created new conversation #{conv.id} with {team_user.username}')
        
        # Create the message
        msg = Message.objects.create(
            conversation=conv,
            sender=system_user,
            content=formatted_message
        )
        
        # Update conversation timestamp
        conv.updated_at = timezone.now()
        conv.save()
        
        print(f'  ✓ Message #{msg.id} sent successfully')
        messages_sent += 1
        
    except Exception as e:
        print(f'  ✗ Error sending to {team_user.username}: {str(e)}')

print(f'\n=== SUMMARY ===')
print(f'Messages sent: {messages_sent}')
print(f'Total Messages in DB: {Message.objects.count()}')
print(f'Total Conversations in DB: {Conversation.objects.count()}')

print('\n=== VERIFICATION ===')
print('Recent Messages:')
for msg in Message.objects.order_by('-timestamp')[:5]:
    print(f'  - Conv #{msg.conversation.id} | From: {msg.sender.username} | Preview: {msg.content[:60]}...')

print('\nConversations with system_guest_messages:')
for conv in Conversation.objects.filter(members=system_user):
    members = ', '.join([u.username for u in conv.members.all()])
    msg_count = conv.messages.count()
    print(f'  - Conv #{conv.id}: {conv.name} | Members: {members} | Messages: {msg_count}')
