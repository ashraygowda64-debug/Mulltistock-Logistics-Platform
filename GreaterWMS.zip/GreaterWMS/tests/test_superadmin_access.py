#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User

print('=== TESTING SUPERADMIN ACCESS ===')

client = Client()

# Test superadmin access
try:
    superuser = User.objects.get(username='admin')
    print(f'Superuser: {superuser.username}')
    print(f'Is superuser: {superuser.is_superuser}')
    print(f'Is staff: {superuser.is_staff}')
    print(f'Is active: {superuser.is_active}')
except:
    print('No admin user found')
    exit()

# Login and test
login_success = client.login(username='admin', password='admin123')
print(f'Login successful: {login_success}')

if login_success:
    response = client.get('/products/')
    print(f'Products page status: {response.status_code}')
    
    if response.status_code == 200:
        content = response.content.decode()
        
        # Check template features
        features = [
            ('Tab Navigation', 'nav nav-tabs' in content),
            ('Product Detail Modal', 'productDetailModal' in content),
            ('Edit Product Modal', 'editProductModal' in content),
            ('Image Upload File', 'editImageFile' in content),
            ('Image Upload URL', 'editImageUrl' in content),
            ('Multistock Badge', 'multistock-badge' in content),
            ('Barcode Generation', 'generateBarcode(' in content),
            ('View Product Function', 'viewProduct(' in content),
            ('Edit Product Function', 'editProduct(' in content)
        ]
        
        print('\nTemplate Features:')
        all_present = True
        for feature, present in features:
            status = 'YES' if present else 'NO'
            print(f'  {feature}: {status}')
            if not present:
                all_present = False
        
        if all_present:
            print('\nSUCCESS: All unified features are present')
        else:
            print('\nWARNING: Some features missing')
            
        # Check which template is being used
        if 'Products & Inventory Management' in content:
            print('Template: Unified Products & Inventory')
        elif 'enhanced_products.html' in content:
            print('Template: Enhanced Products')
        else:
            print('Template: Unknown/Legacy')
    else:
        print(f'ERROR: Page failed to load - Status {response.status_code}')
else:
    print('ERROR: Login failed')

print('\n=== TEST COMPLETE ===')