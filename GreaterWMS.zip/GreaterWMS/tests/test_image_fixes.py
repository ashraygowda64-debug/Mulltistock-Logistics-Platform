#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.test import Client
from django.contrib.auth.models import User
from goods.models import ListModel as Product

print('=== TESTING IMAGE DISPLAY FIXES ===')

# Test client
client = Client()
client.login(username='admin', password='admin123')

# Test 1: Check unified template loads
print('\n1. Testing Unified Template Load...')
response = client.get('/products/')
if response.status_code == 200:
    content = response.content.decode()
    
    # Check for image-related elements
    image_features = [
        ('Detail Image Element', 'detailProductImage' in content),
        ('Edit Image File Input', 'editImageFile' in content),
        ('Edit Image URL Input', 'editImageUrl' in content),
        ('Image Preview Element', 'editCurrentImage' in content),
        ('Add Image File Input', 'addImageFile' in content),
        ('Add Image URL Input', 'addImageUrl' in content),
        ('Image Preview Function', 'previewImage(' in content),
        ('Image Error Handling', 'onerror' in content),
        ('Initialize Image Handlers', 'initializeImageHandlers' in content)
    ]
    
    print('Image-related features in template:')
    for feature, present in image_features:
        status = 'YES' if present else 'NO'
        print(f'  {feature}: {status}')
else:
    print(f'ERROR: Template failed to load - Status {response.status_code}')

# Test 2: Check product detail API
print('\n2. Testing Product Detail API...')
products = Product.objects.filter(is_delete=False)[:1]
if products:
    product = products[0]
    response = client.get(f'/products/api/detail/{product.id}/')
    if response.status_code == 200:
        data = response.json()
        print(f'Product: {data.get("goods_name", "N/A")}')
        print(f'Image URL: {data.get("goods_image", "No image")}')
        print(f'API includes image field: {"YES" if "goods_image" in data else "NO"}')
    else:
        print(f'ERROR: Detail API failed - Status {response.status_code}')
else:
    print('WARNING: No products found to test')

# Test 3: Check template structure
print('\n3. Checking Template Structure...')
response = client.get('/products/')
if response.status_code == 200:
    content = response.content.decode()
    
    # Check modal structure
    modals = [
        ('Product Detail Modal', 'productDetailModal' in content),
        ('Edit Product Modal', 'editProductModal' in content),
        ('Add Product Modal', 'addProductModal' in content)
    ]
    
    print('Modal structure:')
    for modal, present in modals:
        status = 'YES' if present else 'NO'
        print(f'  {modal}: {status}')
    
    # Check JavaScript functions
    js_functions = [
        ('viewProduct function', 'function viewProduct(' in content),
        ('openEditModal function', 'function openEditModal(' in content),
        ('previewImage function', 'function previewImage(' in content),
        ('Error handling', '.catch(error =>' in content)
    ]
    
    print('JavaScript functions:')
    for func, present in js_functions:
        status = 'YES' if present else 'NO'
        print(f'  {func}: {status}')

print('\n=== IMAGE FIXES VERIFICATION COMPLETE ===')
print('\nFIXES APPLIED:')
print('- Enhanced image error handling in detail view')
print('- Improved image display in edit modal')
print('- Better image upload functionality')
print('- Real-time preview with error fallbacks')
print('- Proper initialization of image handlers')
print('\nIMAGE FUNCTIONALITY SHOULD NOW WORK CORRECTLY!')