"""
Test Email Configuration for MultiStock
Run: python test_email.py
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.core.mail import send_mail
from django.conf import settings

def test_email():
    print("=" * 50)
    print("MultiStock Email Configuration Test")
    print("=" * 50)
    print()
    
    # Display current configuration
    print("Current Email Settings:")
    print(f"  Backend: {settings.EMAIL_BACKEND}")
    print(f"  Host: {settings.EMAIL_HOST}")
    print(f"  Port: {settings.EMAIL_PORT}")
    print(f"  Use TLS: {settings.EMAIL_USE_TLS}")
    print(f"  User: {settings.EMAIL_HOST_USER}")
    print(f"  Password: {'*' * len(settings.EMAIL_HOST_PASSWORD) if settings.EMAIL_HOST_PASSWORD else 'NOT SET'}")
    print(f"  From Email: {settings.DEFAULT_FROM_EMAIL}")
    print()
    
    # Check if using console backend
    if 'console' in settings.EMAIL_BACKEND.lower():
        print("⚠️  WARNING: Using console backend (emails won't be sent)")
        print("   Configure .env file with EMAIL_HOST_USER and EMAIL_HOST_PASSWORD")
        print()
        return
    
    # Check if credentials are set
    if not settings.EMAIL_HOST_USER or not settings.EMAIL_HOST_PASSWORD:
        print("❌ ERROR: Email credentials not configured")
        print("   Please set EMAIL_HOST_USER and EMAIL_HOST_PASSWORD in .env file")
        print()
        return
    
    # Prompt for test email
    print("=" * 50)
    recipient = input("Enter recipient email address: ").strip()
    
    if not recipient:
        print("❌ No recipient provided. Test cancelled.")
        return
    
    print()
    print(f"Sending test email to {recipient}...")
    print()
    
    try:
        # Send test email
        result = send_mail(
            subject='MultiStock Email Test',
            message='This is a test email from MultiStock platform. If you received this, email configuration is working correctly!',
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[recipient],
            fail_silently=False,
        )
        
        if result == 1:
            print("✅ SUCCESS! Email sent successfully!")
            print(f"   Check inbox: {recipient}")
            print()
            print("Email configuration is working correctly! 🎉")
        else:
            print("❌ FAILED: Email was not sent")
            
    except Exception as e:
        print(f"❌ ERROR: {str(e)}")
        print()
        print("Common issues:")
        print("  1. Wrong email/password in .env")
        print("  2. Gmail App Password not generated")
        print("  3. 2-Factor Authentication not enabled")
        print("  4. Less secure app access blocked")
        print()
        print("Solution:")
        print("  1. Go to: https://myaccount.google.com/apppasswords")
        print("  2. Enable 2-Factor Authentication")
        print("  3. Generate App Password for 'Mail'")
        print("  4. Update EMAIL_HOST_PASSWORD in .env")
    
    print()
    print("=" * 50)

if __name__ == '__main__':
    test_email()
