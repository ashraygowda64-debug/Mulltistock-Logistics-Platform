# GreaterWMS Cleanup & Consolidation Plan

## Executive Summary
This project is a Django-based Enterprise Inventory Management System with 40+ modules. It has significant redundancy and organizational issues that reduce maintainability. This plan consolidates duplicates, organizes scripts, and creates a cleaner structure.

---

## 🔴 CRITICAL ISSUES IDENTIFIED

### 1. **Duplicate Modules** (Data Redundancy)
- **customers/** (empty - no files) vs **customer/** (full: models, views, admin, migrations)
- **suppliers/** (empty - minimal) vs **supplier/** (full: models, views, admin, migrations)
- **warehouses/** (likely empty) vs **warehouse/** (likely full)
- **stock/** (full) vs **goods/** (likely duplicates product functionality)

**Action**: Merge empties into full versions, update all imports/URLs

### 2. **Scattered Test Files** (15+ files at root)
```
test_barcode_fix.py
test_complete_functionality.py
test_email.py
test_export_functionality.py
test_group_access.py
test_group_urls.py
test_guest_message.py
test_image_fixes.py
test_multistock_badge.py
test_orders_functionality.py
test_product_api.py
test_product_functionality.py
test_product_simple.py
test_simple_verification.py
test_superadmin_access.py
test_superadmin_products.py
test_unified_navigation.py
test_unified_products.py
verify_admin_view.py
verify_and_start.bat
verify_images.py
```

**Action**: Organize into `tests/` folder by category

### 3. **Scattered Setup & Maintenance Scripts** (20+ files at root)
```
Setup:
  - setup.bat, setup_data.py, setup_demo_oauth_safe.py
  - setup_email.bat, setup_google_oauth.py, setup_google_oauth_demo.py
  - setup_multistock.bat, setup_real_google_oauth.py, setup_email.bat

Data Population:
  - create_sample_data.py, create_sample_invoices.py, create_users.py
  - populate_complete_data.py, populate_lockers.py, populate_new_features.py
  - populate_real_system.py, populate_rentals.py

Maintenance/Fixes:
  - cleanup_duplicates.bat, fix_database.bat, fix_message_schema.py
  - fix_missing_images.py, fix_orders_migration.bat, fix_product_images.py
  - fix_stock_image_column.py, quick_fix.py

Data Checks:
  - check_messages.py, check_schema.py, check_tables.py

Purge/Cleanup:
  - purge_all_data.py, START_HERE_PURGE.txt, START_HERE_PURGE.txt

Deployment:
  - start.bat, start_enhanced.bat, start_multistock.bat, start_production.bat
  - deploy.bat, run_migrations.bat, install_psutil.bat
```

**Action**: Organize into `scripts/` folder with subfolders

### 4. **Documentation Overload** (15+ status/doc files at root)
```
CLEANUP_COMPLETE.txt
IMPLEMENTATION_SUMMARY.txt
INTEGRATION_CHECKLIST.txt
OPTIMIZATION_REPORT.txt
PAGES_FIXED.txt
PURGE_QUICK_REFERENCE.txt
PURGE_SYSTEM_FLOW.txt
SETUP_INSTRUCTIONS.md
SUPERADMIN_UPGRADE_COMPLETE.txt
SYSTEM_STATUS.md
UNIFIED_PRODUCTS_INVENTORY_SYSTEM.md
START_HERE_PURGE.txt
RUN_ME_FIRST.txt
```

**Action**: Archive into `docs/` folder, keep only README.md at root

### 5. **Configuration Files Mixed In** (at root level)
```
Dockerfile, docker-compose.yml, docker-compose.prod.yml
nginx.conf, requirements.txt, requirements-production.txt
manage.py (should stay), .gitignore, .env.example
```

**Action**: Move to `config/` folder, update paths

---

## 📋 PROPOSED NEW STRUCTURE

```
GreaterWMS/
├── README.md                    # Main documentation (kept at root)
├── manage.py                    # Django entry point (stays here)
├── db.sqlite3                   # Database (generated)
│
├── config/
│   ├── Dockerfile
│   ├── docker-compose.yml
│   ├── docker-compose.prod.yml
│   ├── nginx.conf
│   ├── requirements.txt
│   ├── requirements-production.txt
│   └── .env.example
│
├── apps/                        # All Django applications (consolidated)
│   ├── customer/                # MERGED: customers + customer
│   ├── supplier/                # MERGED: suppliers + supplier
│   ├── warehouse/               # MERGED: warehouses + warehouse
│   ├── products/
│   ├── stock/
│   ├── goods/
│   ├── orders/
│   ├── billing/
│   ├── payments/
│   ├── notifications/
│   ├── auth_system/
│   ├── ... (all 40+ apps)
│   └── greaterwms/              # Main Django config
│
├── scripts/
│   ├── setup/
│   │   ├── setup_main.py        # MERGED: setup.bat + setup.py
│   │   ├── setup_oauth.py       # MERGED: setup_google_oauth.py + variations
│   │   ├── setup_email.py
│   │   ├── setup_multistock.py
│   │   └── setup_demo.py
│   ├── populate/
│   │   ├── create_sample_data.py
│   │   ├── create_users.py
│   │   ├── populate_system.py   # MERGED: populate_real_system.py + variations
│   │   └── populate_lockers.py
│   ├── maintenance/
│   │   ├── cleanup.py           # MERGED: cleanup_duplicates.bat + fix_*.py
│   │   ├── fix_database.py
│   │   ├── purge_data.py        # MERGED: purge_all_data.py
│   │   └── quick_fix.py
│   ├── deployment/
│   │   ├── start_dev.py
│   │   ├── start_production.py
│   │   ├── deploy.py
│   │   └── migrate.py
│   ├── checks/
│   │   ├── check_messages.py
│   │   ├── check_schema.py
│   │   └── check_tables.py
│   └── backup/
│       └── backup_script.py
│
├── tests/
│   ├── test_products.py         # MERGED: test_product_*.py
│   ├── test_orders.py           # MERGED: test_orders_functionality.py
│   ├── test_authentication.py   # MERGED: test_group_*.py, test_superadmin_*.py
│   ├── test_barcode.py          # MERGED: test_barcode_fix.py
│   ├── test_images.py           # MERGED: test_image_fixes.py, verify_images.py
│   ├── test_functionality.py    # MERGED: test_complete_functionality.py
│   ├── test_export.py           # MERGED: test_export_functionality.py
│   ├── test_email.py
│   ├── test_navigation.py       # MERGED: test_unified_navigation.py
│   └── conftest.py              # Shared test configuration
│
├── docs/
│   ├── SETUP_INSTRUCTIONS.md
│   ├── PURGE_SYSTEM.md          # MERGED: PURGE_*.txt files
│   ├── IMPLEMENTATION_SUMMARY.md
│   ├── SYSTEM_STATUS.md
│   ├── OPTIMIZATION_REPORT.md
│   ├── INTEGRATION_CHECKLIST.md
│   ├── SUPERADMIN_GUIDE.md      # MERGED: SUPERADMIN_UPGRADE_COMPLETE.txt
│   ├── UNIFIED_PRODUCTS.md
│   └── STATUS/
│       ├── CLEANUP_COMPLETE.txt
│       ├── PAGES_FIXED.txt
│       └── ...
│
├── static/                      # Unchanged
├── staticfiles/                 # Unchanged
├── templates/                   # Unchanged
├── media/                       # Unchanged
├── .gitignore
├── .env.example
└── LICENSE
```

---

## ✅ CONSOLIDATION RULES

### 1. **Merging Duplicate Modules**
```
BEFORE:                 AFTER:
customers/ (empty)      → DELETE
customer/ (full)        → KEEP (rename to customer/)

suppliers/ (empty)      → DELETE
supplier/ (full)        → KEEP

warehouses/ (if empty)  → DELETE
warehouse/ (if full)    → KEEP
```

**Update All References**:
- `from customers.models` → `from customer.models`
- `'customers'` in INSTALLED_APPS → `'customer'`
- URLs: `/customers/` → `/customer/`

### 2. **Test File Organization**
```
Naming Convention:
  test_products.py              (product, product_api, product_functionality)
  test_orders.py                (orders functionality)
  test_authentication.py        (superadmin, group access, group urls)
  test_barcode.py               (barcode fixes)
  test_images.py                (image fixes, verify images)
  test_functionality.py         (complete functionality test)
  test_email.py                 (email testing)
  test_navigation.py            (unified navigation, unified products)
  test_multistock.py            (multistock badge)
  test_guest_messages.py        (guest messages)
  test_export.py                (export functionality)
  
Location: tests/test_*.py
```

### 3. **Script Organization**
```
scripts/setup/          → All setup scripts (setup.py, setup_oauth.py, etc.)
scripts/populate/       → Data creation scripts
scripts/maintenance/    → Fixes, cleanup, purge operations
scripts/deployment/     → start.bat, deploy.bat, migrations
scripts/checks/         → check_*.py, verify_*.py
scripts/backup/         → backup_script.py (move from backup/)
```

### 4. **Documentation Organization**
```
Keep at root:           README.md
Move to docs/:          All *.md and *.txt files
Sub-folder: docs/STATUS/  → Archive older status files
```

### 5. **Config Organization**
```
Move to config/:
  - Dockerfile
  - docker-compose.yml
  - docker-compose.prod.yml
  - nginx.conf
  - requirements.txt
  - requirements-production.txt
  - .env.example
  
Update manage.py paths to find config files
Update Docker build commands
Update start scripts to reference new paths
```

---

## 🔧 IMPLEMENTATION STEPS

### Phase 1: Duplicate Module Consolidation
1. [ ] Check `customers/` - if empty, delete and update imports
2. [ ] Check `suppliers/` - if empty, delete and update imports
3. [ ] Check `warehouses/` - if empty, delete and update imports
4. [ ] Search and replace all imports across codebase
5. [ ] Update INSTALLED_APPS in settings.py
6. [ ] Update URL patterns in urls.py
7. [ ] Test imports and URL routing

### Phase 2: Script Organization
1. [ ] Create `scripts/` directory structure
2. [ ] Move and consolidate test files to `tests/`
3. [ ] Move setup scripts to `scripts/setup/`
4. [ ] Move data population scripts to `scripts/populate/`
5. [ ] Move maintenance scripts to `scripts/maintenance/`
6. [ ] Move deployment scripts to `scripts/deployment/`
7. [ ] Create consolidated entry points if needed
8. [ ] Update all import paths in moved scripts

### Phase 3: Documentation Organization
1. [ ] Create `docs/` directory
2. [ ] Move all .md and .txt files to docs/
3. [ ] Create consolidated documentation files (merge duplicates)
4. [ ] Create docs/STATUS/ subfolder for archive
5. [ ] Keep only README.md at root

### Phase 4: Config Organization
1. [ ] Create `config/` directory
2. [ ] Move all config files to `config/`
3. [ ] Update Dockerfile paths
4. [ ] Update docker-compose paths
5. [ ] Update manage.py settings references
6. [ ] Update start script paths

### Phase 5: Verification & Testing
1. [ ] Run migrations
2. [ ] Test all app imports
3. [ ] Test URL routing
4. [ ] Run test suite
5. [ ] Verify static file paths
6. [ ] Test Docker build
7. [ ] Create new .gitignore if needed

---

## 📊 EXPECTED IMPROVEMENTS

| Metric | Before | After | Improvement |
|--------|--------|-------|------------|
| Root-level files | 60+ | <15 | 75% reduction |
| Duplicate modules | 3+ | 0 | 100% eliminated |
| Scattered scripts | 20+ | Organized | 100% organized |
| Documentation files | 15+ | docs/ | Centralized |
| Project clarity | Low | High | Excellent |
| Maintainability | Low | High | Excellent |
| Onboarding time | High | Low | Reduced |

---

## ⚠️ IMPORTANT NOTES

1. **Backup Before Starting**: Create a git commit or backup
2. **Update Requirements**: Some paths in scripts may need adjustment
3. **Database**: No database changes needed; structure consolidation only
4. **Testing**: Test thoroughly after each phase
5. **Documentation**: Update all internal docs and comments
6. **CI/CD**: Update deployment pipeline if applicable

---

## 📝 CONSOLIDATION CHECKLIST

- [ ] Back up the project
- [ ] Create git branch for cleanup
- [ ] Remove duplicate modules
- [ ] Update all imports and settings
- [ ] Organize test files
- [ ] Organize script files
- [ ] Move config files
- [ ] Archive documentation
- [ ] Run full test suite
- [ ] Update deployment scripts
- [ ] Create git commit
- [ ] Test in production-like environment

---

**Status**: Ready to execute Phase 1
**Estimated Time**: 2-3 hours for full cleanup
**Risk Level**: Low (non-functional consolidation)
