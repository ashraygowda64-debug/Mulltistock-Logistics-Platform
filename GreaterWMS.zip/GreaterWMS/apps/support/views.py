from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from .models import Ticket, TicketReply, TicketAttachment

from permissions.decorators import require_permission

@require_permission('support', 'view')
def ticket_list(request):
    if request.user.is_staff:
        tickets = Ticket.objects.all()
    else:
        tickets = Ticket.objects.filter(created_by=request.user)
    
    status_filter = request.GET.get('status')
    priority_filter = request.GET.get('priority')
    
    if status_filter:
        tickets = tickets.filter(status=status_filter)
    if priority_filter:
        tickets = tickets.filter(priority=priority_filter)
    
    return render(request, 'support/list.html', {'tickets': tickets})

@require_permission('support', 'create')
def ticket_create(request):
    if request.method == 'POST':
        ticket = Ticket.objects.create(
            subject=request.POST['subject'],
            description=request.POST['description'],
            priority=request.POST['priority'],
            created_by=request.user
        )
        
        if request.FILES.get('attachment'):
            TicketAttachment.objects.create(
                ticket=ticket,
                file=request.FILES['attachment'],
                uploaded_by=request.user
            )
        
        messages.success(request, f'Ticket {ticket.ticket_number} created successfully!')
        return redirect('support:detail', pk=ticket.pk)
    
    return render(request, 'support/form.html')

@require_permission('support', 'view')
def ticket_detail(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    
    if not request.user.is_staff and ticket.created_by != request.user:
        messages.error(request, 'You do not have permission to view this ticket.')
        return redirect('support:list')
    
    if request.method == 'POST':
        message = request.POST.get('message')
        if message:
            TicketReply.objects.create(
                ticket=ticket,
                user=request.user,
                message=message,
                is_staff_reply=request.user.is_staff
            )
            ticket.updated_at = timezone.now()
            ticket.save()
            messages.success(request, 'Reply added successfully!')
            return redirect('support:detail', pk=pk)
    
    return render(request, 'support/detail.html', {'ticket': ticket})

@require_permission('support', 'manage')
def ticket_assign(request, pk):
    if not request.user.is_staff:
        messages.error(request, 'Only staff can assign tickets.')
        return redirect('support:list')
    
    ticket = get_object_or_404(Ticket, pk=pk)
    
    if request.method == 'POST':
        from django.contrib.auth.models import User
        assigned_to_id = request.POST.get('assigned_to')
        if assigned_to_id:
            ticket.assigned_to = User.objects.get(id=assigned_to_id)
            ticket.status = 'in_progress'
            ticket.save()
            messages.success(request, 'Ticket assigned successfully!')
        return redirect('support:detail', pk=pk)
    
    from django.contrib.auth.models import User
    staff_users = User.objects.filter(is_staff=True)
    return render(request, 'support/assign.html', {'ticket': ticket, 'staff_users': staff_users})

@require_permission('support', 'manage')
def ticket_close(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    
    if not request.user.is_staff and ticket.created_by != request.user:
        messages.error(request, 'You do not have permission to close this ticket.')
        return redirect('support:list')
    
    ticket.status = 'closed'
    ticket.resolved_at = timezone.now()
    ticket.save()
    messages.success(request, 'Ticket closed successfully!')
    return redirect('support:detail', pk=pk)

@require_permission('support', 'create')
def ticket_reopen(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)
    
    if ticket.created_by != request.user:
        messages.error(request, 'Only the ticket creator can reopen tickets.')
        return redirect('support:list')
    
    ticket.status = 'open'
    ticket.resolved_at = None
    ticket.save()
    messages.success(request, 'Ticket reopened successfully!')
    return redirect('support:detail', pk=pk)
