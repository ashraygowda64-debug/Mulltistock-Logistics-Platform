from django.urls import path
from . import views

app_name = 'support'

urlpatterns = [
    path('', views.ticket_list, name='list'),
    path('create/', views.ticket_create, name='create'),
    path('<int:pk>/', views.ticket_detail, name='detail'),
    path('<int:pk>/assign/', views.ticket_assign, name='assign'),
    path('<int:pk>/close/', views.ticket_close, name='close'),
    path('<int:pk>/reopen/', views.ticket_reopen, name='reopen'),
]
