from django.urls import path
from . import views

app_name = 'subscriptions'

urlpatterns = [
    path('plans/', views.plans_view, name='plans'),
    path('upgrade/<int:plan_id>/', views.upgrade_plan, name='upgrade'),
    path('my-subscription/', views.my_subscription, name='my_subscription'),
    path('api/usage/', views.usage_api, name='usage_api'),
]
