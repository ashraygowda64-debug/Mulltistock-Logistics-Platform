from django.contrib.auth.models import User
from .models import UserSubscription

class UsageTracker:
    @staticmethod
    def get_usage(user):
        """Get current usage for user"""
        from goods.models import ListModel as Product
        from warehouse.models import ListModel as Warehouse
        from orders.models import SalesOrder
        from django.utils import timezone
        from datetime import timedelta
        
        subscription = UserSubscription.objects.filter(user=user).first()
        if not subscription:
            return None
        
        # Count actual usage
        products_count = Product.objects.filter(openid=user.openid if hasattr(user, 'openid') else user.username, is_delete=False).count()
        warehouses_count = Warehouse.objects.filter(openid=user.openid if hasattr(user, 'openid') else user.username, is_delete=False).count()
        users_count = User.objects.filter(is_active=True).count()
        
        # Orders this month
        month_start = timezone.now().replace(day=1, hour=0, minute=0, second=0)
        orders_count = SalesOrder.objects.filter(
            customer__customer_name=user.username,
            created_at__gte=month_start
        ).count()
        
        # Storage (approximate from media files)
        import os
        storage_mb = 0
        media_path = 'media/'
        if os.path.exists(media_path):
            for root, dirs, files in os.walk(media_path):
                storage_mb += sum(os.path.getsize(os.path.join(root, f)) for f in files) / (1024 * 1024)
        
        usage = {
            'products': products_count,
            'warehouses': warehouses_count,
            'users': users_count,
            'orders': orders_count,
            'storage_mb': round(storage_mb, 2)
        }
        
        # Update subscription usage data
        subscription.usage_data = usage
        subscription.save()
        
        return usage
    
    @staticmethod
    def check_limit(user, resource_type):
        """Check if user has reached limit for resource"""
        subscription = UserSubscription.objects.filter(user=user).first()
        if not subscription:
            return False
        
        usage = UsageTracker.get_usage(user)
        plan = subscription.plan
        
        limits = {
            'products': plan.max_products,
            'warehouses': plan.max_warehouses,
            'users': plan.max_users,
            'orders': plan.max_orders_per_month,
            'storage': plan.max_storage_gb * 1024  # Convert to MB
        }
        
        if resource_type in usage and resource_type in limits:
            current = usage.get(resource_type, 0)
            if resource_type == 'storage':
                current = usage.get('storage_mb', 0)
            
            return current >= limits[resource_type]
        
        return False
    
    @staticmethod
    def can_create(user, resource_type):
        """Check if user can create new resource"""
        return not UsageTracker.check_limit(user, resource_type)
