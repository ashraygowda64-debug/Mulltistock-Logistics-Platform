from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import SubscriptionPlan, UserSubscription
from .usage_tracker import UsageTracker

def plans_view(request):
    plans = SubscriptionPlan.objects.filter(is_active=True)
    user_subscription = None
    usage = None
    
    if request.user.is_authenticated:
        user_subscription = UserSubscription.objects.filter(user=request.user).first()
        if user_subscription:
            usage = UsageTracker.get_usage(request.user)
    
    return render(request, 'subscriptions/plans.html', {
        'plans': plans,
        'user_subscription': user_subscription,
        'usage': usage
    })

@login_required
def upgrade_plan(request, plan_id):
    plan = SubscriptionPlan.objects.get(id=plan_id)
    subscription, created = UserSubscription.objects.get_or_create(user=request.user)
    subscription.plan = plan
    subscription.status = 'active'
    subscription.save()
    messages.success(request, f'Successfully upgraded to {plan.display_name}!')
    return redirect('subscriptions:plans')

@login_required
def my_subscription(request):
    subscription = UserSubscription.objects.filter(user=request.user).first()
    usage = UsageTracker.get_usage(request.user) if subscription else None
    
    # Calculate usage percentages
    usage_percent = {}
    if subscription and usage:
        plan = subscription.plan
        usage_percent = {
            'products': (usage['products'] / plan.max_products * 100) if plan.max_products else 0,
            'warehouses': (usage['warehouses'] / plan.max_warehouses * 100) if plan.max_warehouses else 0,
            'users': (usage['users'] / plan.max_users * 100) if plan.max_users else 0,
            'orders': (usage['orders'] / plan.max_orders_per_month * 100) if plan.max_orders_per_month else 0,
            'storage': (usage['storage_mb'] / (plan.max_storage_gb * 1024) * 100) if plan.max_storage_gb else 0,
        }
    
    return render(request, 'subscriptions/my_subscription.html', {
        'subscription': subscription,
        'usage': usage,
        'usage_percent': usage_percent
    })

@login_required
def usage_api(request):
    """API endpoint for real-time usage data"""
    usage = UsageTracker.get_usage(request.user)
    subscription = UserSubscription.objects.filter(user=request.user).first()
    
    response = {'usage': usage}
    if subscription:
        response['limits'] = {
            'products': subscription.plan.max_products,
            'warehouses': subscription.plan.max_warehouses,
            'users': subscription.plan.max_users,
            'orders': subscription.plan.max_orders_per_month,
            'storage_gb': subscription.plan.max_storage_gb
        }
    
    return JsonResponse(response)
