from django.contrib import admin
from .models import RentalCategory, RentalItem, RentalBooking, MaintenanceSchedule

admin.site.register(RentalCategory)
admin.site.register(RentalItem)
admin.site.register(RentalBooking)
admin.site.register(MaintenanceSchedule)
