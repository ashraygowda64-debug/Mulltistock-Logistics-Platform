from django.urls import path
from . import views, api_views

urlpatterns = [
    path('', views.rentals_list, name='rentals_list'),
    path('item/<int:item_id>/', views.rental_detail, name='rental_detail'),
    path('book/<int:item_id>/', views.rental_book, name='rental_book'),
    path('booking/<int:booking_id>/summary/', views.booking_summary, name='booking_summary'),
    path('booking/<int:booking_id>/agreement/', views.rental_agreement, name='rental_agreement'),
    path('history/', views.rental_history, name='rental_history'),
    path('maintenance/', views.maintenance_schedule, name='maintenance_schedule'),
    path('api/analytics/', api_views.analytics_data, name='rental_analytics'),
    path('api/item/<int:item_id>/status/', api_views.update_item_status, name='update_item_status'),
    path('api/item/<int:item_id>/price/', api_views.update_item_price, name='update_item_price'),
    path('api/item/<int:item_id>/duplicate/', api_views.duplicate_item, name='duplicate_item'),
    path('api/booking/create/', api_views.create_booking, name='create_booking'),
]
