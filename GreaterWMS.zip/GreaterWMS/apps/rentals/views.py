from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.utils import timezone
from datetime import timedelta
from .models import RentalItem, RentalBooking, RentalCategory, MaintenanceSchedule

from permissions.decorators import require_permission

@require_permission('rentals', 'view')
def rentals_list(request):
    category = request.GET.get('category', 'all')
    if category == 'all':
        items = RentalItem.objects.all().select_related('category')
    else:
        items = RentalItem.objects.filter(category__category_type=category).select_related('category')
    
    categories = RentalCategory.objects.all()
    context = {
        'items': items,
        'categories': categories,
        'selected_category': category,
    }
    return render(request, 'rentals/enhanced_list.html', context)

@require_permission('rentals', 'view')
def rental_detail(request, item_id):
    item = get_object_or_404(RentalItem, id=item_id)
    return render(request, 'rentals/detail.html', {'item': item})

@require_permission('rentals', 'create')
def rental_book(request, item_id):
    item = get_object_or_404(RentalItem, id=item_id)
    
    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        delivery_option = request.POST.get('delivery_option')
        delivery_address = request.POST.get('delivery_address', '')
        duration_type = request.POST.get('duration_type')
        
        # Calculate total amount
        if duration_type == 'hourly':
            total_amount = item.hourly_rate
        elif duration_type == 'daily':
            total_amount = item.daily_rate
        elif duration_type == 'weekly':
            total_amount = item.weekly_rate
        else:
            total_amount = item.monthly_rate
        
        booking = RentalBooking.objects.create(
            item=item,
            customer=request.user,
            start_date=start_date,
            end_date=end_date,
            delivery_option=delivery_option,
            delivery_address=delivery_address,
            total_amount=total_amount,
            status='confirmed'
        )
        
        item.status = 'booked'
        item.save()
        
        messages.success(request, 'Booking confirmed successfully!')
        return redirect('booking_summary', booking_id=booking.id)
    
    return render(request, 'rentals/book.html', {'item': item})

@require_permission('rentals', 'view')
def booking_summary(request, booking_id):
    booking = get_object_or_404(RentalBooking, id=booking_id)
    return render(request, 'rentals/summary.html', {'booking': booking})

@require_permission('rentals', 'view')
def rental_agreement(request, booking_id):
    booking = get_object_or_404(RentalBooking, id=booking_id)
    booking.agreement_generated = True
    booking.save()
    return render(request, 'rentals/agreement.html', {'booking': booking})

@login_required
def rental_history(request):
    bookings = RentalBooking.objects.filter(customer=request.user).order_by('-created_at')
    return render(request, 'rentals/history.html', {'bookings': bookings})

@require_permission('rentals', 'view')  # Maintenance view
def maintenance_schedule(request):
    schedules = MaintenanceSchedule.objects.all().order_by('-scheduled_date')
    return render(request, 'rentals/maintenance.html', {'schedules': schedules})
