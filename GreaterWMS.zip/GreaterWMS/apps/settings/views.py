from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.db import connection
import json

# Import RBAC decorators
from permissions.decorators import require_permission, require_role

@require_permission('settings', 'view')  # Settings view permission (SuperAdmin/Admin)
def settings_page(request):
    if request.method == 'POST':
        # Save settings
        settings_data = {
            'company_name': request.POST.get('company_name', ''),
            'email_notifications': 'email_notifications' in request.POST,
            'sms_notifications': 'sms_notifications' in request.POST,
            'low_stock_threshold': request.POST.get('low_stock_threshold', '10'),
            'currency': request.POST.get('currency', 'USD'),
            'timezone': request.POST.get('timezone', 'UTC'),
            'theme': request.POST.get('theme', 'light'),
        }
        
        with connection.cursor() as cursor:
            for key, value in settings_data.items():
                cursor.execute('''
                    INSERT OR REPLACE INTO settings_systemsetting (key, value, category, updated_at)
                    VALUES (?, ?, 'general', datetime('now'))
                ''', [key, str(value)])
        
        messages.success(request, 'Settings saved successfully!')
        return redirect('settings_page')
    
    # Load settings
    with connection.cursor() as cursor:
        cursor.execute('SELECT key, value FROM settings_systemsetting')
        settings = {row[0]: row[1] for row in cursor.fetchall()}
    
    context = {'settings': settings}
    return render(request, 'settings/settings.html', context)

@require_permission('settings', 'view')  # Settings view permission
def get_setting(request, key):
    with connection.cursor() as cursor:
        cursor.execute('SELECT value FROM settings_systemsetting WHERE key = ?', [key])
        row = cursor.fetchone()
        value = row[0] if row else None
    
    return JsonResponse({'key': key, 'value': value})

@require_permission('settings', 'edit')  # Settings edit permission (SuperAdmin/Admin)
def save_setting(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        key = data.get('key')
        value = data.get('value')
        category = data.get('category', 'general')
        
        with connection.cursor() as cursor:
            cursor.execute('''
                INSERT OR REPLACE INTO settings_systemsetting (key, value, category, updated_at)
                VALUES (?, ?, ?, datetime('now'))
            ''', [key, value, category])
        
        return JsonResponse({'status': 'success', 'message': 'Setting saved'})
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})
