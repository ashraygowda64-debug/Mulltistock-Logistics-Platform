from django.urls import path
from . import views

urlpatterns = [
    path('', views.settings_page, name='settings_page'),
    path('api/update/', views.save_setting, name='save_setting'),
    path('api/get/<str:key>/', views.get_setting, name='get_setting'),
]