from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from .models import AutomationRule, AutomationLog
from .engine import AutomationEngine
import json

@login_required
def automation_dashboard(request):
    rules = AutomationRule.objects.all()
    logs = AutomationLog.objects.all()[:20]
    
    stats = {
        'total_rules': rules.count(),
        'active_rules': rules.filter(is_active=True).count(),
        'executions_today': logs.filter(executed_at__date=timezone.now().date()).count(),
        'success_rate': logs.filter(success=True).count() / max(logs.count(), 1) * 100
    }
    
    return render(request, 'automation/dashboard.html', {
        'rules': rules,
        'logs': logs,
        'stats': stats
    })

@login_required
def automation_rules(request):
    rules = AutomationRule.objects.filter(created_by=request.user)
    return render(request, 'automation/rules.html', {'rules': rules})

@login_required
def create_rule(request):
    if request.method == 'POST':
        rule = AutomationRule.objects.create(
            name=request.POST['name'],
            trigger=request.POST['trigger'],
            action=request.POST['action'],
            conditions=json.loads(request.POST.get('conditions', '{}')),
            created_by=request.user
        )
        messages.success(request, f'Rule "{rule.name}" created!')
        return redirect('automation:dashboard')
    
    return render(request, 'automation/create_rule.html', {
        'triggers': AutomationRule.TRIGGER_CHOICES,
        'actions': AutomationRule.ACTION_CHOICES
    })

@login_required
def toggle_rule(request, rule_id):
    rule = AutomationRule.objects.get(id=rule_id)
    rule.is_active = not rule.is_active
    rule.save()
    return JsonResponse({'status': 'success', 'is_active': rule.is_active})

def automation_status_api(request):
    rules = AutomationRule.objects.all()
    return JsonResponse({
        'status': 'active',
        'rules_count': rules.count(),
        'active_rules': rules.filter(is_active=True).count()
    })