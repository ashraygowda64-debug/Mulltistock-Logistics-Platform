from django.core.mail import send_mail
from django.conf import settings
from .models import AutomationRule, AutomationLog

class AutomationEngine:
    @staticmethod
    def execute_rules(trigger, context):
        """Execute all active rules for a given trigger"""
        rules = AutomationRule.objects.filter(trigger=trigger, is_active=True)
        
        for rule in rules:
            try:
                if AutomationEngine._check_conditions(rule.conditions, context):
                    AutomationEngine._execute_action(rule, context)
                    AutomationLog.objects.create(
                        rule=rule,
                        success=True,
                        details=f"Executed for {trigger}"
                    )
            except Exception as e:
                AutomationLog.objects.create(
                    rule=rule,
                    success=False,
                    details=str(e)
                )
    
    @staticmethod
    def _check_conditions(conditions, context):
        """Check if conditions are met"""
        if not conditions:
            return True
        
        for key, value in conditions.items():
            if key not in context or context[key] != value:
                return False
        return True
    
    @staticmethod
    def _execute_action(rule, context):
        """Execute the rule action"""
        action = rule.action
        
        if action == 'assign_tax':
            AutomationEngine._auto_assign_tax(context)
        elif action == 'map_category':
            AutomationEngine._auto_map_category(context)
        elif action == 'upgrade_customer':
            AutomationEngine._upgrade_customer_level(context)
        elif action == 'notify_supplier':
            AutomationEngine._notify_supplier(context)
        elif action == 'send_email':
            AutomationEngine._send_email(context)
    
    @staticmethod
    def _auto_assign_tax(context):
        """Auto assign tax based on product category"""
        from goods.models import ListModel
        product = context.get('product')
        if product:
            tax_rates = {
                'Electronics': 18.0,
                'Food': 5.0,
                'Clothing': 12.0,
                'Books': 0.0,
            }
            category = getattr(product, 'goods_class', 'General')
            tax_rate = tax_rates.get(category, 10.0)
            
            if hasattr(product, 'goods_price'):
                product.goods_price = float(product.goods_price) * (1 + tax_rate/100)
                product.save()
    
    @staticmethod
    def _auto_map_category(context):
        """Auto map product to category based on keywords"""
        product = context.get('product')
        if product and hasattr(product, 'goods_name'):
            name = product.goods_name.lower()
            
            category_keywords = {
                'Electronics': ['phone', 'laptop', 'computer', 'tablet', 'tv'],
                'Food': ['food', 'snack', 'drink', 'beverage'],
                'Clothing': ['shirt', 'pant', 'dress', 'shoe', 'jacket'],
                'Books': ['book', 'novel', 'magazine'],
            }
            
            for category, keywords in category_keywords.items():
                if any(kw in name for kw in keywords):
                    product.goods_class = category
                    product.save()
                    break
    
    @staticmethod
    def _upgrade_customer_level(context):
        """Upgrade customer level based on order count/value"""
        from customer.models import ListModel as Customer
        from orders.models import SalesOrder
        
        customer = context.get('customer')
        if customer:
            total_orders = SalesOrder.objects.filter(customer=customer).count()
            
            if total_orders >= 50:
                customer.customer_level = 'VIP'
            elif total_orders >= 20:
                customer.customer_level = 'Gold'
            elif total_orders >= 10:
                customer.customer_level = 'Silver'
            else:
                customer.customer_level = 'Bronze'
            
            if hasattr(customer, 'save'):
                customer.save()
    
    @staticmethod
    def _notify_supplier(context):
        """Send notification to supplier"""
        from notifications.email_service import EmailService
        
        supplier = context.get('supplier')
        product = context.get('product')
        
        if supplier and hasattr(supplier, 'supplier_contact'):
            EmailService.send_email(
                to_email=supplier.supplier_contact,
                subject='Stock Alert - Action Required',
                message=f'Product {product.goods_name if product else "N/A"} is running low on stock.',
                email_type='supplier_alert'
            )
    
    @staticmethod
    def _send_email(context):
        """Send custom email"""
        from notifications.email_service import EmailService
        
        email = context.get('email')
        subject = context.get('subject', 'Notification')
        message = context.get('message', '')
        
        if email:
            EmailService.send_email(
                to_email=email,
                subject=subject,
                message=message,
                email_type='automation'
            )
