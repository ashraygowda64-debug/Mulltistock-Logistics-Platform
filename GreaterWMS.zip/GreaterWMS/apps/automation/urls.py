from django.urls import path
from . import views

app_name = 'automation'

urlpatterns = [
    path('', views.automation_dashboard, name='dashboard'),
    path('rules/', views.automation_rules, name='rules'),
    path('create/', views.create_rule, name='create_rule'),
    path('toggle/<int:rule_id>/', views.toggle_rule, name='toggle_rule'),
    path('api/status/', views.automation_status_api, name='status_api'),
]