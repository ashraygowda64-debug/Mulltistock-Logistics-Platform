from django.contrib import admin
from .models import AutomationRule, AutomationLog

@admin.register(AutomationRule)
class AutomationRuleAdmin(admin.ModelAdmin):
    list_display = ['name', 'trigger', 'action', 'is_active', 'created_at']
    list_filter = ['is_active', 'trigger', 'action']
    search_fields = ['name']

@admin.register(AutomationLog)
class AutomationLogAdmin(admin.ModelAdmin):
    list_display = ['rule', 'executed_at', 'success']
    list_filter = ['success', 'executed_at']
