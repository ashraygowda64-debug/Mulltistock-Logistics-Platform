from django.db import models
from django.contrib.auth.models import User

class AutomationRule(models.Model):
    TRIGGER_CHOICES = [
        ('stock_low', 'Stock Below Threshold'),
        ('order_created', 'Order Created'),
        ('customer_signup', 'Customer Signup'),
        ('product_added', 'Product Added'),
        ('price_change', 'Price Change'),
    ]
    
    ACTION_CHOICES = [
        ('assign_tax', 'Auto Assign Tax'),
        ('map_category', 'Auto Map Category'),
        ('upgrade_customer', 'Upgrade Customer Level'),
        ('notify_supplier', 'Notify Supplier'),
        ('send_email', 'Send Email'),
        ('create_po', 'Create Purchase Order'),
    ]
    
    name = models.CharField(max_length=200)
    trigger = models.CharField(max_length=50, choices=TRIGGER_CHOICES)
    action = models.CharField(max_length=50, choices=ACTION_CHOICES)
    conditions = models.JSONField(default=dict)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return self.name

class AutomationLog(models.Model):
    rule = models.ForeignKey(AutomationRule, on_delete=models.CASCADE)
    executed_at = models.DateTimeField(auto_now_add=True)
    success = models.BooleanField(default=True)
    details = models.TextField()
    
    class Meta:
        ordering = ['-executed_at']
