from django.shortcuts import redirect
from django.urls import reverse

class RoleBasedAccessMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Public paths that don't require authentication
        public_paths = [
            reverse('auth:login_selection'),
            reverse('auth:team_login'),
            reverse('auth:customer_login'),
            reverse('auth:register'),
            reverse('auth:logout'),
            reverse('auth:forgot_password'),
            reverse('auth:guest_access'),
            '/admin/',
            '/static/',
            '/media/',
            '/about/',
            '/contact/',
            '/help/',
            '/terms/',
            '/privacy/',
            '/careers/',
            '/guest/',
            '/multistock/marketplace/',
            '/multistock/forums/',
            '/multistock/auctions/',
            '/multistock/analytics/',
            '/products/',
            '/api/goods/',
            '/health/',
            '/messaging/guest/send/',
        ]
        
        # Check if path is public
        is_public = any(request.path.startswith(path) for path in public_paths)
        
        # Allow public access to home page
        if request.path == '/' or request.path == '/home/':
            is_public = True
        
        # FORCE login selection if session not verified (only for protected pages)
        if not is_public and not request.session.get('login_verified', False):
            # Clear any existing authentication
            if request.user.is_authenticated:
                from django.contrib.auth import logout
                logout(request)
            request.session.flush()
            return redirect('auth:login_selection')
        
        response = self.get_response(request)
        return response
