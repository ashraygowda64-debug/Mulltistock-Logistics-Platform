"""
Customers, Suppliers, and Warehouse pages with real data
"""

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.db.models import Q, Count, Sum
from django.core.paginator import Paginator

from permissions.decorators import require_permission
from customer.models import ListModel as Customer
from supplier.models import ListModel as Supplier
from warehouse.models import ListModel as Warehouse
from stock.models import StockListModel


@require_permission('customers', 'view')
def customers_page(request):
    """Customers page with real data and filters"""
    
    customers = Customer.objects.filter(is_delete=False)
    
    # Search
    search = request.GET.get('search', '')
    if search:
        customers = customers.filter(
            Q(customer_name__icontains=search) |
            Q(customer_city__icontains=search) |
            Q(customer_contact__icontains=search)
        )
    
    # Sort
    sort = request.GET.get('sort', 'name')
    if sort == 'name':
        customers = customers.order_by('customer_name')
    elif sort == 'city':
        customers = customers.order_by('customer_city')
    
    # Pagination
    paginator = Paginator(customers, 25)
    page = request.GET.get('page', 1)
    customers_page = paginator.get_page(page)
    
    context = {
        'customers': customers_page,
        'total_customers': customers.count(),
        'search': search,
    }
    
    return render(request, 'pages/customers.html', context)


@require_permission('suppliers', 'view')
def suppliers_page(request):
    """Suppliers page with real data and filters"""
    
    suppliers = Supplier.objects.filter(is_delete=False)
    
    # Search
    search = request.GET.get('search', '')
    if search:
        suppliers = suppliers.filter(
            Q(supplier_name__icontains=search) |
            Q(supplier_city__icontains=search) |
            Q(supplier_contact__icontains=search)
        )
    
    # Sort
    sort = request.GET.get('sort', 'name')
    if sort == 'name':
        suppliers = suppliers.order_by('supplier_name')
    elif sort == 'level':
        suppliers = suppliers.order_by('-supplier_level')
    
    # Pagination
    paginator = Paginator(suppliers, 25)
    page = request.GET.get('page', 1)
    suppliers_page = paginator.get_page(page)
    
    context = {
        'suppliers': suppliers_page,
        'total_suppliers': suppliers.count(),
        'search': search,
    }
    
    return render(request, 'pages/suppliers.html', context)


@require_permission('warehouses', 'view')
def warehouses_page(request):
    """Warehouses page with real data"""
    
    warehouses = Warehouse.objects.filter(is_delete=False).annotate(
        stock_count=Count('stocklistmodel'),
        total_stock=Sum('stocklistmodel__qty')
    )
    
    context = {
        'warehouses': warehouses,
        'total_warehouses': warehouses.count(),
    }
    
    return render(request, 'pages/warehouses.html', context)
