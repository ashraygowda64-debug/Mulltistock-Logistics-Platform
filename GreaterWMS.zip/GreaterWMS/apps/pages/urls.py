from django.urls import path
from . import views

app_name = 'pages'

urlpatterns = [
    path('customers/', views.customers_page, name='customers'),
    path('suppliers/', views.suppliers_page, name='suppliers'),
    path('warehouses/', views.warehouses_page, name='warehouses'),
]
