from django.urls import path
from . import views_superadmin

app_name = 'dashboard'

urlpatterns = [
    path('superadmin/', views_superadmin.superadmin_dashboard, name='superadmin_dashboard'),
    path('add-stock/', views_superadmin.add_stock_quick, name='add_stock'),
]
