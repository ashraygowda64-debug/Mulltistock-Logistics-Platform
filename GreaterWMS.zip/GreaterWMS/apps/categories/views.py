from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.core.paginator import Paginator
from .models import Category

@login_required
def category_list(request):
    categories = Category.objects.all()
    
    # Search
    search = request.GET.get('search', '')
    if search:
        categories = categories.filter(name__icontains=search) | categories.filter(code__icontains=search)
    
    # Filter by type
    cat_type = request.GET.get('type', '')
    if cat_type:
        categories = categories.filter(category_type=cat_type)
    
    # Pagination
    paginator = Paginator(categories, 20)
    page = request.GET.get('page', 1)
    categories = paginator.get_page(page)
    
    context = {
        'categories': categories,
        'category_types': Category.CATEGORY_TYPES,
        'search': search,
        'selected_type': cat_type,
    }
    return render(request, 'categories/list.html', context)

@login_required
def category_create(request):
    if request.method == 'POST':
        category = Category(
            name=request.POST['name'],
            code=request.POST['code'],
            category_type=request.POST['category_type'],
            icon=request.POST.get('icon', 'fa-folder'),
            description=request.POST.get('description', ''),
            status=request.POST.get('status', 'active'),
            created_by=request.user
        )
        category.save()
        messages.success(request, f'Category "{category.name}" created successfully!')
        return redirect('categories:list')
    
    return render(request, 'categories/form.html', {'category_types': Category.CATEGORY_TYPES})

@login_required
def category_edit(request, pk):
    category = get_object_or_404(Category, pk=pk)
    
    if request.method == 'POST':
        category.name = request.POST['name']
        category.code = request.POST['code']
        category.category_type = request.POST['category_type']
        category.icon = request.POST.get('icon', 'fa-folder')
        category.description = request.POST.get('description', '')
        category.status = request.POST.get('status', 'active')
        category.save()
        messages.success(request, f'Category "{category.name}" updated successfully!')
        return redirect('categories:list')
    
    context = {'category': category, 'category_types': Category.CATEGORY_TYPES}
    return render(request, 'categories/form.html', context)

@login_required
def category_delete(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        name = category.name
        category.delete()
        messages.success(request, f'Category "{name}" deleted successfully!')
        return redirect('categories:list')
    
    return render(request, 'categories/delete.html', {'category': category})

@login_required
def category_api(request):
    cat_type = request.GET.get('type', '')
    categories = Category.objects.filter(status='active')
    if cat_type:
        categories = categories.filter(category_type=cat_type)
    
    data = [{'id': c.id, 'name': c.name, 'code': c.code, 'icon': c.icon} for c in categories]
    return JsonResponse({'categories': data})
