from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt
from .payment_processor import PaymentProcessor
import json

@login_required
def process_payment_view(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        order_id = data.get('order_id')
        amount = data.get('amount')
        method = data.get('method')
        
        result = PaymentProcessor.process_payment(
            order_id, amount, method, request.user.id
        )
        
        return JsonResponse(result)
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@login_required
def refund_payment_view(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        transaction_id = data.get('transaction_id')
        amount = data.get('amount')
        
        result = PaymentProcessor.refund_payment(transaction_id, amount)
        return JsonResponse(result)
    
    return JsonResponse({'status': 'error', 'message': 'Invalid request'})

@login_required
def payment_history(request):
    from django.db import connection
    
    with connection.cursor() as cursor:
        cursor.execute('''
            SELECT id, order_id, amount, method, status, created_at
            FROM payments_transaction
            WHERE user_id = ?
            ORDER BY created_at DESC
            LIMIT 50
        ''', [request.user.id])
        
        columns = [col[0] for col in cursor.description]
        transactions = [dict(zip(columns, row)) for row in cursor.fetchall()]
    
    return render(request, 'payments/history.html', {'transactions': transactions})

@login_required
def payment_page(request, order_id):
    return render(request, 'payments/payment_page.html', {'order_id': order_id})

@login_required
def process_payment(request):
    return process_payment_view(request)

@csrf_exempt
def payment_webhook(request):
    return JsonResponse({'status': 'received'})

@login_required
def payment_success(request, payment_id):
    return render(request, 'payments/success.html', {'payment_id': payment_id})

@login_required
def payment_failed(request, payment_id):
    return render(request, 'payments/failed.html', {'payment_id': payment_id})
