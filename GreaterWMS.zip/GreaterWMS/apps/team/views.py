from django.shortcuts import render
from django.contrib.auth.models import User
from permissions.models import UserRole

def team_list(request):
    team_users = User.objects.filter(is_staff=True).select_related('role')
    return render(request, 'team/enhanced_team.html', {'team_users': team_users})
