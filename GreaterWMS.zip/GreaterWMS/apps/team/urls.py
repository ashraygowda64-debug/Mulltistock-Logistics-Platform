from django.urls import path
from apps.team import views

urlpatterns = [
    path('', views.team_list, name='team_list'),
    path('enhanced/', views.team_list, name='team_enhanced'),
]
