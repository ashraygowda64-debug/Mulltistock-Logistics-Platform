from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse
from django.core.paginator import Paginator
from django.template.loader import render_to_string
from .models import Invoice, InvoiceItem, Receipt, InvoiceComment
from datetime import datetime, timedelta
import io
from django.conf import settings

# Import RBAC decorators
from permissions.decorators import require_permission, require_role

@require_permission('billing', 'view')  # Billing view permission
def invoice_list(request):
    invoices = Invoice.objects.all()
    
    search = request.GET.get('search', '')
    if search:
        invoices = invoices.filter(invoice_number__icontains=search) | invoices.filter(customer_name__icontains=search)
    
    status = request.GET.get('status', '')
    if status:
        invoices = invoices.filter(status=status)
    
    paginator = Paginator(invoices, 20)
    page = request.GET.get('page', 1)
    invoices = paginator.get_page(page)
    
    context = {'invoices': invoices, 'search': search, 'selected_status': status}
    return render(request, 'billing/invoice_list.html', context)

@require_permission('billing', 'create')  # Create invoices (Admin+)
def invoice_create(request):
    if request.method == 'POST':
        invoice = Invoice(
            invoice_type=request.POST['invoice_type'],
            customer_name=request.POST['customer_name'],
            customer_email=request.POST['customer_email'],
            customer_phone=request.POST['customer_phone'],
            customer_address=request.POST['customer_address'],
            due_date=request.POST['due_date'],
            project_name=request.POST.get('project_name', ''),
            tax_rate=request.POST.get('tax_rate', 0),
            discount_amount=request.POST.get('discount_amount', 0),
            payment_method=request.POST.get('payment_method', ''),
            terms_conditions=request.POST.get('terms_conditions', ''),
            created_by=request.user
        )
        invoice.save()
        
        # Add items
        items = request.POST.getlist('item_description[]')
        quantities = request.POST.getlist('item_quantity[]')
        prices = request.POST.getlist('item_price[]')
        
        subtotal = 0
        for desc, qty, price in zip(items, quantities, prices):
            if desc and qty and price:
                item = InvoiceItem(invoice=invoice, description=desc, quantity=int(qty), price=float(price))
                item.save()
                subtotal += item.amount
        
        invoice.subtotal = subtotal
        invoice.tax_amount = (subtotal * float(invoice.tax_rate)) / 100
        invoice.grand_total = subtotal + invoice.tax_amount - float(invoice.discount_amount)
        invoice.save()
        
        messages.success(request, f'Invoice {invoice.invoice_number} created successfully!')
        return redirect('billing:invoice_detail', pk=invoice.id)
    
    return render(request, 'billing/invoice_form.html', {'invoice_types': Invoice.INVOICE_TYPES})

@require_permission('billing', 'view')  # View invoice details
def invoice_detail(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    comments = invoice.comments.all()
    receipts = invoice.receipts.all()
    context = {'invoice': invoice, 'comments': comments, 'receipts': receipts}
    return render(request, 'billing/invoice_detail.html', context)

@require_permission('billing', 'pdf')  # Generate invoice PDF
def invoice_pdf(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    template = request.GET.get('template', 'light')
    
    html = render_to_string('billing/invoice_pdf.html', {'invoice': invoice, 'template': template})
    
    try:
        from weasyprint import HTML
        pdf_file = HTML(string=html, base_url=request.build_absolute_uri()).write_pdf()
        response = HttpResponse(pdf_file, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="invoice_{invoice.invoice_number}.pdf"'
        return response
    except:
        return HttpResponse(html)

@require_permission('billing', 'create')  # Create receipts (record payments)
def receipt_create(request, invoice_id):
    invoice = get_object_or_404(Invoice, pk=invoice_id)
    
    if request.method == 'POST':
        receipt = Receipt(
            invoice=invoice,
            payment_mode=request.POST['payment_mode'],
            amount_paid=request.POST['amount_paid']
        )
        receipt.save()
        
        invoice.status = 'paid'
        invoice.save()
        
        messages.success(request, f'Receipt {receipt.receipt_number} generated!')
        return redirect('billing:receipt_detail', pk=receipt.id)
    
    return render(request, 'billing/receipt_form.html', {'invoice': invoice})

@require_permission('billing', 'view')  # View receipt details
def receipt_detail(request, pk):
    receipt = get_object_or_404(Receipt, pk=pk)
    return render(request, 'billing/receipt_detail.html', {'receipt': receipt})

@require_permission('billing', 'pdf')  # Generate receipt PDF
def receipt_pdf(request, pk):
    receipt = get_object_or_404(Receipt, pk=pk)
    html = render_to_string('billing/receipt_pdf.html', {'receipt': receipt})
    
    try:
        from weasyprint import HTML
        pdf_file = HTML(string=html, base_url=request.build_absolute_uri()).write_pdf()
        response = HttpResponse(pdf_file, content_type='application/pdf')
        response['Content-Disposition'] = f'attachment; filename="receipt_{receipt.receipt_number}.pdf"'
        return response
    except:
        return HttpResponse(html)

@require_permission('billing', 'delete')  # Delete invoices (SuperAdmin/Admin only)
def invoice_delete(request, pk):
    invoice = get_object_or_404(Invoice, pk=pk)
    invoice.delete()
    messages.success(request, 'Invoice deleted successfully!')
    return redirect('billing:invoice_list')

