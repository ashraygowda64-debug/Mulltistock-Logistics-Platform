from django.db import models
from django.contrib.auth.models import User
import secrets

class Webhook(models.Model):
    name = models.CharField(max_length=200)
    url = models.URLField()
    secret = models.CharField(max_length=100, default=secrets.token_hex)
    events = models.JSONField(default=list)
    is_active = models.BooleanField(default=True)
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.name

class WebhookLog(models.Model):
    webhook = models.ForeignKey(Webhook, on_delete=models.CASCADE, related_name='logs')
    event = models.CharField(max_length=100)
    payload = models.JSONField()
    response_code = models.IntegerField(null=True)
    response_body = models.TextField(null=True)
    success = models.BooleanField(default=False)
    retry_count = models.IntegerField(default=0)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-created_at']
