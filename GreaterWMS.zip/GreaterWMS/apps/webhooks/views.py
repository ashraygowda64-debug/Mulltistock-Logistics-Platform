from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.contrib import messages
from django.utils import timezone
from .models import Webhook, WebhookLog
from .webhook_sender import trigger_webhook
import json

@login_required
def webhook_list(request):
    webhooks = Webhook.objects.filter(created_by=request.user)
    return render(request, 'webhooks/list.html', {'webhooks': webhooks})

@login_required
def webhook_create(request):
    if request.method == 'POST':
        webhook = Webhook.objects.create(
            name=request.POST['name'],
            url=request.POST['url'],
            events=json.loads(request.POST.get('events', '[]')),
            created_by=request.user
        )
        messages.success(request, f'Webhook "{webhook.name}" created successfully!')
        return redirect('webhooks:list')
    
    events = ['order.created', 'order.updated', 'stock.low', 'product.created', 'payment.received']
    return render(request, 'webhooks/form.html', {'events': events})

@login_required
def webhook_edit(request, pk):
    webhook = get_object_or_404(Webhook, pk=pk, created_by=request.user)
    
    if request.method == 'POST':
        webhook.name = request.POST['name']
        webhook.url = request.POST['url']
        webhook.events = json.loads(request.POST.get('events', '[]'))
        webhook.is_active = 'is_active' in request.POST
        webhook.save()
        messages.success(request, 'Webhook updated successfully!')
        return redirect('webhooks:list')
    
    events = ['order.created', 'order.updated', 'stock.low', 'product.created', 'payment.received']
    return render(request, 'webhooks/form.html', {'webhook': webhook, 'events': events})

@login_required
def webhook_delete(request, pk):
    webhook = get_object_or_404(Webhook, pk=pk, created_by=request.user)
    webhook.delete()
    messages.success(request, 'Webhook deleted successfully!')
    return redirect('webhooks:list')

@login_required
def webhook_test(request, pk):
    webhook = get_object_or_404(Webhook, pk=pk, created_by=request.user)
    test_data = {'event': 'test', 'message': 'This is a test webhook', 'timestamp': str(timezone.now())}
    success = trigger_webhook('test', test_data, webhook_id=pk)
    
    if success:
        messages.success(request, 'Test webhook sent successfully!')
    else:
        messages.error(request, 'Failed to send test webhook. Check logs.')
    
    return redirect('webhooks:logs', pk=pk)

@login_required
def webhook_logs(request, pk):
    webhook = get_object_or_404(Webhook, pk=pk, created_by=request.user)
    logs = webhook.logs.all()[:50]
    return render(request, 'webhooks/logs.html', {'webhook': webhook, 'logs': logs})

@login_required
def webhook_regenerate_secret(request, pk):
    webhook = get_object_or_404(Webhook, pk=pk, created_by=request.user)
    import secrets
    webhook.secret = secrets.token_hex(32)
    webhook.save()
    messages.success(request, 'Secret regenerated successfully!')
    return redirect('webhooks:list')
