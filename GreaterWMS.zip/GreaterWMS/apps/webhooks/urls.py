from django.urls import path
from . import views

app_name = 'webhooks'

urlpatterns = [
    path('', views.webhook_list, name='list'),
    path('create/', views.webhook_create, name='create'),
    path('edit/<int:pk>/', views.webhook_edit, name='edit'),
    path('delete/<int:pk>/', views.webhook_delete, name='delete'),
    path('test/<int:pk>/', views.webhook_test, name='test'),
    path('logs/<int:pk>/', views.webhook_logs, name='logs'),
    path('regenerate-secret/<int:pk>/', views.webhook_regenerate_secret, name='regenerate_secret'),
]
