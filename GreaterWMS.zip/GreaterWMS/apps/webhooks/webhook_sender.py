import requests
import hmac
import hashlib
import json
import logging
import time
from .models import Webhook, WebhookLog

logger = logging.getLogger(__name__)

def trigger_webhook(event, data, webhook_id=None):
    """Trigger webhooks with event filtering"""
    if webhook_id:
        webhooks = Webhook.objects.filter(id=webhook_id, is_active=True)
    else:
        # Filter webhooks that have this event in their events list
        webhooks = Webhook.objects.filter(is_active=True)
        webhooks = [w for w in webhooks if event in w.events]
    
    for webhook in webhooks:
        send_webhook(webhook, event, data)

def send_webhook(webhook, event, data, retry=0):
    """Send webhook with HMAC signature validation and retry logic"""
    payload = json.dumps({
        'event': event,
        'data': data,
        'timestamp': int(time.time())
    })
    
    # Generate HMAC-SHA256 signature
    signature = hmac.new(
        webhook.secret.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()
    
    try:
        response = requests.post(
            webhook.url,
            data=payload,
            headers={
                'Content-Type': 'application/json',
                'X-Webhook-Signature': f'sha256={signature}',
                'X-Webhook-Event': event,
                'X-Webhook-ID': str(webhook.id),
                'User-Agent': 'MultiStock-Webhook/1.0'
            },
            timeout=10
        )
        
        success = 200 <= response.status_code < 300
        
        WebhookLog.objects.create(
            webhook=webhook,
            event=event,
            payload=data,
            response_code=response.status_code,
            response_body=response.text[:1000],
            success=success,
            retry_count=retry
        )
        
        logger.info(f'Webhook {webhook.name} sent: {event} - {response.status_code}')
        
        # Retry on failure
        if not success and retry < 3:
            time.sleep(2 ** retry)  # Exponential backoff
            return send_webhook(webhook, event, data, retry + 1)
        
        return success
        
    except Exception as e:
        WebhookLog.objects.create(
            webhook=webhook,
            event=event,
            payload=data,
            response_body=str(e)[:1000],
            success=False,
            retry_count=retry
        )
        logger.error(f'Webhook {webhook.name} failed: {str(e)}')
        
        # Retry with exponential backoff
        if retry < 3:
            time.sleep(2 ** retry)
            return send_webhook(webhook, event, data, retry + 1)
        
        return False

def validate_webhook_signature(payload, signature, secret):
    """Validate incoming webhook signature"""
    expected_signature = hmac.new(
        secret.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()
    
    # Remove 'sha256=' prefix if present
    if signature.startswith('sha256='):
        signature = signature[7:]
    
    return hmac.compare_digest(expected_signature, signature)
