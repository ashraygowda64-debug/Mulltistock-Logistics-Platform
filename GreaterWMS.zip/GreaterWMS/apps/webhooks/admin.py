from django.contrib import admin
from .models import Webhook, WebhookLog

@admin.register(Webhook)
class WebhookAdmin(admin.ModelAdmin):
    list_display = ['name', 'url', 'is_active', 'created_by', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['name', 'url']

@admin.register(WebhookLog)
class WebhookLogAdmin(admin.ModelAdmin):
    list_display = ['webhook', 'event', 'success', 'response_code', 'retry_count', 'created_at']
    list_filter = ['success', 'event', 'created_at']
    search_fields = ['event', 'webhook__name']
