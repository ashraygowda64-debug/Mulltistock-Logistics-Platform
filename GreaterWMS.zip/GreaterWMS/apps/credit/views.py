from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import CreditProfile, CreditTransaction

@login_required
def credit_dashboard(request):
    profiles = CreditProfile.objects.select_related('customer').all()
    total_credit = sum(p.credit_limit for p in profiles)
    total_used = sum(p.used_credit for p in profiles)
    total_overdue = sum(p.overdue_amount for p in profiles)
    
    return render(request, 'credit/dashboard.html', {
        'profiles': profiles,
        'total_credit': total_credit,
        'total_used': total_used,
        'total_overdue': total_overdue,
    })

@login_required
def credit_detail(request, profile_id):
    profile = get_object_or_404(CreditProfile, id=profile_id)
    transactions = profile.transactions.all()[:20]
    return render(request, 'credit/detail.html', {
        'profile': profile,
        'transactions': transactions
    })
