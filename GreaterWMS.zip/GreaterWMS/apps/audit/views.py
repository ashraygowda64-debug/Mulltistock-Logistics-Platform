from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import AuditLog

from permissions.decorators import require_permission

@require_permission('audit', 'view')
def audit_logs(request):
    logs = AuditLog.objects.select_related('user').all()[:100]
    action_type = request.GET.get('action_type')
    user_id = request.GET.get('user')
    
    if action_type:
        logs = logs.filter(action_type=action_type)
    if user_id:
        logs = logs.filter(user_id=user_id)
    
    return render(request, 'audit/logs.html', {'logs': logs})
