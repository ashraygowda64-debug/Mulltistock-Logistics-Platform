from django.contrib import admin
from .models import Marketplace, Listing, Forum, ForumPost, Analytics, Auction, Bid

@admin.register(Marketplace)
class MarketplaceAdmin(admin.ModelAdmin):
    list_display = ['name', 'owner', 'is_active', 'created_at']
    list_filter = ['is_active']
    search_fields = ['name']

@admin.register(Listing)
class ListingAdmin(admin.ModelAdmin):
    list_display = ['title', 'price', 'quantity', 'seller', 'is_active']
    list_filter = ['is_active', 'marketplace']
    search_fields = ['title', 'product_code']

@admin.register(Forum)
class ForumAdmin(admin.ModelAdmin):
    list_display = ['title', 'creator', 'created_at']
    search_fields = ['title']

@admin.register(ForumPost)
class ForumPostAdmin(admin.ModelAdmin):
    list_display = ['forum', 'author', 'created_at']
    list_filter = ['forum']

@admin.register(Analytics)
class AnalyticsAdmin(admin.ModelAdmin):
    list_display = ['user', 'metric_name', 'metric_value', 'date_recorded']
    list_filter = ['metric_name']

@admin.register(Auction)
class AuctionAdmin(admin.ModelAdmin):
    list_display = ['title', 'starting_price', 'current_price', 'end_time', 'is_active']
    list_filter = ['is_active']

@admin.register(Bid)
class BidAdmin(admin.ModelAdmin):
    list_display = ['auction', 'bidder', 'amount', 'created_at']