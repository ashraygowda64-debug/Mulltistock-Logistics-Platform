"""
Payment Integration for MultiStock Marketplace
Supports multiple payment gateways: Stripe, PayPal, Razorpay
"""

from decimal import Decimal
from django.conf import settings
import logging

logger = logging.getLogger(__name__)


class PaymentGateway:
    """
    Unified payment gateway interface
    """
    
    def __init__(self, gateway_type='stripe'):
        self.gateway_type = gateway_type
        self.initialize_gateway()
    
    def initialize_gateway(self):
        """Initialize the selected payment gateway"""
        if self.gateway_type == 'stripe':
            self._init_stripe()
        elif self.gateway_type == 'paypal':
            self._init_paypal()
        elif self.gateway_type == 'razorpay':
            self._init_razorpay()
    
    def _init_stripe(self):
        """Initialize Stripe"""
        try:
            import stripe
            stripe.api_key = getattr(settings, 'STRIPE_SECRET_KEY', '')
            self.stripe = stripe
            logger.info("Stripe initialized")
        except ImportError:
            logger.error("Stripe library not installed. Run: pip install stripe")
    
    def _init_paypal(self):
        """Initialize PayPal"""
        try:
            import paypalrestsdk
            paypalrestsdk.configure({
                "mode": getattr(settings, 'PAYPAL_MODE', 'sandbox'),
                "client_id": getattr(settings, 'PAYPAL_CLIENT_ID', ''),
                "client_secret": getattr(settings, 'PAYPAL_CLIENT_SECRET', '')
            })
            self.paypal = paypalrestsdk
            logger.info("PayPal initialized")
        except ImportError:
            logger.error("PayPal SDK not installed. Run: pip install paypalrestsdk")
    
    def _init_razorpay(self):
        """Initialize Razorpay"""
        try:
            import razorpay
            self.razorpay_client = razorpay.Client(
                auth=(
                    getattr(settings, 'RAZORPAY_KEY_ID', ''),
                    getattr(settings, 'RAZORPAY_KEY_SECRET', '')
                )
            )
            logger.info("Razorpay initialized")
        except ImportError:
            logger.error("Razorpay library not installed. Run: pip install razorpay")
    
    # ==================== LISTING FEE PAYMENT ====================
    
    def charge_listing_fee(self, user, listing, amount):
        """
        Charge listing fee when creating a new listing
        
        Args:
            user: User object
            listing: UnifiedListing object
            amount: Decimal amount to charge
        
        Returns:
            dict: Payment result with success status and transaction_id
        """
        try:
            if self.gateway_type == 'stripe':
                return self._stripe_charge(user, amount, f"Listing fee for: {listing.title}")
            elif self.gateway_type == 'paypal':
                return self._paypal_charge(user, amount, f"Listing fee for: {listing.title}")
            elif self.gateway_type == 'razorpay':
                return self._razorpay_charge(user, amount, f"Listing fee for: {listing.title}")
            else:
                return {'success': False, 'error': 'Invalid gateway'}
        except Exception as e:
            logger.error(f"Payment failed: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    def _stripe_charge(self, user, amount, description):
        """Charge via Stripe"""
        try:
            charge = self.stripe.Charge.create(
                amount=int(amount * 100),  # Stripe uses cents
                currency='usd',
                description=description,
                source='tok_visa',  # In production, use real payment method
                metadata={'user_id': user.id}
            )
            return {
                'success': True,
                'transaction_id': charge.id,
                'amount': amount,
                'gateway': 'stripe'
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _paypal_charge(self, user, amount, description):
        """Charge via PayPal"""
        try:
            payment = self.paypal.Payment({
                "intent": "sale",
                "payer": {"payment_method": "paypal"},
                "transactions": [{
                    "amount": {
                        "total": str(amount),
                        "currency": "USD"
                    },
                    "description": description
                }],
                "redirect_urls": {
                    "return_url": "http://localhost:8000/payment/success/",
                    "cancel_url": "http://localhost:8000/payment/cancel/"
                }
            })
            
            if payment.create():
                return {
                    'success': True,
                    'transaction_id': payment.id,
                    'approval_url': payment.links[1].href
                }
            return {'success': False, 'error': payment.error}
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    def _razorpay_charge(self, user, amount, description):
        """Charge via Razorpay"""
        try:
            order = self.razorpay_client.order.create({
                "amount": int(amount * 100),  # Razorpay uses paise
                "currency": "INR",
                "notes": {"description": description, "user_id": user.id}
            })
            return {
                'success': True,
                'order_id': order['id'],
                'amount': amount,
                'gateway': 'razorpay'
            }
        except Exception as e:
            return {'success': False, 'error': str(e)}
    
    # ==================== TRANSACTION FEE ====================
    
    def process_transaction_fee(self, transaction):
        """
        Calculate and deduct platform fee from transaction
        
        Args:
            transaction: Transaction object
        
        Returns:
            dict: Fee breakdown
        """
        # Calculate platform fee (10% for customer sellers, 5% for suppliers)
        if transaction.listing.source_type == 'customer_seller':
            fee_percentage = Decimal('0.10')
        elif transaction.listing.source_type == 'supplier':
            fee_percentage = Decimal('0.05')
        else:
            fee_percentage = Decimal('0.00')
        
        platform_fee = transaction.amount * fee_percentage
        seller_earnings = transaction.amount - platform_fee
        
        return {
            'amount': transaction.amount,
            'platform_fee': platform_fee,
            'seller_earnings': seller_earnings,
            'fee_percentage': float(fee_percentage * 100)
        }
    
    # ==================== SELLER PAYOUT ====================
    
    def process_payout(self, seller_profile, amount, payment_method='bank_transfer'):
        """
        Process payout to seller
        
        Args:
            seller_profile: CustomerSellerProfile object
            amount: Decimal amount to payout
            payment_method: str ('bank_transfer', 'paypal', 'stripe')
        
        Returns:
            dict: Payout result
        """
        try:
            if amount > seller_profile.pending_earnings:
                return {'success': False, 'error': 'Insufficient balance'}
            
            # Simulate payout (in production, integrate with actual payment gateway)
            logger.info(f"Processing payout of ${amount} to {seller_profile.user.username}")
            
            # Update seller profile
            seller_profile.pending_earnings -= amount
            seller_profile.withdrawn_earnings += amount
            seller_profile.save()
            
            return {
                'success': True,
                'amount': amount,
                'method': payment_method,
                'status': 'processing'
            }
        except Exception as e:
            logger.error(f"Payout failed: {str(e)}")
            return {'success': False, 'error': str(e)}


# Helper functions
def calculate_fees(amount, source_type):
    """Calculate listing and transaction fees"""
    listing_fee = Decimal('2.00')  # Flat listing fee
    
    if source_type == 'customer_seller':
        transaction_fee_percent = Decimal('0.10')
    elif source_type == 'supplier':
        transaction_fee_percent = Decimal('0.05')
    else:
        transaction_fee_percent = Decimal('0.00')
    
    transaction_fee = amount * transaction_fee_percent
    
    return {
        'listing_fee': listing_fee,
        'transaction_fee': transaction_fee,
        'transaction_fee_percent': float(transaction_fee_percent * 100),
        'total_fees': listing_fee + transaction_fee
    }
