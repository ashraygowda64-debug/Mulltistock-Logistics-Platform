from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.db.models import Sum, Count, Q
from decimal import Decimal

from permissions.decorators import require_permission, require_role, get_user_role
from .models_marketplace import (
    Badge, CustomerSellerProfile, UnifiedListing, 
    ListingFee, Transaction
)
from .email_service import EmailService

# ==================== CUSTOMER SELLER REGISTRATION ====================

@login_required
def become_seller(request):
    """Customer registration to become a marketplace seller"""
    
    # Check if user already has a seller profile
    if hasattr(request.user, 'seller_profile'):
        messages.info(request, 'You are already registered as a seller!')
        return redirect('multistock:seller_dashboard')
    
    if request.method == 'POST':
        business_name = request.POST.get('business_name', '')
        business_description = request.POST.get('business_description', '')
        
        # Get or create Customer Seller badge
        customer_seller_badge, _ = Badge.objects.get_or_create(
            badge_type='customer_seller',
            defaults={
                'display_name': 'Customer Seller',
                'color': '#3498db',  # Blue
                'icon': 'fa-store',
                'description': 'Verified Customer Seller'
            }
        )
        
        # Create seller profile
        seller_profile = CustomerSellerProfile.objects.create(
            user=request.user,
            badge=customer_seller_badge,
            business_name=business_name,
            business_description=business_description,
            is_verified=False  # Requires admin approval
        )
        
        # Update user role to customer_seller
        from permissions.models import UserRole
        user_role, created = UserRole.objects.get_or_create(user=request.user)
        user_role.role = 'customer_seller'
        user_role.save()
        
        # Send welcome email
        EmailService.send_seller_welcome(request.user, seller_profile)
        
        messages.success(request, 'Congratulations! Your seller account has been created. Check your email for next steps.')
        return redirect('multistock:seller_dashboard')
    
    return render(request, 'multistock/become_seller.html')


# ==================== CUSTOMER SELLER DASHBOARD ====================

@require_role('customer_seller', 'admin', 'superadmin')
def seller_dashboard(request):
    """Main dashboard for customer sellers"""
    
    if not hasattr(request.user, 'seller_profile'):
        messages.error(request, 'You need to register as a seller first.')
        return redirect('multistock:become_seller')
    
    seller_profile = request.user.seller_profile
    
    # Get seller's listings across all modules
    my_listings = UnifiedListing.objects.filter(
        owner_user=request.user,
        source_type='customer_seller'
    )
    
    # Statistics
    stats = {
        'total_listings': my_listings.count(),
        'active_listings': my_listings.filter(status='active').count(),
        'pending_approval': my_listings.filter(status='pending').count(),
        'total_sales': seller_profile.total_sales,
        'lifetime_earnings': seller_profile.lifetime_earnings,
        'pending_earnings': seller_profile.pending_earnings,
        'rating': seller_profile.rating,
        'total_reviews': seller_profile.total_reviews,
    }
    
    # Recent listings
    recent_listings = my_listings.order_by('-created_at')[:10]
    
    # Recent transactions
    recent_transactions = Transaction.objects.filter(
        seller=request.user
    ).order_by('-created_at')[:10]
    
    context = {
        'seller_profile': seller_profile,
        'stats': stats,
        'recent_listings': recent_listings,
        'recent_transactions': recent_transactions,
    }
    
    return render(request, 'multistock/seller_dashboard.html', context)


# ==================== LISTING CREATION ====================

@require_permission('marketplace', 'create')
def create_listing(request):
    """Create a new listing for marketplace/rental/storage/auction"""
    
    if not hasattr(request.user, 'seller_profile'):
        messages.error(request, 'You must be a registered seller to create listings.')
        return redirect('multistock:become_seller')
    
    seller_profile = request.user.seller_profile
    
    if request.method == 'POST':
        listing_type = request.POST.get('listing_type')
        title = request.POST.get('title')
        description = request.POST.get('description')
        price = Decimal(request.POST.get('price', 0))
        category = request.POST.get('category', '')
        quantity = int(request.POST.get('quantity', 1))
        
        # Create listing
        listing = UnifiedListing.objects.create(
            listing_type=listing_type,
            source_type='customer_seller',
            owner_user=request.user,
            badge=seller_profile.badge,
            title=title,
            description=description,
            price=price,
            category=category,
            quantity=quantity,
            status='pending',  # Requires approval
        )
        
        # Calculate and create listing fee
        listing_fee_amount = calculate_listing_fee(price, listing_type)
        if listing_fee_amount > 0:
            ListingFee.objects.create(
                listing=listing,
                fee_type='listing',
                amount=listing_fee_amount,
                paid=False
            )
        
        # Update seller stats
        seller_profile.total_listings += 1
        seller_profile.save()
        
        messages.success(request, f'Listing "{title}" created! Pending admin approval.')
        return redirect('multistock:my_listings')
    
    listing_types = [
        {'value': 'marketplace', 'label': 'Marketplace Product'},
        {'value': 'rental', 'label': 'Rental Equipment'},
        {'value': 'storage', 'label': 'Storage Unit'},
        {'value': 'auction', 'label': 'Auction Item'},
    ]
    
    context = {
        'listing_types': listing_types,
    }
    
    return render(request, 'multistock/create_listing.html', context)


@require_role('customer_seller', 'admin', 'superadmin')
def my_listings(request):
    """View all seller's listings"""
    
    listings = UnifiedListing.objects.filter(
        owner_user=request.user,
        source_type='customer_seller'
    ).order_by('-created_at')
    
    # Filter by type if specified
    listing_type = request.GET.get('type')
    if listing_type:
        listings = listings.filter(listing_type=listing_type)
    
    # Filter by status
    status = request.GET.get('status')
    if status:
        listings = listings.filter(status=status)
    
    context = {
        'listings': listings,
    }
    
    return render(request, 'multistock/my_listings.html', context)


@require_role('customer_seller', 'admin', 'superadmin')
def edit_listing(request, listing_id):
    """Edit an existing listing"""
    
    listing = get_object_or_404(
        UnifiedListing,
        id=listing_id,
        owner_user=request.user
    )
    
    if request.method == 'POST':
        listing.title = request.POST.get('title')
        listing.description = request.POST.get('description')
        listing.price = Decimal(request.POST.get('price'))
        listing.quantity = int(request.POST.get('quantity', 1))
        listing.availability = request.POST.get('availability') == 'true'
        listing.save()
        
        messages.success(request, 'Listing updated successfully!')
        return redirect('multistock:my_listings')
    
    context = {
        'listing': listing,
    }
    
    return render(request, 'multistock/edit_listing.html', context)


@require_role('customer_seller', 'admin', 'superadmin')
def delete_listing(request, listing_id):
    """Delete a listing"""
    
    listing = get_object_or_404(
        UnifiedListing,
        id=listing_id,
        owner_user=request.user
    )
    
    if request.method == 'POST':
        listing.status = 'inactive'
        listing.availability = False
        listing.save()
        
        messages.success(request, 'Listing deleted successfully!')
        return redirect('multistock:my_listings')
    
    context = {
        'listing': listing,
    }
    
    return render(request, 'multistock/delete_listing_confirm.html', context)


# ==================== EARNINGS & WITHDRAWALS ====================

@require_role('customer_seller', 'admin', 'superadmin')
def seller_earnings(request):
    """View seller earnings and transaction history"""
    
    seller_profile = request.user.seller_profile
    
    transactions = Transaction.objects.filter(
        seller=request.user
    ).order_by('-created_at')
    
    # Calculate totals
    total_sales = transactions.filter(status='completed').aggregate(
        total=Sum('amount')
    )['total'] or 0
    
    total_fees = transactions.filter(status='completed').aggregate(
        total=Sum('platform_fee')
    )['total'] or 0
    
    context = {
        'seller_profile': seller_profile,
        'transactions': transactions,
        'total_sales': total_sales,
        'total_fees': total_fees,
    }
    
    return render(request, 'multistock/seller_earnings.html', context)


# ==================== HELPER FUNCTIONS ====================

def calculate_listing_fee(price, listing_type):
    """Calculate listing fee based on price and type"""
    # Default fee structure - can be customized
    fee_rates = {
        'marketplace': Decimal('2.00'),  # Flat $2
        'rental': Decimal('1.50'),
        'storage': Decimal('3.00'),
        'auction': Decimal('5.00'),
    }
    
    return fee_rates.get(listing_type, Decimal('2.00'))


def calculate_transaction_fee(amount, source_type):
    """Calculate transaction fee/commission"""
    # Default commission rates
    commission_rates = {
        'customer_seller': Decimal('0.10'),  # 10%
        'supplier': Decimal('0.05'),  # 5%
        'platform': Decimal('0.00'),  # No fee
    }
    
    rate = commission_rates.get(source_type, Decimal('0.10'))
    return amount * rate


# ==================== BADGE INITIALIZATION ====================

def initialize_badges():
    """Initialize default badges - run this once via management command"""
    
    badges_data = [
        {
            'badge_type': 'platform',
            'display_name': 'Platform',
            'color': '#6c757d',  # Grey
            'icon': 'fa-shield-alt',
            'description': 'Official MultiStock Platform'
        },
        {
            'badge_type': 'supplier',
            'display_name': 'Verified Supplier',
            'color': '#FFD700',  # Gold
            'icon': 'fa-award',
            'description': 'Verified Business Supplier'
        },
        {
            'badge_type': 'customer_seller',
            'display_name': 'Customer Seller',
            'color': '#3498db',  # Blue
            'icon': 'fa-store',
            'description': 'Trusted Customer Seller'
        },
    ]
    
    for badge_data in badges_data:
        Badge.objects.get_or_create(
            badge_type=badge_data['badge_type'],
            defaults=badge_data
        )
    
    print("✅ Badges initialized successfully!")
