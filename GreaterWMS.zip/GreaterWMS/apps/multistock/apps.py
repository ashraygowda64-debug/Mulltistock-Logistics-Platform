from django.apps import AppConfig

class MultistockConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'multistock'