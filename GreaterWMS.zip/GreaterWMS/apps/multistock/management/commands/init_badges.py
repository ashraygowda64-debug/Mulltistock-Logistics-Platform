"""
Management command to initialize badges for the marketplace system.

Usage: python manage.py init_badges
"""

from django.core.management.base import BaseCommand
from apps.multistock.models_marketplace import Badge


class Command(BaseCommand):
    help = 'Initialize default badges for Platform, Supplier, and Customer Seller'

    def handle(self, *args, **options):
        badges_data = [
            {
                'badge_type': 'platform',
                'display_name': 'Platform',
                'color': '#6c757d',  # Grey
                'icon': 'fa-shield-alt',
                'description': 'Official MultiStock Platform'
            },
            {
                'badge_type': 'supplier',
                'display_name': 'Verified Supplier',
                'color': '#FFD700',  # Gold
                'icon': 'fa-award',
                'description': 'Verified Business Supplier'
            },
            {
                'badge_type': 'customer_seller',
                'display_name': 'Customer Seller',
                'color': '#3498db',  # Blue
                'icon': 'fa-store',
                'description': 'Trusted Customer Seller'
            },
        ]
        
        created_count = 0
        for badge_data in badges_data:
            badge, created = Badge.objects.get_or_create(
                badge_type=badge_data['badge_type'],
                defaults=badge_data
            )
            if created:
                created_count += 1
                self.stdout.write(
                    self.style.SUCCESS(f'✅ Created badge: {badge.display_name}')
                )
            else:
                self.stdout.write(
                    self.style.WARNING(f'Badge already exists: {badge.display_name}')
                )
        
        self.stdout.write(
            self.style.SUCCESS(f'\n✅ Badges initialized successfully! ({created_count} new badges created)')
        )
