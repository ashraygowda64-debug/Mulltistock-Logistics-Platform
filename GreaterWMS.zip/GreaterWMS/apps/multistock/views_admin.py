"""
Admin approval workflows for listings and sellers
"""

from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.utils import timezone

from permissions.decorators import require_role
from .models_marketplace import UnifiedListing, CustomerSellerProfile
from .email_service import EmailService


@require_role('admin', 'superadmin', 'supervisor')
def pending_listings_admin(request):
    """View all pending listings for approval"""
    
    pending_listings = UnifiedListing.objects.filter(
        status='pending'
    ).order_by('-created_at')
    
    context = {
        'pending_listings': pending_listings,
    }
    
    return render(request, 'multistock/admin/pending_listings.html', context)


@require_role('admin', 'superadmin', 'supervisor')
def approve_listing(request, listing_id):
    """Approve a pending listing"""
    
    listing = get_object_or_404(UnifiedListing, id=listing_id)
    
    if request.method == 'POST':
        listing.status = 'active'
        listing.approved_by = request.user
        listing.approved_at = timezone.now()
        listing.published_at = timezone.now()
        listing.save()
        
        # Send email notification to seller
        EmailService.send_listing_approved(listing.owner_user, listing)
        
        messages.success(request, f'Listing "{listing.title}" has been approved and published!')
        return redirect('multistock:pending_listings_admin')
    
    context = {
        'listing': listing,
    }
    
    return render(request, 'multistock/admin/approve_listing.html', context)


@require_role('admin', 'superadmin', 'supervisor')
def reject_listing(request, listing_id):
    """Reject a pending listing"""
    
    listing = get_object_or_404(UnifiedListing, id=listing_id)
    
    if request.method == 'POST':
        rejection_reason = request.POST.get('rejection_reason', 'Does not meet our guidelines')
        
        listing.status = 'rejected'
        listing.rejection_reason = rejection_reason
        listing.save()
        
        # Send email notification to seller
        EmailService.send_listing_rejected(listing.owner_user, listing, rejection_reason)
        
        messages.warning(request, f'Listing "{listing.title}" has been rejected.')
        return redirect('multistock:pending_listings_admin')
    
    context = {
        'listing': listing,
    }
    
    return render(request, 'multistock/admin/reject_listing.html', context)


@require_role('admin', 'superadmin')
def pending_sellers_admin(request):
    """View all sellers pending verification"""
    
    pending_sellers = CustomerSellerProfile.objects.filter(
        is_verified=False
    ).order_by('-created_at')
    
    context = {
        'pending_sellers': pending_sellers,
    }
    
    return render(request, 'multistock/admin/pending_sellers.html', context)


@require_role('admin', 'superadmin')
def verify_seller(request, profile_id):
    """Verify a seller account"""
    
    seller_profile = get_object_or_404(CustomerSellerProfile, id=profile_id)
    
    if request.method == 'POST':
        seller_profile.is_verified = True
        seller_profile.verified_at = timezone.now()
        seller_profile.verified_by = request.user
        seller_profile.save()
        
        # Auto-approve all pending listings from this seller
        seller_profile.user.listings.filter(status='pending').update(
            status='active',
            approved_by=request.user,
            approved_at=timezone.now()
        )
        
        # Send email
        EmailService.send_email(
            to_email=seller_profile.user.email,
            subject="Your seller account has been verified!",
            message=f"Congratulations! Your seller account has been verified. All your listings are now live.",
            email_type='seller_verification'
        )
        
        messages.success(request, f'Seller "{seller_profile.user.username}" has been verified!')
        return redirect('multistock:pending_sellers_admin')
    
    context = {
        'seller_profile': seller_profile,
    }
    
    return render(request, 'multistock/admin/verify_seller.html', context)


@require_role('admin', 'superadmin')
def seller_management(request):
    """Manage all sellers"""
    
    all_sellers = CustomerSellerProfile.objects.all().order_by('-created_at')
    
    context = {
        'sellers': all_sellers,
    }
    
    return render(request, 'multistock/admin/seller_management.html', context)
