from django.urls import path, include
from rest_framework.routers import DefaultRouter
from . import views
from . import views_seller
from . import views_admin

router = DefaultRouter()
router.register(r'marketplace', views.MarketplaceViewSet)
router.register(r'listings', views.ListingViewSet)
router.register(r'forums', views.ForumViewSet)
router.register(r'forum-posts', views.ForumPostViewSet)
router.register(r'analytics', views.AnalyticsViewSet)
router.register(r'auctions', views.AuctionViewSet)
router.register(r'bids', views.BidViewSet)

app_name = 'multistock'

urlpatterns = [
    path('api/', include(router.urls)),
    path('marketplace/', views.marketplace_view, name='marketplace'),
    path('analytics/', views.analytics_view, name='analytics'),
    path('forums/', views.forums_view, name='forums'),
    path('forums/<str:category>/', views.forum_category_view, name='forum_category'),
    path('forums/create-post/', views.create_post_view, name='create_post'),
    path('forums/my-posts/', views.my_posts_view, name='my_posts'),
    path('auctions/', views.auctions_view, name='auctions'),
    path('auctions/create/', views.create_auction_view, name='create_auction'),
    path('my-bids/', views.my_bids_view, name='my_bids'),
    
    # Customer Seller URLs
    path('become-seller/', views_seller.become_seller, name='become_seller'),
    path('seller/dashboard/', views_seller.seller_dashboard, name='seller_dashboard'),
    path('seller/listings/', views_seller.my_listings, name='my_listings'),
    path('seller/listings/create/', views_seller.create_listing, name='create_listing'),
    path('seller/listings/<int:listing_id>/edit/', views_seller.edit_listing, name='edit_listing'),
    path('seller/listings/<int:listing_id>/delete/', views_seller.delete_listing, name='delete_listing'),
    path('seller/earnings/', views_seller.seller_earnings, name='seller_earnings'),
    
    # Admin Workflow URLs
    path('admin/listings/pending/', views_admin.pending_listings_admin, name='pending_listings_admin'),
    path('admin/listings/<int:listing_id>/approve/', views_admin.approve_listing, name='approve_listing'),
    path('admin/listings/<int:listing_id>/reject/', views_admin.reject_listing, name='reject_listing'),
    path('admin/sellers/pending/', views_admin.pending_sellers_admin, name='pending_sellers_admin'),
    path('admin/sellers/<int:profile_id>/verify/', views_admin.verify_seller, name='verify_seller'),
    path('admin/sellers/', views_admin.seller_management, name='seller_management'),
]