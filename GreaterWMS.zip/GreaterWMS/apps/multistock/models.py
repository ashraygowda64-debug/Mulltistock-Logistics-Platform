from django.db import models

# Import marketplace models
from .models_marketplace import (
    Badge,
    CustomerSellerProfile,
    UnifiedListing,
    ListingFee,
    Transaction
)

from django.contrib.auth.models import User
from django.utils import timezone

class Marketplace(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    owner = models.ForeignKey(User, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

class Listing(models.Model):
    marketplace = models.ForeignKey(Marketplace, on_delete=models.CASCADE)
    product_code = models.CharField(max_length=255)
    title = models.CharField(max_length=255)
    description = models.TextField()
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField()
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    category = models.CharField(max_length=100, default='General')
    seller = models.ForeignKey(User, on_delete=models.CASCADE)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    rating_sum = models.IntegerField(default=0)
    rating_count = models.IntegerField(default=0)

    class Meta:
        ordering = ['-created_at']

    def __str__(self):
        return self.title
    
    @property
    def average_rating(self):
        if self.rating_count == 0:
            return 0
        return round(self.rating_sum / self.rating_count, 2)

class ProductRating(models.Model):
    listing = models.ForeignKey(Listing, on_delete=models.CASCADE, related_name='ratings')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    rating = models.IntegerField(choices=[(i, i) for i in range(1, 6)])
    review = models.TextField(blank=True)
    verified_purchase = models.BooleanField(default=False)
    is_spam = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        unique_together = ['listing', 'user']
    
    def save(self, *args, **kwargs):
        is_new = self.pk is None
        super().save(*args, **kwargs)
        
        if is_new and not self.is_spam:
            # Update listing rating
            self.listing.rating_sum += self.rating
            self.listing.rating_count += 1
            self.listing.save()

class Forum(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField()
    creator = models.ForeignKey(User, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title

class ForumPost(models.Model):
    forum = models.ForeignKey(Forum, on_delete=models.CASCADE)
    author = models.ForeignKey(User, on_delete=models.CASCADE)
    content = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

class Analytics(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    metric_name = models.CharField(max_length=255)
    metric_value = models.FloatField()
    date_recorded = models.DateTimeField(auto_now_add=True)

class Auction(models.Model):
    product_code = models.CharField(max_length=255)
    title = models.CharField(max_length=255)
    starting_price = models.DecimalField(max_digits=10, decimal_places=2)
    current_price = models.DecimalField(max_digits=10, decimal_places=2)
    reserve_price = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    end_time = models.DateTimeField()
    auto_extend = models.BooleanField(default=True)
    extension_minutes = models.IntegerField(default=5)
    seller = models.ForeignKey(User, on_delete=models.CASCADE)
    winner = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='won_auctions')
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def check_and_extend(self):
        """Auto-extend auction if bid placed in last minutes"""
        from django.utils import timezone
        from datetime import timedelta
        
        if self.auto_extend:
            time_left = (self.end_time - timezone.now()).total_seconds()
            if 0 < time_left < 300:  # Last 5 minutes
                self.end_time += timedelta(minutes=self.extension_minutes)
                self.save()
                return True
        return False
    
    def finalize_auction(self):
        """Finalize auction and notify winner"""
        from django.utils import timezone
        
        if timezone.now() >= self.end_time and self.is_active:
            highest_bid = self.bid_set.order_by('-amount').first()
            
            if highest_bid and highest_bid.amount >= self.reserve_price:
                self.winner = highest_bid.bidder
                self.is_active = False
                self.save()
                
                # Send winner notification
                from notifications.email_service import EmailService
                EmailService.send_email(
                    to_email=highest_bid.bidder.email,
                    subject=f'Congratulations! You won: {self.title}',
                    message=f'You won the auction with a bid of ${highest_bid.amount}',
                    email_type='auction_winner'
                )
                return True
        return False

class Bid(models.Model):
    auction = models.ForeignKey(Auction, on_delete=models.CASCADE)
    bidder = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    created_at = models.DateTimeField(auto_now_add=True)
    
    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Update auction current price
        self.auction.current_price = self.amount
        self.auction.save()
        # Check for auto-extend
        self.auction.check_and_extend()