"""
Email Service for MultiStock Platform
Supports SMTP, SendGrid, and other email backends
"""

from django.core.mail import send_mail, EmailMultiAlternatives
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags
import logging

logger = logging.getLogger(__name__)


class EmailService:
    """
    Unified email service for all platform notifications
    """
    
    @staticmethod
    def send_email(to_email, subject, message, email_type='general', html_message=None, from_email=None):
        """
        Send email using configured backend
        
        Args:
            to_email (str): Recipient email
            subject (str): Email subject
            message (str): Plain text message
            email_type (str): Type of email for template selection
            html_message (str): Optional HTML version
            from_email (str): Sender email (defaults to settings.DEFAULT_FROM_EMAIL)
        """
        try:
            if from_email is None:
                from_email = getattr(settings, 'DEFAULT_FROM_EMAIL', 'noreply@multistock.com')
            
            # Send email
            result = send_mail(
                subject=subject,
                message=message,
                from_email=from_email,
                recipient_list=[to_email],
                html_message=html_message,
                fail_silently=False
            )
            
            logger.info(f"Email sent to {to_email}: {subject}")
            return result
            
        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {str(e)}")
            return False
    
    @staticmethod
    def send_template_email(to_email, template_name, context, subject=None):
        """
        Send email using Django template
        
        Args:
            to_email (str): Recipient email
            template_name (str): Template path (without .html)
            context (dict): Template context
            subject (str): Email subject (can also be in template)
        """
        try:
            # Render HTML email
            html_content = render_to_string(f'emails/{template_name}.html', context)
            text_content = strip_tags(html_content)
            
            # Get subject from context if not provided
            if subject is None:
                subject = context.get('subject', 'Notification from MultiStock')
            
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', 'noreply@multistock.com'),
                to=[to_email]
            )
            email.attach_alternative(html_content, "text/html")
            email.send(fail_silently=False)
            
            logger.info(f"Template email sent to {to_email}: {template_name}")
            return True
            
        except Exception as e:
            logger.error(f"Failed to send template email to {to_email}: {str(e)}")
            return False
    
    # ==================== SELLER EMAILS ====================
    
    @staticmethod
    def send_seller_welcome(user, seller_profile):
        """Welcome email for new sellers"""
        subject = "Welcome to MultiStock Marketplace!"
        context = {
            'user': user,
            'seller_profile': seller_profile,
            'subject': subject
        }
        return EmailService.send_template_email(user.email, 'seller_welcome', context, subject)
    
    @staticmethod
    def send_listing_created(user, listing):
        """Notification when listing is created"""
        subject = f"Listing Created: {listing.title}"
        context = {
            'user': user,
            'listing': listing,
            'subject': subject
        }
        return EmailService.send_template_email(user.email, 'listing_created', context, subject)
    
    @staticmethod
    def send_listing_approved(user, listing):
        """Notification when listing is approved"""
        subject = f"Listing Approved: {listing.title}"
        context = {
            'user': user,
            'listing': listing,
            'subject': subject
        }
        return EmailService.send_template_email(user.email, 'listing_approved', context, subject)
    
    @staticmethod
    def send_listing_rejected(user, listing, reason):
        """Notification when listing is rejected"""
        subject = f"Listing Rejected: {listing.title}"
        context = {
            'user': user,
            'listing': listing,
            'reason': reason,
            'subject': subject
        }
        return EmailService.send_template_email(user.email, 'listing_rejected', context, subject)
    
    @staticmethod
    def send_sale_notification(seller, buyer, transaction):
        """Notification when item is sold"""
        subject = f"Sale Confirmed: {transaction.listing.title}"
        context = {
            'seller': seller,
            'buyer': buyer,
            'transaction': transaction,
            'subject': subject
        }
        return EmailService.send_template_email(seller.email, 'sale_notification', context, subject)
    
    @staticmethod
    def send_earnings_notification(user, amount):
        """Notification for earnings update"""
        subject = f"You earned ${amount}!"
        context = {
            'user': user,
            'amount': amount,
            'subject': subject
        }
        return EmailService.send_template_email(user.email, 'earnings_notification', context, subject)
    
    # ==================== BUYER EMAILS ====================
    
    @staticmethod
    def send_purchase_confirmation(buyer, transaction):
        """Purchase confirmation email"""
        subject = f"Order Confirmed: {transaction.listing.title}"
        context = {
            'buyer': buyer,
            'transaction': transaction,
            'subject': subject
        }
        return EmailService.send_template_email(buyer.email, 'purchase_confirmation', context, subject)
    
    # ==================== AUCTION EMAILS ====================
    
    @staticmethod
    def send_auction_winner(user, auction, bid_amount):
        """Congratulations email for auction winner"""
        subject = f"Congratulations! You won: {auction.title}"
        context = {
            'user': user,
            'auction': auction,
            'bid_amount': bid_amount,
            'subject': subject
        }
        return EmailService.send_template_email(user.email, 'auction_winner', context, subject)
    
    # ==================== ADMIN EMAILS ====================
    
    @staticmethod
    def send_admin_new_listing(listing):
        """Notify admin of new listing pending approval"""
        admin_emails = getattr(settings, 'ADMIN_NOTIFICATION_EMAILS', [])
        if not admin_emails:
            return False
        
        subject = f"New Listing Pending Approval: {listing.title}"
        context = {
            'listing': listing,
            'subject': subject
        }
        
        for admin_email in admin_emails:
            EmailService.send_template_email(admin_email, 'admin_new_listing', context, subject)
        
        return True


# Quick send functions for common use cases
def send_welcome_email(user_email, username):
    """Send welcome email to new user"""
    return EmailService.send_email(
        to_email=user_email,
        subject="Welcome to MultiStock!",
        message=f"Hello {username},\n\nWelcome to MultiStock platform!\n\nBest regards,\nMultiStock Team",
        email_type='welcome'
    )


def send_verification_email(user_email, verification_link):
    """Send email verification link"""
    return EmailService.send_email(
        to_email=user_email,
        subject="Verify your email address",
        message=f"Click the link to verify your email: {verification_link}",
        email_type='verification'
    )


def send_password_reset(user_email, reset_link):
    """Send password reset email"""
    return EmailService.send_email(
        to_email=user_email,
        subject="Reset your password",
        message=f"Click the link to reset your password: {reset_link}",
        email_type='password_reset'
    )
