from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Count, Sum, Avg
from django.utils import timezone
from datetime import timedelta
from .models import Marketplace, Listing, Forum, ForumPost, Analytics, Auction, Bid
from .serializers import MarketplaceSerializer, ListingSerializer, ForumSerializer, ForumPostSerializer, AnalyticsSerializer, AuctionSerializer, BidSerializer

class MarketplaceViewSet(viewsets.ModelViewSet):
    queryset = Marketplace.objects.filter(is_active=True)
    serializer_class = MarketplaceSerializer
    permission_classes = [IsAuthenticated]

class ListingViewSet(viewsets.ModelViewSet):
    queryset = Listing.objects.filter(is_active=True)
    serializer_class = ListingSerializer
    permission_classes = [IsAuthenticated]

class ForumViewSet(viewsets.ModelViewSet):
    queryset = Forum.objects.all()
    serializer_class = ForumSerializer
    permission_classes = [IsAuthenticated]

class ForumPostViewSet(viewsets.ModelViewSet):
    queryset = ForumPost.objects.all()
    serializer_class = ForumPostSerializer
    permission_classes = [IsAuthenticated]

class AnalyticsViewSet(viewsets.ModelViewSet):
    queryset = Analytics.objects.all()
    serializer_class = AnalyticsSerializer
    permission_classes = [IsAuthenticated]

class AuctionViewSet(viewsets.ModelViewSet):
    queryset = Auction.objects.filter(is_active=True)
    serializer_class = AuctionSerializer
    permission_classes = [IsAuthenticated]

class BidViewSet(viewsets.ModelViewSet):
    queryset = Bid.objects.all()
    serializer_class = BidSerializer
    permission_classes = [IsAuthenticated]

def marketplace_view(request):
    """Public marketplace view - no login required"""
    from goods.models import ListModel as Product
    from stock.models import StockListModel
    
    products = Product.objects.filter(is_delete=False).order_by('-create_time')
    
    products_with_stock = []
    for product in products:
        try:
            stock = StockListModel.objects.filter(goods_code=product.goods_code).first()
            image_url = stock.goods_image.url if stock and stock.goods_image else '/static/default-product.png'
            is_multistock = product.goods_brand == "Multistock"
            
            products_with_stock.append({
                'product': product,
                'stock': stock.goods_qty if stock else 0,
                'supplier': product.goods_supplier or 'N/A',
                'image': image_url,
                'is_multistock': is_multistock
            })
        except:
            products_with_stock.append({
                'product': product,
                'stock': 0,
                'supplier': 'N/A',
                'image': '/static/default-product.png',
                'is_multistock': False
            })
    
    context = {
        'products': products_with_stock,
        'total_products': Product.objects.filter(is_delete=False).count(),
        'low_stock_count': sum(1 for p in products_with_stock if p['stock'] <= 10),
    }
    
    # Check if guest mode - use guest template (CHECK SESSION FLAGS FIRST)
    is_guest = request.session.get('is_guest', False) or request.session.get('guest_mode', False)
    print(f"[MARKETPLACE] is_guest={is_guest}, guest_mode={request.session.get('guest_mode')}, is_authenticated={request.user.is_authenticated}, username={request.user.username if request.user.is_authenticated else 'Anonymous'}")
    
    if is_guest:
        print("[MARKETPLACE] → Rendering GUEST template")
        return render(request, 'multistock/guest_marketplace.html', context)
    
    # If not authenticated at all, also use guest template
    if not request.user.is_authenticated:
        print("[MARKETPLACE] → Rendering GUEST template (not authenticated)")
        return render(request, 'multistock/guest_marketplace.html', context)
    
    print("[MARKETPLACE] → Rendering REGULAR template")
    return render(request, 'multistock/marketplace.html', context)

def analytics_view(request):
    """Public analytics view - no login required"""
    # Get analytics data for the last 30 days
    thirty_days_ago = timezone.now() - timedelta(days=30)
    
    analytics_data = {
        'total_listings': Listing.objects.count(),
        'active_auctions': Auction.objects.filter(is_active=True, end_time__gt=timezone.now()).count(),
        'total_bids': Bid.objects.count(),
        'avg_listing_price': Listing.objects.aggregate(avg_price=Avg('price'))['avg_price'] or 0,
        'recent_activity': Analytics.objects.filter(date_recorded__gte=thirty_days_ago).count(),
    }
    
    return render(request, 'multistock/analytics.html', analytics_data)

def forums_view(request):
    """Public forums view - no login required for browsing"""
    forums = Forum.objects.all().order_by('-created_at')
    recent_posts = ForumPost.objects.all().order_by('-created_at')[:10]
    
    context = {
        'forums': forums,
        'recent_posts': recent_posts,
        'total_forums': forums.count(),
        'total_posts': ForumPost.objects.count(),
    }
    
    # Check if guest mode - use guest template (CHECK SESSION FLAGS FIRST)
    is_guest = request.session.get('is_guest', False) or request.session.get('guest_mode', False)
    print(f"[FORUMS] is_guest={is_guest}, guest_mode={request.session.get('guest_mode')}, is_authenticated={request.user.is_authenticated}, username={request.user.username if request.user.is_authenticated else 'Anonymous'}")
    
    if is_guest:
        print("[FORUMS] → Rendering GUEST template")
        return render(request, 'multistock/guest_forums.html', context)
    
    # If not authenticated at all, also use guest template
    if not request.user.is_authenticated:
        print("[FORUMS] → Rendering GUEST template (not authenticated)")
        return render(request, 'multistock/guest_forums.html', context)
    
    print("[FORUMS] → Rendering REGULAR template")
    return render(request, 'multistock/forums.html', context)

def auctions_view(request):
    """Public auctions view - no login required for browsing"""
    active_auctions = Auction.objects.filter(is_active=True, end_time__gt=timezone.now()).order_by('end_time')
    ended_auctions = Auction.objects.filter(end_time__lte=timezone.now()).order_by('-end_time')[:10]
    
    context = {
        'active_auctions': active_auctions,
        'ended_auctions': ended_auctions,
        'total_auctions': Auction.objects.count(),
        'active_count': active_auctions.count(),
    }
    
    # Check if guest mode - use guest template (CHECK SESSION FLAGS FIRST)
    is_guest = request.session.get('is_guest', False) or request.session.get('guest_mode', False)
    print(f"[AUCTIONS] is_guest={is_guest}, guest_mode={request.session.get('guest_mode')}, is_authenticated={request.user.is_authenticated}, username={request.user.username if request.user.is_authenticated else 'Anonymous'}")
    
    if is_guest:
        print("[AUCTIONS] → Rendering GUEST template")
        return render(request, 'multistock/guest_auctions.html', context)
    
    # If not authenticated at all, also use guest template
    if not request.user.is_authenticated:
        print("[AUCTIONS] → Rendering GUEST template (not authenticated)")
        return render(request, 'multistock/guest_auctions.html', context)
    
    print("[AUCTIONS] → Rendering REGULAR template")
    return render(request, 'multistock/auctions.html', context)

@login_required
def my_bids_view(request):
    return render(request, 'multistock/my_bids.html')

def forum_category_view(request, category):
    """Public forum category view - no login required for browsing"""
    category_names = {
        'general': 'General Discussion',
        'reviews': 'Product Reviews', 
        'support': 'Technical Support',
        'business': 'Business Tips'
    }
    category_icons = {
        'general': '💬',
        'reviews': '⭐',
        'support': '🔧', 
        'business': '💡'
    }
    
    context = {
        'category_name': category_names.get(category, 'Unknown Category'),
        'category_icon': category_icons.get(category, ''),
        'category': category
    }
    return render(request, 'multistock/forum_category.html', context)

@login_required
def create_post_view(request):
    # Check if user has team access (Staff, Senior Staff, Sub-Admin, Admin, Superadmin)
    if not (request.user.groups.exists() or request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Only team members can create posts.')
        return redirect('forums')
    
    if request.method == 'POST':
        try:
            # Handle post creation
            title = request.POST.get('title')
            content = request.POST.get('content')
            category = request.POST.get('category')
            
            if title and content and category:
                # Create forum post (simplified for now)
                messages.success(request, 'Post created successfully!')
                return redirect('forums')
            else:
                messages.error(request, 'Please fill in all required fields.')
        except Exception as e:
            messages.error(request, 'Error creating post. Please try again.')
    
    return render(request, 'multistock/create_post.html')

@login_required
def my_posts_view(request):
    # Get user's posts if they have team access
    user_posts = []
    if request.user.groups.exists() or request.user.is_staff:
        user_posts = ForumPost.objects.filter(author=request.user).order_by('-created_at')
    
    context = {
        'user_posts': user_posts,
        'has_team_access': request.user.groups.exists() or request.user.is_staff
    }
    return render(request, 'multistock/my_posts.html', context)

@login_required
def create_auction_view(request):
    # Check if user has team access for auction creation
    if not (request.user.groups.exists() or request.user.is_staff or request.user.is_superuser):
        messages.error(request, 'Access denied. Only team members can create auctions.')
        return redirect('auctions')
    
    if request.method == 'POST':
        # Handle auction creation
        title = request.POST.get('title')
        starting_price = request.POST.get('starting_price')
        end_time = request.POST.get('end_time')
        
        if title and starting_price and end_time:
            # Create auction logic here
            messages.success(request, 'Auction created successfully!')
            return redirect('auctions')
    
    return render(request, 'multistock/create_auction.html')