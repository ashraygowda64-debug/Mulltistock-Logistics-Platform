from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone


class Badge(models.Model):
    """Badge system for Platform, Supplier, and Customer Seller identification"""
    BADGE_TYPES = (
        ('platform', 'Platform Badge'),
        ('supplier', 'Supplier Badge'),
        ('customer_seller', 'Customer Seller Badge'),
    )
    
    badge_type = models.CharField(max_length=20, choices=BADGE_TYPES, unique=True)
    color = models.CharField(max_length=20, default='#6c757d')
    icon = models.CharField(max_length=50, default='fa-badge')
    display_name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'marketplace_badges'
        verbose_name = 'Badge'
        verbose_name_plural = 'Badges'
    
    def __str__(self):
        return f"{self.display_name} ({self.badge_type})"


class CustomerSellerProfile(models.Model):
    """Profile for customers who become sellers in the marketplace"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='seller_profile')
    badge = models.ForeignKey(Badge, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Verification & Status
    is_verified = models.BooleanField(default=False)
    verification_document = models.FileField(upload_to='seller_docs/', null=True, blank=True)
    verified_at = models.DateTimeField(null=True, blank=True)
    verified_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='verified_sellers')
    
    # Business Info
    business_name = models.CharField(max_length=255, blank=True)
    business_description = models.TextField(blank=True)
    business_logo = models.ImageField(upload_to='seller_logos/', null=True, blank=True)
    
    # Performance Metrics
    total_sales = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    total_listings = models.IntegerField(default=0)
    rating = models.FloatField(default=0)
    total_reviews = models.IntegerField(default=0)
    
    # Earnings
    lifetime_earnings = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    pending_earnings = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    withdrawn_earnings = models.DecimalField(max_digits=12, decimal_places=2, default=0)
    
    # Settings
    auto_approve_listings = models.BooleanField(default=False)
    email_notifications = models.BooleanField(default=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'customer_seller_profiles'
        verbose_name = 'Customer Seller Profile'
        verbose_name_plural = 'Customer Seller Profiles'
    
    def __str__(self):
        return f"Seller: {self.user.username}"


class UnifiedListing(models.Model):
    """Unified listing model for Marketplace, Rentals, Storage, and Auctions"""
    LISTING_TYPES = (
        ('marketplace', 'Marketplace Product'),
        ('rental', 'Rental Equipment'),
        ('storage', 'Storage Unit'),
        ('auction', 'Auction Item'),
    )
    
    SOURCE_TYPES = (
        ('platform', 'Platform'),
        ('supplier', 'Supplier'),
        ('customer_seller', 'Customer Seller'),
    )
    
    STATUS_CHOICES = (
        ('draft', 'Draft'),
        ('pending', 'Pending Approval'),
        ('approved', 'Approved'),
        ('active', 'Active'),
        ('sold', 'Sold'),
        ('rented', 'Rented'),
        ('expired', 'Expired'),
        ('rejected', 'Rejected'),
        ('inactive', 'Inactive'),
    )
    
    # Listing Type & Source
    listing_type = models.CharField(max_length=20, choices=LISTING_TYPES)
    source_type = models.CharField(max_length=20, choices=SOURCE_TYPES)
    
    # Owner Information
    owner_user = models.ForeignKey(User, on_delete=models.CASCADE, null=True, blank=True, related_name='listings')
    owner_supplier = models.ForeignKey('supplier.ListModel', on_delete=models.CASCADE, null=True, blank=True, related_name='marketplace_listings')
    
    # Badge
    badge = models.ForeignKey(Badge, on_delete=models.SET_NULL, null=True, blank=True)
    
    # Basic Information
    title = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=100, blank=True)
    subcategory = models.CharField(max_length=100, blank=True)
    
    # Pricing
    price = models.DecimalField(max_digits=10, decimal_places=2)
    original_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    currency = models.CharField(max_length=3, default='USD')
    
    # Availability
    availability = models.BooleanField(default=True)
    quantity = models.IntegerField(default=1)
    
    # Status & Approval
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='draft')
    approved_by = models.ForeignKey(User, on_delete=models.SET_NULL, null=True, blank=True, related_name='approved_listings')
    approved_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.TextField(blank=True)
    
    # Media
    featured_image = models.ImageField(upload_to='listings/', null=True, blank=True)
    images = models.JSONField(default=list, blank=True)  # Array of image URLs
    video_url = models.URLField(blank=True)
    
    # Additional Data
    metadata = models.JSONField(default=dict, blank=True)  # Flexible storage for type-specific data
    tags = models.JSONField(default=list, blank=True)
    
    # Location (for Storage/Rentals)
    location = models.CharField(max_length=255, blank=True)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    
    # Rental/Auction Specific
    rental_duration_type = models.CharField(max_length=20, blank=True)  # hourly, daily, weekly, monthly
    auction_start_date = models.DateTimeField(null=True, blank=True)
    auction_end_date = models.DateTimeField(null=True, blank=True)
    starting_bid = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    
    # Statistics
    views_count = models.IntegerField(default=0)
    favorites_count = models.IntegerField(default=0)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    published_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        db_table = 'unified_listings'
        verbose_name = 'Unified Listing'
        verbose_name_plural = 'Unified Listings'
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['listing_type', 'status']),
            models.Index(fields=['source_type']),
            models.Index(fields=['owner_user']),
            models.Index(fields=['created_at']),
        ]
    
    def __str__(self):
        return f"{self.title} ({self.listing_type} - {self.source_type})"


class ListingFee(models.Model):
    """Fee tracking for listings"""
    FEE_TYPES = (
        ('listing', 'Listing Fee'),
        ('transaction', 'Transaction Fee'),
        ('commission', 'Platform Commission'),
    )
    
    listing = models.ForeignKey(UnifiedListing, on_delete=models.CASCADE, related_name='fees')
    fee_type = models.CharField(max_length=20, choices=FEE_TYPES)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    percentage = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    
    paid = models.BooleanField(default=False)
    paid_at = models.DateTimeField(null=True, blank=True)
    payment_method = models.CharField(max_length=50, blank=True)
    payment_reference = models.CharField(max_length=255, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'listing_fees'
        verbose_name = 'Listing Fee'
        verbose_name_plural = 'Listing Fees'
    
    def __str__(self):
        return f"{self.fee_type} - ${self.amount}"


class Transaction(models.Model):
    """Transaction tracking for purchases, rentals, auctions"""
    TRANSACTION_TYPES = (
        ('purchase', 'Purchase'),
        ('rental', 'Rental'),
        ('auction', 'Auction Win'),
        ('storage', 'Storage Booking'),
    )
    
    STATUS_CHOICES = (
        ('pending', 'Pending'),
        ('processing', 'Processing'),
        ('completed', 'Completed'),
        ('cancelled', 'Cancelled'),
        ('refunded', 'Refunded'),
    )
    
    listing = models.ForeignKey(UnifiedListing, on_delete=models.CASCADE, related_name='transactions')
    transaction_type = models.CharField(max_length=20, choices=TRANSACTION_TYPES)
    
    # Parties
    buyer = models.ForeignKey(User, on_delete=models.CASCADE, related_name='purchases')
    seller = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sales')
    
    # Financial Details
    amount = models.DecimalField(max_digits=12, decimal_places=2)
    platform_fee = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    seller_earnings = models.DecimalField(max_digits=12, decimal_places=2)
    
    # Status
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='pending')
    
    # Payment
    payment_method = models.CharField(max_length=50, blank=True)
    payment_reference = models.CharField(max_length=255, blank=True)
    payment_completed_at = models.DateTimeField(null=True, blank=True)
    
    # Delivery/Fulfillment
    fulfillment_status = models.CharField(max_length=50, blank=True)
    delivered_at = models.DateTimeField(null=True, blank=True)
    
    # Additional Data
    notes = models.TextField(blank=True)
    metadata = models.JSONField(default=dict, blank=True)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'marketplace_transactions'
        verbose_name = 'Transaction'
        verbose_name_plural = 'Transactions'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"Transaction #{self.id} - {self.buyer.username} - ${self.amount}"
