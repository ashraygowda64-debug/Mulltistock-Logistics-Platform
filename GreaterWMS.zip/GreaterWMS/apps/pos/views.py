from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.db.models import Q
from goods.models import ListModel
from stock.models import StockListModel
from warehouse.models import ListModel as WarehouseModel

@login_required
def pos_interface(request):
    # Get all warehouses for selection
    warehouses = WarehouseModel.objects.filter(is_delete=False)
    
    # Get products with stock
    products = []
    for product in ListModel.objects.filter(is_delete=False)[:20]:  # Limit for performance
        stock = StockListModel.objects.filter(goods_code=product.goods_code).first()
        if stock and stock.goods_qty > 0:
            products.append({
                'id': product.id,
                'name': product.goods_desc,  # Fixed: was goods_name, should be goods_desc
                'code': product.goods_code,
                'price': float(product.goods_price or 0),
                'stock': stock.goods_qty,
                'description': product.goods_desc or '',
                'category': product.goods_class or 'General'
            })
    
    context = {
        'products': products,
        'warehouses': warehouses
    }
    return render(request, 'pos/interface.html', context)

@login_required
def pos_sales(request):
    return render(request, 'pos/sales.html')

@login_required
def search_products(request):
    query = request.GET.get('q', '').strip()
    warehouse_id = request.GET.get('warehouse')
    
    products = []
    if len(query) >= 2:
        product_list = ListModel.objects.filter(
            Q(goods_desc__icontains=query) | Q(goods_code__icontains=query),  # Fixed: was goods_name
            is_delete=False
        )[:10]
        
        for product in product_list:
            stock = StockListModel.objects.filter(goods_code=product.goods_code).first()
            if stock and stock.goods_qty > 0:
                products.append({
                    'id': product.id,
                    'name': product.goods_desc,  # Fixed: was goods_name
                    'code': product.goods_code,
                    'price': float(product.goods_price or 0),
                    'stock': stock.goods_qty,
                    'description': product.goods_desc or '',
                    'category': product.goods_class or 'General'
                })
    
    return JsonResponse({'products': products})