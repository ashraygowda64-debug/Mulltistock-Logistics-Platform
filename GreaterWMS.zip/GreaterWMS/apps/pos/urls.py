from django.urls import path
from . import views

urlpatterns = [
    path('', views.pos_interface, name='pos_interface'),
    path('sales/', views.pos_sales, name='pos_sales'),
    path('api/search/', views.search_products, name='search_products'),
]