from django.urls import path
from . import views, api_views

app_name = 'lockers'

urlpatterns = [
    path('', views.lockers_list, name='list'),
    path('<int:locker_id>/', views.locker_detail, name='detail'),
    path('<int:locker_id>/book/', views.book_locker, name='book'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path('analytics/', views.locker_analytics, name='analytics'),
    path('api/booking/create/', api_views.create_booking, name='create_booking'),
]
