from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from datetime import timedelta
from .models import Locker, LockerBooking, LockerAccessLog
import json
import random
import string

@login_required
@require_http_methods(["POST"])
def create_booking(request):
    try:
        data = json.loads(request.body)
        locker = Locker.objects.get(id=data['locker_id'])
        
        if not locker.is_available():
            return JsonResponse({'success': False, 'error': 'Locker not available'}, status=400)
        
        duration_type = data['duration_type']
        duration_count = int(data['duration_count'])
        
        start_date = timezone.now()
        if duration_type == 'hourly':
            end_date = start_date + timedelta(hours=duration_count)
            rate = locker.locker_type.hourly_rate
        elif duration_type == 'daily':
            end_date = start_date + timedelta(days=duration_count)
            rate = locker.locker_type.daily_rate
        elif duration_type == 'weekly':
            end_date = start_date + timedelta(weeks=duration_count)
            rate = locker.locker_type.weekly_rate
        else:
            end_date = start_date + timedelta(days=30 * duration_count)
            rate = locker.locker_type.monthly_rate
        
        total_amount = float(rate) * duration_count
        access_code = ''.join(random.choices(string.digits, k=6))
        
        booking = LockerBooking.objects.create(
            locker=locker,
            customer_name=data['customer_name'],
            customer_email=data['customer_email'],
            customer_phone=data['customer_phone'],
            duration_type=duration_type,
            duration_count=duration_count,
            start_date=start_date,
            end_date=end_date,
            access_code=access_code,
            total_amount=total_amount,
            items_description=data.get('items_description', ''),
            status='active',
            created_by=request.user
        )
        
        locker.status = 'occupied'
        locker.access_code = access_code
        locker.save()
        
        LockerAccessLog.objects.create(
            locker=locker,
            booking=booking,
            action='open',
            access_code_used=access_code,
            user=request.user,
            notes='Locker booked'
        )
        
        return JsonResponse({
            'success': True,
            'booking_number': booking.booking_number,
            'access_code': access_code
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)
