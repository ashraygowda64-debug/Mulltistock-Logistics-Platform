from django.urls import path
from . import views

urlpatterns = [
    path('', views.reports_dashboard, name='reports_dashboard'),
    path('create/', views.reports_dashboard, name='create_report'),  # Added missing URL
    path('sales/', views.generate_sales_report, name='sales_report'),
    path('inventory/', views.generate_inventory_report, name='inventory_report'),
    path('customers/', views.generate_customer_report, name='customer_report'),
    path('low-stock/', views.low_stock_report, name='low_stock_report'),
    path('scheduled/', views.reports_dashboard, name='scheduled_reports'),
]