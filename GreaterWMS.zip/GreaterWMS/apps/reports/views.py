from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import HttpResponse, JsonResponse
from .report_generator import ReportGenerator
from datetime import datetime, timedelta

@login_required
def reports_dashboard(request):
    return render(request, 'reports/dashboard.html')

@login_required
def generate_sales_report(request):
    end_date = datetime.now()
    start_date = end_date - timedelta(days=30)
    
    data = ReportGenerator.sales_report(start_date, end_date)
    
    if request.GET.get('format') == 'csv':
        csv_data = ReportGenerator.export_to_csv(data, 'sales_report.csv')
        response = HttpResponse(csv_data, content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="sales_report.csv"'
        return response
    
    return JsonResponse({'data': data})

@login_required
def generate_inventory_report(request):
    data = ReportGenerator.inventory_report()
    
    if request.GET.get('format') == 'csv':
        csv_data = ReportGenerator.export_to_csv(data, 'inventory_report.csv')
        response = HttpResponse(csv_data, content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="inventory_report.csv"'
        return response
    
    return JsonResponse({'data': data})

@login_required
def generate_customer_report(request):
    data = ReportGenerator.customer_report()
    
    if request.GET.get('format') == 'csv':
        csv_data = ReportGenerator.export_to_csv(data, 'customer_report.csv')
        response = HttpResponse(csv_data, content_type='text/csv')
        response['Content-Disposition'] = 'attachment; filename="customer_report.csv"'
        return response
    
    return JsonResponse({'data': data})

@login_required
def low_stock_report(request):
    threshold = int(request.GET.get('threshold', 10))
    data = ReportGenerator.low_stock_report(threshold)
    return JsonResponse({'data': data, 'count': len(data)})
