from django.urls import path
from . import views

urlpatterns = [
    path('dashboard/metrics/', views.dashboard_metrics, name='dashboard_metrics'),
    path('products/bulk/', views.bulk_product_action, name='bulk_products'),
    path('orders/stats/', views.order_statistics, name='order_stats'),
    path('inventory/alerts/', views.inventory_alerts, name='inventory_alerts'),
    path('audit/logs/', views.audit_logs, name='audit_logs'),
    path('settings/get/', views.get_settings, name='get_settings'),
    path('settings/save/', views.save_settings, name='save_settings'),
]
