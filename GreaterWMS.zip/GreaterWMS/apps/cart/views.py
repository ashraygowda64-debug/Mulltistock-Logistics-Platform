from django.shortcuts import render, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from .models import Cart, CartItem, Coupon
from goods.models import ListModel
import json

@login_required
@require_http_methods(["GET"])
def get_cart(request):
    cart, created = Cart.objects.get_or_create(user=request.user)
    items = [{
        'id': item.id,
        'product_id': item.product.id if item.product else None,
        'title': item.product_name,
        'price': float(item.unit_price),
        'quantity': item.quantity,
        'total': float(item.total_price),
        'seller': item.seller,
        'image': item.image_url
    } for item in cart.items.all()]
    
    return JsonResponse({
        'items': items,
        'total_items': cart.total_items,
        'subtotal': float(cart.subtotal)
    })

@login_required
@require_http_methods(["POST"])
def add_to_cart(request):
    data = json.loads(request.body)
    cart, created = Cart.objects.get_or_create(user=request.user)
    
    product_id = data.get('product_id')
    product = ListModel.objects.filter(id=product_id).first() if product_id else None
    
    item, created = CartItem.objects.get_or_create(
        cart=cart,
        product=product,
        defaults={
            'product_name': data.get('title'),
            'unit_price': data.get('price'),
            'quantity': data.get('quantity', 1),
            'seller': data.get('seller', ''),
            'image_url': data.get('image', '')
        }
    )
    
    if not created:
        item.quantity += data.get('quantity', 1)
        item.save()
    
    return JsonResponse({'success': True, 'item_id': item.id})

@login_required
@require_http_methods(["POST"])
def update_cart_item(request, item_id):
    data = json.loads(request.body)
    item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    
    item.quantity = data.get('quantity', item.quantity)
    item.save()
    
    return JsonResponse({'success': True, 'total': float(item.total_price)})

@login_required
@require_http_methods(["DELETE"])
def remove_from_cart(request, item_id):
    item = get_object_or_404(CartItem, id=item_id, cart__user=request.user)
    item.delete()
    return JsonResponse({'success': True})

@login_required
@require_http_methods(["POST"])
def clear_cart(request):
    cart = Cart.objects.filter(user=request.user).first()
    if cart:
        cart.items.all().delete()
    return JsonResponse({'success': True})

@login_required
@require_http_methods(["POST"])
def apply_coupon(request):
    data = json.loads(request.body)
    code = data.get('code', '').upper()
    subtotal = float(data.get('subtotal', 0))
    
    try:
        coupon = Coupon.objects.get(code=code)
        if not coupon.is_valid():
            return JsonResponse({'success': False, 'message': 'Coupon expired or invalid'})
        
        if subtotal < float(coupon.min_order_amount):
            return JsonResponse({'success': False, 'message': f'Minimum order of Rs.{coupon.min_order_amount} required'})
        
        discount = 0
        if coupon.discount_type == 'percentage':
            discount = (subtotal * float(coupon.discount_value)) / 100
        elif coupon.discount_type == 'fixed':
            discount = float(coupon.discount_value)
        
        return JsonResponse({
            'success': True,
            'discount': discount,
            'type': coupon.discount_type,
            'message': 'Coupon applied successfully'
        })
    except Coupon.DoesNotExist:
        return JsonResponse({'success': False, 'message': 'Invalid coupon code'})
