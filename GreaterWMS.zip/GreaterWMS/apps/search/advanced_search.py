from django.db.models import Q
from django.core.cache import cache

class AdvancedSearch:
    @staticmethod
    def search_all(query, user=None):
        """Search across all modules with ranking"""
        if not query:
            return {'results': [], 'count': 0}
        
        cache_key = f'search_{query}_{user.id if user else "anon"}'
        cached = cache.get(cache_key)
        if cached:
            return cached
        
        results = {
            'products': AdvancedSearch._search_products(query),
            'orders': AdvancedSearch._search_orders(query, user),
            'customers': AdvancedSearch._search_customers(query),
            'suppliers': AdvancedSearch._search_suppliers(query),
        }
        
        all_results = []
        for category, items in results.items():
            for item in items:
                item['category'] = category
                all_results.append(item)
        
        all_results.sort(key=lambda x: x.get('relevance', 0), reverse=True)
        
        response = {
            'results': all_results[:50],
            'count': len(all_results),
            'by_category': {k: len(v) for k, v in results.items()}
        }
        
        cache.set(cache_key, response, 300)
        
        if user:
            AdvancedSearch._save_search_history(user, query)
        
        return response
    
    @staticmethod
    def _search_products(query):
        from goods.models import ListModel as Product
        
        products = Product.objects.filter(
            Q(goods_name__icontains=query) |
            Q(goods_code__icontains=query) |
            Q(goods_desc__icontains=query),
            is_delete=False
        )[:20]
        
        results = []
        for p in products:
            relevance = 0
            if query.lower() in p.goods_name.lower():
                relevance += 10
            if query.lower() in p.goods_code.lower():
                relevance += 5
            
            results.append({
                'id': p.id,
                'title': p.goods_name,
                'subtitle': p.goods_code,
                'url': f'/products/{p.id}/',
                'relevance': relevance
            })
        
        return results
    
    @staticmethod
    def _search_orders(query, user):
        from orders.models import SalesOrder
        
        orders = SalesOrder.objects.filter(
            Q(order_number__icontains=query) |
            Q(customer__customer_name__icontains=query)
        )[:20]
        
        results = []
        for o in orders:
            results.append({
                'id': o.id,
                'title': f'Order {o.order_number}',
                'subtitle': f'Status: {o.status}',
                'url': f'/orders/sales/{o.id}/',
                'relevance': 8
            })
        
        return results
    
    @staticmethod
    def _search_customers(query):
        from customer.models import ListModel as Customer
        
        customers = Customer.objects.filter(
            Q(customer_name__icontains=query) |
            Q(customer_contact__icontains=query),
            is_delete=False
        )[:20]
        
        results = []
        for c in customers:
            results.append({
                'id': c.id,
                'title': c.customer_name,
                'subtitle': c.customer_contact,
                'url': f'/customers/{c.id}/',
                'relevance': 7
            })
        
        return results
    
    @staticmethod
    def _search_suppliers(query):
        from supplier.models import ListModel as Supplier
        
        suppliers = Supplier.objects.filter(
            Q(supplier_name__icontains=query) |
            Q(supplier_contact__icontains=query),
            is_delete=False
        )[:20]
        
        results = []
        for s in suppliers:
            results.append({
                'id': s.id,
                'title': s.supplier_name,
                'subtitle': s.supplier_contact,
                'url': f'/suppliers/{s.id}/',
                'relevance': 6
            })
        
        return results
    
    @staticmethod
    def _save_search_history(user, query):
        history_key = f'search_history_{user.id}'
        history = cache.get(history_key, [])
        
        if query not in history:
            history.insert(0, query)
            history = history[:10]
            cache.set(history_key, history, 86400*7)
    
    @staticmethod
    def get_search_history(user):
        return cache.get(f'search_history_{user.id}', [])
    
    @staticmethod
    def get_suggestions(query):
        if len(query) < 2:
            return []
        
        from goods.models import ListModel as Product
        
        suggestions = Product.objects.filter(
            goods_name__istartswith=query,
            is_delete=False
        ).values_list('goods_name', flat=True)[:5]
        
        return list(suggestions)
