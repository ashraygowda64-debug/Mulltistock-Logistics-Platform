from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .advanced_search import AdvancedSearch

@login_required
def global_search(request):
    query = request.GET.get('q', '')
    results = AdvancedSearch.search_all(query, request.user)
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse(results)
    
    return render(request, 'search/results.html', {
        'query': query,
        'results': results['results'],
        'count': results['count'],
        'by_category': results['by_category']
    })

@login_required
def search_suggestions(request):
    query = request.GET.get('q', '')
    suggestions = AdvancedSearch.get_suggestions(query)
    return JsonResponse({'suggestions': suggestions})

@login_required
def search_history(request):
    history = AdvancedSearch.get_search_history(request.user)
    return JsonResponse({'history': history})
