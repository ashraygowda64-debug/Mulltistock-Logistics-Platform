from django.urls import path
from . import views

app_name = 'coupons'

urlpatterns = [
    path('', views.coupon_list, name='list'),
    path('analytics/', views.coupon_analytics, name='analytics'),
]
