from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import Coupon, CouponUsage
from django.db.models import Sum, Count

@login_required
def coupon_list(request):
    now = timezone.now()
    coupons = Coupon.objects.filter(
        is_active=True,
        valid_from__lte=now,
        valid_to__gte=now
    )
    return render(request, 'coupons/list.html', {'coupons': coupons})

@login_required
def coupon_analytics(request):
    total_coupons = Coupon.objects.count()
    active_coupons = Coupon.objects.filter(is_active=True).count()
    total_redemptions = CouponUsage.objects.count()
    total_savings = CouponUsage.objects.aggregate(total=Sum('discount_amount'))['total'] or 0
    
    context = {
        'total_coupons': total_coupons,
        'active_coupons': active_coupons,
        'total_redemptions': total_redemptions,
        'total_savings': total_savings,
    }
    return render(request, 'coupons/analytics.html', context)
