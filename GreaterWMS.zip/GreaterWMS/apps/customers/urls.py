from django.urls import path
from customer import views
from customer.models import ListModel as Customer
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from permissions.decorators import require_permission
from django.db.models import Count, Sum

app_name = 'customers'

@require_permission('customers', 'view')
def customers_list(request):
    # Get filter parameters
    search = request.GET.get('search', '')
    segment = request.GET.get('segment', '')
    status = request.GET.get('status', '')
    location = request.GET.get('location', '')
    
    # Base queryset
    customers = Customer.objects.filter(is_delete=False)
    
    # Apply filters
    if search:
        from django.db.models import Q
        customers = customers.filter(
            Q(customer_name__icontains=search) |
            Q(customer_contact__icontains=search) |
            Q(customer_manager__icontains=search)
        )
    if segment:
        customers = customers.filter(customer_level=segment)
    if status:
        customers = customers.filter(customer_status=status)
    if location:
        customers = customers.filter(customer_city__icontains=location)
    
    # Prepare customer data with order info
    customer_data = []
    for customer in customers:
        customer_data.append({
            'customer': customer,
            'total_spent': 0,
            'order_count': 0,
            'last_order': None
        })
    
    # Calculate stats
    total_customers = customers.count()
    vip_customers = customers.filter(customer_level__gte=3).count()
    
    context = {
        'customers': customer_data,
        'total_customers': total_customers,
        'vip_customers': vip_customers,
        'active_orders': 0,
    }
    return render(request, 'customers/enhanced_customers.html', context)

urlpatterns = [
    path('', customers_list, name='list'),
    path('manage/', customers_list, name='manage'),
]