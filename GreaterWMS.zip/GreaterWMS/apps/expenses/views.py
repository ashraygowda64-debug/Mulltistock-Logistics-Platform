from django.shortcuts import render
from django.contrib.auth.decorators import login_required

@login_required
def expense_list(request):
    return render(request, 'expenses/list.html')

@login_required
def create_expense(request):
    return render(request, 'expenses/create.html')