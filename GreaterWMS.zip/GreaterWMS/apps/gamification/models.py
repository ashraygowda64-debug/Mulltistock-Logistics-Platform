from django.db import models
from django.contrib.auth.models import User

class UserPoints(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='points')
    points = models.IntegerField(default=0)
    level = models.IntegerField(default=1)
    badges = models.TextField(blank=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'gamification_userpoints'
    
    def add_points(self, amount, reason=''):
        self.points += amount
        self.level = (self.points // 100) + 1
        self.save()
        PointHistory.objects.create(user=self.user, points=amount, reason=reason)
    
    def __str__(self):
        return f"{self.user.username} - {self.points} pts (Level {self.level})"

class PointHistory(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='point_history')
    points = models.IntegerField()
    reason = models.CharField(max_length=200)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.points} pts - {self.reason}"

class Badge(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField()
    icon = models.CharField(max_length=50)
    points_required = models.IntegerField()
    
    def __str__(self):
        return self.name

class Challenge(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    points_reward = models.IntegerField()
    start_date = models.DateField()
    end_date = models.DateField()
    is_active = models.BooleanField(default=True)
    
    def __str__(self):
        return self.title
