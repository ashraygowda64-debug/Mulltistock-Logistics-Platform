from django.urls import path
from . import views

app_name = 'gamification'

urlpatterns = [
    path('', views.gamification_dashboard, name='dashboard'),
    path('spin/', views.spin_wheel, name='spin_wheel'),
    path('rewards/', views.rewards_catalog, name='rewards_catalog'),
    path('redeem/<str:reward_id>/', views.redeem_reward, name='redeem_reward'),
    path('track/<str:tracking_number>/', views.track_reward, name='track_reward'),
    path('leaderboard/', views.leaderboard, name='leaderboard'),
    path('challenges/', views.challenges_view, name='challenges'),
    path('api/add-points/', views.add_points_api, name='add_points_api'),
]
