from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from .models import UserPoints

from permissions.decorators import require_permission

@require_permission('gamification', 'view')
def gamification_dashboard(request):
    user_points, created = UserPoints.objects.get_or_create(
        user=request.user,
        defaults={'points': 0, 'level': 1}
    )
    
    context = {
        'points': user_points.points,
        'level': user_points.level,
        'next_level_points': user_points.level * 100,
        'progress': (user_points.points % 100)
    }
    return render(request, 'gamification/dashboard.html', context)

@require_permission('gamification', 'manage')
def add_points_api(request):
    if request.method == 'POST':
        import json
        data = json.loads(request.body)
        points = data.get('points', 0)
        reason = data.get('reason', 'Activity')
        
        user_points, created = UserPoints.objects.get_or_create(
            user=request.user,
            defaults={'points': 0, 'level': 1}
        )
        
        user_points.add_points(points, reason)
        
        return JsonResponse({'status': 'success', 'points': points, 'reason': reason})
    
    return JsonResponse({'status': 'error'})

@require_permission('gamification', 'view')
def spin_wheel(request):
    return render(request, 'gamification/spin_wheel.html')

@require_permission('gamification', 'view')
def select_reward(request):
    return render(request, 'gamification/select_reward.html')

@require_permission('gamification', 'view')
def rewards_catalog(request):
    from .reward_fulfillment import RewardFulfillment
    
    user_points = UserPoints.objects.filter(user=request.user).first()
    
    rewards = [
        {'id': 'product_1', 'name': 'Free T-Shirt', 'points': 500, 'image': 'tshirt.jpg'},
        {'id': 'product_2', 'name': 'Gift Card $10', 'points': 1000, 'image': 'giftcard.jpg'},
        {'id': 'product_3', 'name': 'Premium Mug', 'points': 300, 'image': 'mug.jpg'},
    ]
    
    return render(request, 'gamification/rewards_catalog.html', {
        'rewards': rewards,
        'user_points': user_points
    })

@require_permission('gamification', 'view')
def redeem_reward(request, reward_id):
    from .reward_fulfillment import RewardFulfillment
    from django.contrib import messages
    
    result = RewardFulfillment.redeem_reward(request.user, reward_id)
    
    if result['success']:
        messages.success(request, result['message'])
    else:
        messages.error(request, result['message'])
    
    return redirect('gamification:rewards_catalog')

@require_permission('gamification', 'view')
def track_reward(request, tracking_number):
    from .reward_fulfillment import RewardFulfillment
    
    shipment = RewardFulfillment.track_shipment(tracking_number)
    return render(request, 'gamification/track_reward.html', {'shipment': shipment})

@require_permission('gamification', 'view')
def leaderboard(request):
    return render(request, 'gamification/leaderboard.html')

@require_permission('gamification', 'view')
def challenges_view(request):
    return render(request, 'gamification/challenges.html')
