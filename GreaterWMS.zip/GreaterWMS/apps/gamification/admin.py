from django.contrib import admin
from .models import UserPoints, Badge, Challenge

try:
    @admin.register(UserPoints)
    class UserPointsAdmin(admin.ModelAdmin):
        list_display = ['user', 'points', 'level', 'updated_at']
        search_fields = ['user__username']
except:
    pass

try:
    @admin.register(Badge)
    class BadgeAdmin(admin.ModelAdmin):
        list_display = ['name', 'points_required']
except:
    pass

try:
    @admin.register(Challenge)
    class ChallengeAdmin(admin.ModelAdmin):
        list_display = ['title', 'points_reward', 'start_date', 'end_date', 'is_active']
except:
    pass
