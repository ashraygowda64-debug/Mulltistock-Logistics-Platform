from django.contrib.auth.models import User
from .models import UserPoints
from goods.models import ListModel as Product
from stock.models import StockListModel

class RewardFulfillment:
    @staticmethod
    def redeem_reward(user, reward_id, reward_type='product'):
        """Redeem reward and handle inventory/shipping"""
        user_points = UserPoints.objects.get(user=user)
        
        rewards_catalog = {
            'product_1': {'name': 'Free T-Shirt', 'points': 500, 'product_code': 'REWARD-TSHIRT'},
            'product_2': {'name': 'Gift Card $10', 'points': 1000, 'product_code': 'REWARD-GIFT10'},
            'product_3': {'name': 'Premium Mug', 'points': 300, 'product_code': 'REWARD-MUG'},
        }
        
        reward = rewards_catalog.get(reward_id)
        if not reward:
            return {'success': False, 'message': 'Invalid reward'}
        
        # Check points
        if user_points.points < reward['points']:
            return {'success': False, 'message': 'Insufficient points'}
        
        # Deduct points
        user_points.points -= reward['points']
        user_points.save()
        
        # Reduce inventory if physical product
        if reward_type == 'product':
            try:
                stock = StockListModel.objects.filter(goods_code=reward['product_code']).first()
                if stock and stock.goods_qty > 0:
                    stock.goods_qty -= 1
                    stock.save()
                    
                    # Create shipping record
                    shipping = RewardFulfillment._create_shipping(user, reward)
                    
                    # Log redemption
                    from .models import PointHistory
                    PointHistory.objects.create(
                        user=user,
                        points=-reward['points'],
                        reason=f'Redeemed: {reward[\"name\"]}'
                    )
                    
                    return {
                        'success': True,
                        'message': f'Reward redeemed! Tracking: {shipping[\"tracking_number\"]}',
                        'tracking': shipping
                    }
                else:
                    # Refund points if out of stock
                    user_points.points += reward['points']
                    user_points.save()
                    return {'success': False, 'message': 'Reward out of stock'}
            except Exception as e:
                # Refund points on error
                user_points.points += reward['points']
                user_points.save()
                return {'success': False, 'message': str(e)}
        
        return {'success': True, 'message': 'Reward redeemed successfully!'}
    
    @staticmethod
    def _create_shipping(user, reward):
        """Create shipping record for reward"""
        import random
        import string
        from datetime import datetime, timedelta
        
        tracking_number = ''.join(random.choices(string.ascii_uppercase + string.digits, k=12))
        
        shipping = {
            'tracking_number': tracking_number,
            'user': user.username,
            'reward': reward['name'],
            'status': 'processing',
            'estimated_delivery': (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d'),
            'carrier': 'Standard Shipping'
        }
        
        # Store in database (create RewardShipping model if needed)
        from django.core.cache import cache
        cache.set(f'shipping_{tracking_number}', shipping, timeout=86400*30)
        
        # Send notification
        from notifications.email_service import EmailService
        EmailService.send_email(
            to_email=user.email,
            subject=f'Reward Shipped - {reward[\"name\"]}',
            message=f'Your reward has been shipped! Tracking: {tracking_number}',
            email_type='reward_shipping'
        )
        
        return shipping
    
    @staticmethod
    def track_shipment(tracking_number):
        """Track reward shipment"""
        from django.core.cache import cache
        return cache.get(f'shipping_{tracking_number}')
