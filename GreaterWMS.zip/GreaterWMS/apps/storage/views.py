from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import StorageUnit, StorageBooking
import random
import string

from permissions.decorators import require_permission

@require_permission('storage', 'view')
def storage_list(request):
    units = StorageUnit.objects.all().order_by('-created_at')
    unit_type = request.GET.get('type')
    location = request.GET.get('location')
    
    if unit_type:
        units = units.filter(type=unit_type)
    if location:
        units = units.filter(location__icontains=location)
    
    context = {
        'units': units,
        'total_units': units.count(),
        'available_units': units.filter(status='available').count(),
        'occupied_units': units.filter(status='occupied').count(),
    }
    return render(request, 'storage/enhanced_list.html', context)

@require_permission('storage', 'view')
def storage_detail(request, unit_id):
    unit = get_object_or_404(StorageUnit, id=unit_id)
    return render(request, 'storage/detail.html', {'unit': unit})

@require_permission('storage', 'create')
def book_storage(request, unit_id):
    unit = get_object_or_404(StorageUnit, id=unit_id)
    
    if request.method == 'POST':
        start_date = request.POST.get('start_date')
        end_date = request.POST.get('end_date')
        access_code = ''.join(random.choices(string.digits, k=6))
        
        booking = StorageBooking.objects.create(
            unit=unit,
            user=request.user,
            start_date=start_date,
            end_date=end_date,
            total_amount=unit.price_per_month,
            access_code=access_code
        )
        
        unit.status = 'occupied'
        unit.access_code = access_code
        unit.save()
        
        messages.success(request, f'Storage booked! Your access code is: {access_code}')
        return redirect('storage:my_bookings')
    
    return render(request, 'storage/book.html', {'unit': unit})

@login_required
def my_bookings(request):
    bookings = StorageBooking.objects.filter(user=request.user)
    return render(request, 'storage/my_bookings.html', {'bookings': bookings})
