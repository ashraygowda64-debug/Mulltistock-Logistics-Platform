from django.urls import path
from . import views, api_views

app_name = 'storage'

urlpatterns = [
    path('', views.storage_list, name='list'),
    path('<int:unit_id>/', views.storage_detail, name='detail'),
    path('<int:unit_id>/book/', views.book_storage, name='book'),
    path('my-bookings/', views.my_bookings, name='my_bookings'),
    path('api/analytics/', api_views.analytics_data, name='analytics'),
    path('api/unit/<int:unit_id>/update/', api_views.update_unit_field, name='update_unit'),
    path('api/unit/<int:unit_id>/duplicate/', api_views.duplicate_unit, name='duplicate_unit'),
    path('api/unit/<int:unit_id>/delete/', api_views.delete_unit, name='delete_unit'),
    path('api/booking/create/', api_views.create_booking, name='create_booking'),
]
