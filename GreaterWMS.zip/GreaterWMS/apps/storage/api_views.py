from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count, Avg
from django.utils import timezone
from datetime import timedelta
from .models import StorageUnit, StorageBooking
import json
import random
import string

@login_required
@require_http_methods(["GET"])
def analytics_data(request):
    total_units = StorageUnit.objects.count()
    occupied = StorageUnit.objects.filter(status='occupied').count()
    occupancy_rate = (occupied / total_units * 100) if total_units > 0 else 0
    monthly_revenue = StorageUnit.objects.filter(status='occupied').aggregate(Sum('price_per_month'))['price_per_month__sum'] or 0
    avg_size = StorageUnit.objects.aggregate(Avg('size_sqft'))['size_sqft__avg'] or 0
    
    occupancy_trend = [72, 75, 78, 82, 85, round(occupancy_rate)]
    floor_data = []
    for floor in range(1, 5):
        count = StorageUnit.objects.filter(floor=floor).count()
        floor_data.append(count)
    
    return JsonResponse({
        'total_units': total_units,
        'occupancy_rate': round(occupancy_rate, 1),
        'monthly_revenue': float(monthly_revenue),
        'avg_size': round(avg_size, 1),
        'occupancy_trend': occupancy_trend,
        'floor_data': floor_data
    })

@login_required
@require_http_methods(["POST"])
def update_unit_field(request, unit_id):
    try:
        unit = StorageUnit.objects.get(id=unit_id)
        data = json.loads(request.body)
        field = data.get('field')
        value = data.get('value')
        
        if field == 'unit_number':
            unit.unit_number = value
        elif field == 'size_sqft':
            unit.size_sqft = value
        elif field == 'price_per_month':
            unit.price_per_month = value
        
        unit.save()
        return JsonResponse({'success': True})
    except:
        return JsonResponse({'success': False}, status=400)

@login_required
@require_http_methods(["POST"])
def duplicate_unit(request, unit_id):
    try:
        unit = StorageUnit.objects.get(id=unit_id)
        new_unit = StorageUnit.objects.create(
            unit_number=f"{unit.unit_number}-COPY",
            type=unit.type,
            size_sqft=unit.size_sqft,
            location=unit.location,
            floor=unit.floor,
            zone=unit.zone,
            status='available',
            price_per_month=unit.price_per_month,
            features=unit.features,
            is_climate_controlled=unit.is_climate_controlled
        )
        return JsonResponse({'success': True, 'id': new_unit.id})
    except:
        return JsonResponse({'success': False}, status=400)

@login_required
@require_http_methods(["DELETE"])
def delete_unit(request, unit_id):
    try:
        unit = StorageUnit.objects.get(id=unit_id)
        unit.delete()
        return JsonResponse({'success': True})
    except:
        return JsonResponse({'success': False}, status=400)

@login_required
@require_http_methods(["POST"])
def create_booking(request):
    try:
        data = json.loads(request.body)
        unit = StorageUnit.objects.get(id=data['unit_id'])
        
        duration_months = int(data['duration_months'])
        start_date = timezone.now()
        end_date = start_date + timedelta(days=duration_months*30)
        total = float(unit.price_per_month) * duration_months
        access_code = ''.join(random.choices(string.digits, k=6))
        
        booking = StorageBooking.objects.create(
            unit=unit,
            user=request.user,
            start_date=start_date,
            end_date=end_date,
            total_amount=total,
            access_code=access_code,
            status='active'
        )
        
        unit.status = 'occupied'
        unit.access_code = access_code
        unit.save()
        
        return JsonResponse({
            'success': True,
            'booking_number': f'STR-{booking.id:05d}',
            'access_code': access_code
        })
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=400)
