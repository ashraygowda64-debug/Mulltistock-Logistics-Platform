from django.db import models
from django.contrib.auth.models import User

class StorageUnit(models.Model):
    TYPE_CHOICES = [
        ('locker', 'Locker'),
        ('mini', 'Mini Warehouse'),
        ('standard', 'Standard Unit'),
        ('large', 'Large Unit'),
    ]
    
    STATUS_CHOICES = [
        ('available', 'Available'),
        ('occupied', 'Occupied'),
        ('maintenance', 'Maintenance'),
    ]
    
    unit_number = models.CharField(max_length=50, unique=True)
    type = models.CharField(max_length=20, choices=TYPE_CHOICES)
    size_sqft = models.DecimalField(max_digits=10, decimal_places=2)
    location = models.CharField(max_length=255)
    floor = models.IntegerField(default=1)
    zone = models.CharField(max_length=50)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='available')
    price_per_month = models.DecimalField(max_digits=10, decimal_places=2)
    features = models.JSONField(default=dict)
    access_code = models.CharField(max_length=20, blank=True)
    is_climate_controlled = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'storage_units'
        ordering = ['unit_number']
    
    def __str__(self):
        return f"{self.unit_number} - {self.get_type_display()}"

class StorageBooking(models.Model):
    STATUS_CHOICES = [
        ('active', 'Active'),
        ('expired', 'Expired'),
        ('cancelled', 'Cancelled'),
    ]
    
    unit = models.ForeignKey(StorageUnit, on_delete=models.CASCADE, related_name='bookings')
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default='active')
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)
    access_code = models.CharField(max_length=20)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    
    class Meta:
        db_table = 'storage_bookings'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.user.username} - {self.unit.unit_number}"
