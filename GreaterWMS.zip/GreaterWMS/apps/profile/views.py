"""
User Profile Views with Real Data
"""

from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Sum, Count
from django.http import JsonResponse
from django.contrib.auth import update_session_auth_hash

from permissions.decorators import get_user_role
from goods.models import ListModel as Product
from orders.models import Order
from customer.models import ListModel as Customer


@login_required
def user_profile(request):
    """User profile page with real database data"""
    
    user = request.user
    user_role = get_user_role(user)
    
    # Get user statistics based on role
    if user_role in ['superadmin', 'admin', 'subadmin']:
        # Admin statistics
        total_products = Product.objects.filter(is_delete=False).count()
        total_orders = Order.objects.count()
        total_customers = Customer.objects.filter(is_delete=False).count()
        
        stats = {
            'products': total_products,
            'orders': total_orders,
            'customers': total_customers
        }
    elif hasattr(user, 'seller_profile'):
        # Seller statistics
        seller_profile = user.seller_profile
        stats = {
            'total_listings': seller_profile.total_listings,
            'total_sales': seller_profile.total_sales,
            'lifetime_earnings': seller_profile.lifetime_earnings,
            'rating': seller_profile.rating
        }
    else:
        # Customer statistics
        total_orders = Order.objects.filter(customer__user=user).count()
        total_spent = Order.objects.filter(
            customer__user=user,
            status='completed'
        ).aggregate(total=Sum('total_amount'))['total'] or 0
        
        stats = {
            'orders': total_orders,
            'total_spent': total_spent
        }
    
    # User details
    profile_data = {
        'username': user.username,
        'email': user.email,
        'first_name': user.first_name,
        'last_name': user.last_name,
        'role': user_role,
        'date_joined': user.date_joined,
        'last_login': user.last_login,
    }
    
    context = {
        'profile': profile_data,
        'stats': stats,
        'user_role': user_role,
    }
    
    # Check if embed mode
    if request.GET.get('embed') == '1':
        return render(request, 'profile/user_profile_embed.html', context)
    
    return render(request, 'profile/user_profile.html', context)


@login_required
def edit_profile(request):
    """Edit user profile"""
    if request.method == 'POST':
        user = request.user
        user.first_name = request.POST.get('first_name', '')
        user.last_name = request.POST.get('last_name', '')
        user.email = request.POST.get('email', '')
        user.save()
        
        messages.success(request, 'Profile updated successfully!')
        return redirect('profile:user_profile')
    
    return render(request, 'profile/edit_profile.html', {'user': request.user})


@login_required
def upload_photo(request):
    """Upload profile photo"""
    if request.method == 'POST':
        import os
        from django.conf import settings
        import time
        import re
        from apps.users.models import UserProfile
        
        # Get or create user profile
        profile, created = UserProfile.objects.get_or_create(user=request.user)
        
        # Delete old photo from filesystem
        photo_dir = os.path.join(settings.MEDIA_ROOT, 'profile_photos')
        os.makedirs(photo_dir, exist_ok=True)
        photo_path = os.path.join(photo_dir, f"{request.user.username}.jpg")
        
        if os.path.exists(photo_path):
            os.remove(photo_path)
        
        if request.FILES.get('photo'):
            photo = request.FILES['photo']
            with open(photo_path, 'wb+') as f:
                for chunk in photo.chunks():
                    f.write(chunk)
            photo_url = f'/media/profile_photos/{request.user.username}.jpg?t={int(time.time())}'
            profile.avatar_url = photo_url
            profile.save()
            return JsonResponse({'success': True, 'photo_url': photo_url})
        
        elif request.POST.get('photo_url'):
            import urllib.parse
            photo_url = request.POST.get('photo_url').strip()
            
            # Extract actual image URL from Bing/Google search URLs
            if 'bing.com' in photo_url or 'google.com' in photo_url:
                match = re.search(r'mediaurl=([^&]+)', photo_url)
                if match:
                    photo_url = urllib.parse.unquote(match.group(1))
            
            # Decode HTML entities
            photo_url = photo_url.replace('&amp;', '&')
            
            # Validate URL format
            if not photo_url.startswith(('http://', 'https://')):
                return JsonResponse({'success': False, 'error': 'Invalid URL format'})
            
            profile.avatar_url = photo_url
            profile.save()
            return JsonResponse({'success': True, 'photo_url': photo_url})
    
    return JsonResponse({'success': False})


@login_required
def change_password(request):
    """Change user password"""
    if request.method == 'POST':
        user = request.user
        current = request.POST.get('current_password')
        new_pass = request.POST.get('new_password')
        
        if not user.check_password(current):
            return JsonResponse({'success': False, 'error': 'Current password is incorrect'})
        
        if len(new_pass) < 8:
            return JsonResponse({'success': False, 'error': 'Password must be at least 8 characters'})
        
        user.set_password(new_pass)
        user.save()
        update_session_auth_hash(request, user)
        
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})
