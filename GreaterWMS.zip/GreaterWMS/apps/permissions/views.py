from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from django.http import JsonResponse
from django.db.models import Count, Q
from .models import UserRole, PERMISSION_MATRIX
from django.core.paginator import Paginator

from permissions.decorators import require_permission

@require_permission('permissions', 'view')
def permission_list(request):
    users = User.objects.all()
    user_roles = UserRole.objects.select_related('user').all()
    return render(request, 'permissions/list.html', {'users': users, 'user_roles': user_roles})

@require_permission('permissions', 'manage')
def create_permission(request):
    if request.method == 'POST':
        user_id = request.POST.get('user_id')
        role = request.POST.get('role')
        user = User.objects.get(id=user_id)
        UserRole.objects.update_or_create(user=user, defaults={'role': role})
        messages.success(request, f'Role assigned to {user.username}')
        return redirect('permissions:list')
    
    users = User.objects.all()
    roles = UserRole.ROLE_CHOICES
    return render(request, 'permissions/create.html', {'users': users, 'roles': roles})

@require_permission('permissions', 'view')
def role_permissions(request, role):
    permissions = PERMISSION_MATRIX.get(role, {})
    return render(request, 'permissions/role_permissions.html', {'role': role, 'permissions': permissions})

@require_permission('permissions', 'view')
def user_permissions(request, user_id):
    user = get_object_or_404(User, id=user_id)
    try:
        user_role = user.role
        permissions = PERMISSION_MATRIX.get(user_role.role, {})
    except:
        user_role = None
        permissions = {}
    
    return render(request, 'permissions/user_permissions.html', {'user_obj': user, 'user_role': user_role, 'permissions': permissions})

@require_permission('permissions', 'manage')
def grant_permission(request, user_id):
    user = get_object_or_404(User, id=user_id)
    
    if request.method == 'POST':
        role = request.POST.get('role')
        UserRole.objects.update_or_create(user=user, defaults={'role': role})
        messages.success(request, f'Role {role} granted to {user.username}')
        return redirect('permissions:user_permissions', user_id=user_id)
    
    roles = UserRole.ROLE_CHOICES
    return render(request, 'permissions/grant.html', {'user_obj': user, 'roles': roles})

@require_permission('permissions', 'manage')
def revoke_permission(request, override_id):
    user = get_object_or_404(User, id=override_id)
    try:
        user.role.delete()
        messages.success(request, 'Role revoked')
    except:
        messages.error(request, 'No role to revoke')
    return redirect('permissions:list')

@require_permission('audit', 'view')
def access_logs(request):
    from audit.models import AuditLog
    logs = AuditLog.objects.select_related('user').all()[:100]
    return render(request, 'permissions/access_logs.html', {'logs': logs})

@require_permission('permissions', 'view')
def permission_matrix(request):
    roles = ['superadmin', 'admin', 'subadmin', 'manager', 'staff', 'user']
    modules = list(PERMISSION_MATRIX.get('superadmin', {}).keys())
    return render(request, 'permissions/matrix.html', {'roles': roles, 'modules': modules, 'matrix': PERMISSION_MATRIX})

@require_permission('permissions', 'view')
def check_permission_api(request):
    user_id = request.GET.get('user_id')
    module = request.GET.get('module')
    action = request.GET.get('action')
    
    user = User.objects.get(id=user_id)
    try:
        user_role = user.role
        has_permission = user_role.has_permission(module, action)
    except:
        has_permission = False
    
    return JsonResponse({'has_permission': has_permission})
