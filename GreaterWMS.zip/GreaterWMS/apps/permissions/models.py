from django.db import models
from django.contrib.auth.models import User

class UserRole(models.Model):
    ROLE_CHOICES = (
        ('superadmin', 'SuperAdmin'),
        ('admin', 'Admin (Partner)'),
        ('subadmin', 'SubAdmin (Manager)'),
        ('supervisor', 'Supervisor (SeniorStaff)'),
        ('staff', 'Staff (Employee)'),
        ('customer', 'Customer'),
        ('customer_seller', 'Customer Seller'),  # C2C marketplace seller
        ('guest', 'Guest'),
    )
    
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='role')
    role = models.CharField(max_length=20, choices=ROLE_CHOICES, default='customer')
    scope = models.JSONField(default=dict, blank=True)  # For dept/store scoping
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'user_roles'
    
    def __str__(self):
        return f"{self.user.username} - {self.get_role_display()}"
    
    def has_permission(self, module, action):
        """Check if role has permission for module action"""
        permissions = PERMISSION_MATRIX.get(self.role, {})
        module_perms = permissions.get(module, {})
        return module_perms.get(action, False)


# Comprehensive Permission Matrix for all 7 roles × all modules
PERMISSION_MATRIX = {
    'superadmin': {
        # Products & Inventory
        'products': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True, 'import': True, 'barcode': True},
        'inventory': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True, 'transfer': True, 'audit': True},
        'stock': {'view': True, 'adjust': True, 'transfer': True, 'alert': True, 'export': True, 'audit': True},
        'categories': {'view': True, 'create': True, 'edit': True, 'delete': True},
        'barcode': {'view': True, 'generate': True, 'scan': True, 'print': True},
        
        # Orders & Sales
        'orders': {'view': True, 'create': True, 'edit': True, 'delete': True, 'approve': True, 'cancel': True, 'export': True},
        'pos': {'view': True, 'create': True, 'process': True, 'refund': True},
        'quotations': {'view': True, 'create': True, 'edit': True, 'convert': True, 'delete': True},
        'returns': {'view': True, 'approve': True, 'refund': True, 'process': True},
        
        # Customers & Suppliers
        'customers': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True},
        'suppliers': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True},
        
        # Team & Users
        'users': {'view': True, 'create': True, 'edit': True, 'delete': True, 'promote': True, 'deactivate': True},
        'team': {'view': True, 'create': True, 'assign': True, 'manage': True},
        'permissions': {'view': True, 'create': True, 'edit': True, 'delete': True, 'grant': True},
        
        # Marketplace & Community
        'marketplace': {'view': True, 'buy': True, 'manage': True, 'feature': True, 'moderate': True},
        'auctions': {'view': True, 'create': True, 'bid': True, 'moderate': True, 'end': True},
        'forums': {'view': True, 'post': True, 'reply': True, 'moderate': True, 'delete': True, 'pin': True, 'ban': True},
        
        # Rentals & Storage
        'rentals': {'view': True, 'create': True, 'book': True, 'checkin': True, 'checkout': True, 'billing': True, 'export': True},
        'storage': {'view': True, 'create': True, 'assign': True, 'billing': True, 'export': True},
        'lockers': {'view': True, 'create': True, 'assign': True, 'access': True},
        
        # Financial
        'billing': {'view': True, 'create': True, 'edit': True, 'delete': True, 'pdf': True, 'export': True},
        'expenses': {'view': True, 'create': True, 'approve': True, 'export': True},
        'credit': {'view': True, 'set_limit': True, 'approve': True, 'export': True},
        'coupons': {'view': True, 'create': True, 'edit': True, 'delete': True},
        'payments': {'view': True, 'process': True, 'refund': True},
        
        # Analytics & Reports
        'analytics': {'view': True, 'create': True, 'export': True, 'configure': True},
        'reports': {'view': True, 'create': True, 'schedule': True, 'export': True, 'delete': True},
        'audit': {'view': True, 'export': True, 'purge': False},  # Purge via separate check
        
        # System & Settings
        'settings': {'view': True, 'edit': True, 'configure': True, 'backup': True, 'restore': True},
        'warehouses': {'view': True, 'create': True, 'edit': True, 'delete': True, 'configure': True},
        'automation': {'view': True, 'create': True, 'edit': True, 'delete': True},
        'webhooks': {'view': True, 'create': True, 'edit': True, 'delete': True, 'logs': True},
        'subscriptions': {'view': True, 'manage': True, 'billing': True},
        
        # Support & Messages
        'support': {'view': True, 'create': True, 'assign': True, 'resolve': True, 'delete': True},
        'messaging': {'view': True, 'send': True, 'group': True, 'moderate': True},
        'notifications': {'view': True, 'send': True, 'configure': True},
        
        # Special
        'gamification': {'view': True, 'configure': True, 'award': True},
        'mobile_api': {'view': True, 'access': True},
    },
    
    'admin': {
        # Products & Inventory
        'products': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True, 'import': True, 'barcode': True},
        'inventory': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True, 'transfer': True, 'audit': True},
        'stock': {'view': True, 'adjust': True, 'transfer': True, 'alert': True, 'export': True, 'audit': True},
        'categories': {'view': True, 'create': True, 'edit': True, 'delete': True},
        'barcode': {'view': True, 'generate': True, 'scan': True, 'print': True},
        
        # Orders & Sales  
        'orders': {'view': True, 'create': True, 'edit': True, 'delete': True, 'approve': True, 'cancel': True, 'export': True},
        'pos': {'view': True, 'create': True, 'process': True, 'refund': True},
        'quotations': {'view': True, 'create': True, 'edit': True, 'convert': True, 'delete': True},
        'returns': {'view': True, 'approve': True, 'refund': True, 'process': True},
        
        # Customers & Suppliers
        'customers': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True},
        'suppliers': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': True},
        
        # Team & Users (limited)
        'users': {'view': True, 'create': True, 'edit': True, 'delete': False, 'promote': False, 'deactivate': True},
        'team': {'view': True, 'create': True, 'assign': True, 'manage': True},
        'permissions': {'view': True, 'create': False, 'edit': True, 'delete': False, 'grant': True},
        
        # Marketplace & Community
        'marketplace': {'view': True, 'buy': True, 'manage': True, 'feature': True, 'moderate': True},
        'auctions': {'view': True, 'create': True, 'bid': True, 'moderate': True, 'end': True},
        'forums': {'view': True, 'post': True, 'reply': True, 'moderate': True, 'delete': True, 'pin': True, 'ban': True},
        
        # Rentals & Storage
        'rentals': {'view': True, 'create': True, 'book': True, 'checkin': True, 'checkout': True, 'billing': True, 'export': True},
        'storage': {'view': True, 'create': True, 'assign': True, 'billing': True, 'export': True},
        'lockers': {'view': True, 'create': True, 'assign': True, 'access': True},
        
        # Financial
        'billing': {'view': True, 'create': True, 'edit': True, 'delete': True, 'pdf': True, 'export': True},
        'expenses': {'view': True, 'create': True, 'approve': True, 'export': True},
        'credit': {'view': True, 'set_limit': True, 'approve': True, 'export': True},
        'coupons': {'view': True, 'create': True, 'edit': True, 'delete': True},
        'payments': {'view': True, 'process': True, 'refund': True},
        
        # Analytics & Reports
        'analytics': {'view': True, 'create': True, 'export': True, 'configure': False},
        'reports': {'view': True, 'create': True, 'schedule': True, 'export': True, 'delete': False},
        'audit': {'view': True, 'export': True, 'purge': False},
        
        # System & Settings (limited)
        'settings': {'view': True, 'edit': True, 'configure': False, 'backup': False, 'restore': False},
        'warehouses': {'view': True, 'create': True, 'edit': True, 'delete': False, 'configure': True},
        'automation': {'view': True, 'create': True, 'edit': True, 'delete': True},
        'webhooks': {'view': True, 'create': True, 'edit': True, 'delete': True, 'logs': True},
        'subscriptions': {'view': True, 'manage': True, 'billing': True},
        
        # Support & Messages
        'support': {'view': True, 'create': True, 'assign': True, 'resolve': True, 'delete': False},
        'messaging': {'view': True, 'send': True, 'group': True, 'moderate': True},
        'notifications': {'view': True, 'send': True, 'configure': True},
        
        # Special
        'gamification': {'view': True, 'configure': True, 'award': True},
        'mobile_api': {'view': True, 'access': True},
    },
    
    'subadmin': {
        # Products & Inventory (EDIT ONLY - no create/delete)
        'products': {'view': True, 'create': False, 'edit': True, 'delete': False, 'export': True, 'import': False, 'barcode': True},
        'inventory': {'view': True, 'create': True, 'edit': True, 'delete': False, 'export': True, 'transfer': False, 'audit': False},
        'stock': {'view': True, 'adjust': True, 'transfer': False, 'alert': True, 'export': True, 'audit': False},
        'categories': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'barcode': {'view': True, 'generate': True, 'scan': True, 'print': True},
        
        # Orders & Sales (Full access)
        'orders': {'view': True, 'create': True, 'edit': True, 'delete': False, 'approve': True, 'cancel': True, 'export': True},
        'pos': {'view': True, 'create': True, 'process': True, 'refund': True},
        'quotations': {'view': True, 'create': True, 'edit': True, 'convert': True, 'delete': False},
        'returns': {'view': True, 'approve': True, 'refund': True, 'process': True},
        
        # Customers & Suppliers (No delete)
        'customers': {'view': True, 'create': True, 'edit': True, 'delete': False, 'export': True},
        'suppliers': {'view': True, 'create': True, 'edit': True, 'delete': False, 'export': True},
        
        # Team & Users (Can create Supervisor/Staff only)
        'users': {'view': True, 'create': True, 'edit': False, 'delete': False, 'promote': False, 'deactivate': True},
        'team': {'view': True, 'create': True, 'assign': True, 'manage': True},
        'permissions': {'view': False, 'create': False, 'edit': False, 'delete': False, 'grant': False},
        
        # Marketplace & Community
        'marketplace': {'view': True, 'buy': True, 'manage': False, 'feature': False, 'moderate': False},
        'auctions': {'view': True, 'create': True, 'bid': True, 'moderate': False, 'end': False},
        'forums': {'view': True, 'post': True, 'reply': True, 'moderate': False, 'delete': False, 'pin': False, 'ban': False},
        
        # Rentals & Storage
        'rentals': {'view': True, 'create': True, 'book': True, 'checkin': True, 'checkout': True, 'billing': True, 'export': True},
        'storage': {'view': True, 'create': True, 'assign': True, 'billing': True, 'export': True},
        'lockers': {'view': True, 'create': True, 'assign': True, 'access': True},
        
        # Financial (limited - no approval power)
        'billing': {'view': True, 'create': True, 'edit': True, 'delete': False, 'pdf': True, 'export': True},
        'expenses': {'view': True, 'create': True, 'approve': False, 'export': True},
        'credit': {'view': True, 'set_limit': False, 'approve': False, 'export': False},
        'coupons': {'view': True, 'create': True, 'edit': True, 'delete': False},
        'payments': {'view': True, 'process': True, 'refund': False},
        
        # Analytics & Reports (store-scoped, no configuration)
        'analytics': {'view': True, 'create': False, 'export': True, 'configure': False},
        'reports': {'view': True, 'create': True, 'schedule': False, 'export': True, 'delete': False},
        'audit': {'view': True, 'export': False, 'purge': False},
        
        # System & Settings (View only - no modifications)
        'settings': {'view': True, 'edit': False, 'configure': False, 'backup': False, 'restore': False},
        'warehouses': {'view': True, 'create': False, 'edit': False, 'delete': False, 'configure': False},
        'automation': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'webhooks': {'view': False, 'create': False, 'edit': False, 'delete': False, 'logs': False},
        'subscriptions': {'view': True, 'manage': False, 'billing': False},
        
        # Support & Messages
        'support': {'view': True, 'create': True, 'assign': True, 'resolve': True, 'delete': False},
        'messaging': {'view': True, 'send': True, 'group': True, 'moderate': False},
        'notifications': {'view': True, 'send': True, 'configure': False},
        
        # Special
        'gamification': {'view': True, 'configure': False, 'award': False},
        'mobile_api': {'view': True, 'access': True},
    },
    
    'supervisor': {
        # Products & Inventory (VIEW ONLY - no edit/create/delete)
        'products': {'view': True, 'create': False, 'edit': False, 'delete': False, 'export': False, 'import': False, 'barcode': True},
        'inventory': {'view': True, 'create': False, 'edit': True, 'delete': False, 'export': False, 'transfer': False, 'audit': False},
        'stock': {'view': True, 'adjust': True, 'transfer': False, 'alert': True, 'export': False, 'audit': False},
        'categories': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'barcode': {'view': True, 'generate': True, 'scan': True, 'print': True},
        
        # Orders & Sales (Operational access)
        'orders': {'view': True, 'create': True, 'edit': True, 'delete': False, 'approve': False, 'cancel': True, 'export': False},
        'pos': {'view': True, 'create': True, 'process': True, 'refund': False},
        'quotations': {'view': True, 'create': True, 'edit': True, 'convert': False, 'delete': False},
        'returns': {'view': True, 'approve': False, 'refund': False, 'process': True},
        
        # Customers & Suppliers (Can add/edit, NOT delete)
        'customers': {'view': True, 'create': True, 'edit': True, 'delete': False, 'export': False},
        'suppliers': {'view': True, 'create': True, 'edit': True, 'delete': False, 'export': False},
        
        # Team & Users (View and assign only - CANNOT create)
        'users': {'view': True, 'create': False, 'edit': False, 'delete': False, 'promote': False, 'deactivate': False},
        'team': {'view': True, 'create': False, 'assign': True, 'manage': False},
        'permissions': {'view': False, 'create': False, 'edit': False, 'delete': False, 'grant': False},
        
        # Marketplace & Community
        'marketplace': {'view': True, 'buy': True, 'manage': False, 'feature': False, 'moderate': False},
        'auctions': {'view': True, 'create': True, 'bid': True, 'moderate': False, 'end': False},
        'forums': {'view': True, 'post': True, 'reply': True, 'moderate': False, 'delete': False, 'pin': False, 'ban': False},
        
        # Rentals & Storage
        'rentals': {'view': True, 'create': False, 'book': True, 'checkin': True, 'checkout': True, 'billing': False, 'export': False},
        'storage': {'view': True, 'create': False, 'assign': True, 'billing': False, 'export': False},
        'lockers': {'view': True, 'create': False, 'assign': True, 'access': True},
        
        # Financial (Submit only, no approval)
        'billing': {'view': True, 'create': True, 'edit': False, 'delete': False, 'pdf': True, 'export': False},
        'expenses': {'view': True, 'create': True, 'approve': False, 'export': False},
        'credit': {'view': False, 'set_limit': False, 'approve': False, 'export': False},
        'coupons': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'payments': {'view': True, 'process': True, 'refund': False},
        
        # Analytics & Reports (Basic operational reports only)
        'analytics': {'view': True, 'create': False, 'export': False, 'configure': False},
        'reports': {'view': True, 'create': False, 'schedule': False, 'export': False, 'delete': False},
        'audit': {'view': True, 'export': False, 'purge': False},
        
        # System & Settings (View only)
        'settings': {'view': True, 'edit': False, 'configure': False, 'backup': False, 'restore': False},
        'warehouses': {'view': True, 'create': False, 'edit': False, 'delete': False, 'configure': False},
        'automation': {'view': False, 'create': False, 'edit': False, 'delete': False},
        'webhooks': {'view': False, 'create': False, 'edit': False, 'delete': False, 'logs': False},
        'subscriptions': {'view': True, 'manage': False, 'billing': False},
        
        # Support & Messages
        'support': {'view': True, 'create': True, 'assign': False, 'resolve': True, 'delete': False},
        'messaging': {'view': True, 'send': True, 'group': True, 'moderate': False},
        'notifications': {'view': True, 'send': False, 'configure': False},
        
        # Special
        'reports': {'view': True, 'create': False, 'schedule': False, 'export': True, 'delete': False},
        'audit': {'view': False, 'export': False, 'purge': False},
        
        # System & Settings (NO access)
        'settings': {'view': False, 'edit': False, 'configure': False, 'backup': False, 'restore': False},
        'warehouses': {'view': True, 'create': False, 'edit': False, 'delete': False, 'configure': False},
        'automation': {'view': False, 'create': False, 'edit': False, 'delete': False},
        'webhooks': {'view': False, 'create': False, 'edit': False, 'delete': False, 'logs': False},
        'subscriptions': {'view': False, 'manage': False, 'billing': False},
        
        # Support & Messages
        'support': {'view': True, 'create': True, 'assign': False, 'resolve': False, 'delete': False},
        'messaging': {'view': True, 'send': True, 'group': False, 'moderate': False},
        'notifications': {'view': True, 'send': False, 'configure': False},
        
        # Special
        'gamification': {'view': True, 'configure': False, 'award': False},
        'mobile_api': {'view': True, 'access': True},
    },
    
    'customer': {
        # Products & Inventory (browse/view only)
        'products': {'view': True, 'create': False, 'edit': False, 'delete': False, 'export': False, 'import': False, 'barcode': False},
        'inventory': {'view': False, 'create': False, 'edit': False, 'delete': False, 'export': False, 'transfer': False, 'audit': False},
        'stock': {'view': False, 'adjust': False, 'transfer': False, 'alert': False, 'export': False, 'audit': False},
        'categories': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'barcode': {'view': False, 'generate': False, 'scan': False, 'print': False},
        
        # Orders & Sales (own orders only)
        'orders': {'view': True, 'create': True, 'edit': False, 'delete': False, 'approve': False, 'cancel': False, 'export': False},
        'pos': {'view': False, 'create': False, 'process': False, 'refund': False},
        'quotations': {'view': True, 'create': True, 'edit': False, 'convert': False, 'delete': False},
        'returns': {'view': True, 'approve': False, 'refund': False, 'process': True},
        
        # Customers & Suppliers (own profile only)
        'customers': {'view': False, 'create': False, 'edit': False, 'delete': False, 'export': False},
        'suppliers': {'view': False, 'create': False, 'edit': False, 'delete': False, 'export': False},
        
        # Team & Users (NO access)
        'users': {'view': False, 'create': False, 'edit': False, 'delete': False, 'promote': False, 'deactivate': False},
        'team': {'view': False, 'create': False, 'assign': False, 'manage': False},
        'permissions': {'view': False, 'create': False, 'edit': False, 'delete': False, 'grant': False},
        
        # Marketplace & Community (full consumer access)
        'marketplace': {'view': True, 'buy': True, 'manage': False, 'feature': False, 'moderate': False},
        'auctions': {'view': True, 'create': True, 'bid': True, 'moderate': False, 'end': False},
        'forums': {'view': True, 'post': True, 'reply': True, 'moderate': False, 'delete': False, 'pin': False, 'ban': False},
        
        # Rentals & Storage (book only)
        'rentals': {'view': True, 'create': False, 'book': True, 'checkin': False, 'checkout': False, 'billing': False, 'export': False},
        'storage': {'view': True, 'create': False, 'assign': False, 'billing': False, 'export': False},
        'lockers': {'view': True, 'create': False, 'assign': False, 'access': False},
        
        # Financial (view own invoices/payments only)
        'billing': {'view': True, 'create': False, 'edit': False, 'delete': False, 'pdf': True, 'export': False},
        'expenses': {'view': False, 'create': False, 'approve': False, 'export': False},
        'credit': {'view': True, 'set_limit': False, 'approve': False, 'export': False},
        'coupons': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'payments': {'view': True, 'process': True, 'refund': False},
        
        # Analytics & Reports (NO access)
        'analytics': {'view': False, 'create': False, 'export': False, 'configure': False},
        'reports': {'view': False, 'create': False, 'schedule': False, 'export': False, 'delete': False},
        'audit': {'view': False, 'export': False, 'purge': False},
        
        # System & Settings (NO access)
        'settings': {'view': False, 'edit': False, 'configure': False, 'backup': False, 'restore': False},
        'warehouses': {'view': False, 'create': False, 'edit': False, 'delete': False, 'configure': False},
        'automation': {'view': False, 'create': False, 'edit': False, 'delete': False},
        'webhooks': {'view': False, 'create': False, 'edit': False, 'delete': False, 'logs': False},
        'subscriptions': {'view': False, 'manage': False, 'billing': False},
        
        # Support & Messages (can raise tickets)
        'support': {'view': True, 'create': True, 'assign': False, 'resolve': False, 'delete': False},
        'messaging': {'view': True, 'send': True, 'group': False, 'moderate': False},
        'notifications': {'view': True, 'send': False, 'configure': False},
        
        # Special
        'gamification': {'view': True, 'configure': False, 'award': False},
        'mobile_api': {'view': True, 'access': True},
    },
    
    # Customer Seller role - C2C marketplace seller with listing capabilities
    'customer_seller': {
        # Products & Inventory (can create listings)
        'products': {'view': True, 'create': True, 'edit': True, 'delete': True, 'export': False, 'import': False, 'barcode': True},
        'inventory': {'view': True, 'create': True, 'edit': True, 'delete': False, 'export': False, 'transfer': False, 'audit': False},
        'stock': {'view': True, 'adjust': True, 'transfer': False, 'alert': False, 'export': False, 'audit': False},
        'categories': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'barcode': {'view': True, 'generate': True, 'scan': True, 'print': True},
        
        # Orders & Sales (can manage own sales)
        'orders': {'view': True, 'create': True, 'edit': True, 'delete': False, 'approve': False, 'cancel': False, 'export': True},
        'pos': {'view': True, 'create': True, 'process': True, 'refund': False},
        'quotations': {'view': True, 'create': True, 'edit': True, 'convert': False, 'delete': False},
        'returns': {'view': True, 'approve': False, 'refund': False, 'process': True},
        
        # Customers & Suppliers (view own customer list)
        'customers': {'view': True, 'create': True, 'edit': False, 'delete': False, 'export': False},
        'suppliers': {'view': False, 'create': False, 'edit': False, 'delete': False, 'export': False},
        
        # Team & Users (NO access)
        'users': {'view': False, 'create': False, 'edit': False, 'delete': False, 'promote': False, 'deactivate': False},
        'team': {'view': False, 'create': False, 'assign': False, 'manage': False},
        'permissions': {'view': False, 'create': False, 'edit': False, 'delete': False, 'grant': False},
        
        # Marketplace & Community (FULL seller access)
        'marketplace': {'view': True, 'buy': True, 'manage': True, 'feature': False, 'moderate': False},
        'auctions': {'view': True, 'create': True, 'bid': True, 'moderate': False, 'end': False},
        'forums': {'view': True, 'post': True, 'reply': True, 'moderate': False, 'delete': False, 'pin': False, 'ban': False},
        
        # Rentals & Storage (Can create listings)
        'rentals': {'view': True, 'create': True, 'book': True, 'checkin': True, 'checkout': True, 'billing': True, 'export': True},
        'storage': {'view': True, 'create': True, 'assign': True, 'billing': True, 'export': True},
        'lockers': {'view': True, 'create': True, 'assign': False, 'access': True},
        
        # Financial (Seller earnings & payouts)
        'billing': {'view': True, 'create': True, 'edit': False, 'delete': False, 'pdf': True, 'export': True},
        'expenses': {'view': True, 'create': True, 'approve': False, 'export': False},
        'credit': {'view': True, 'set_limit': False, 'approve': False, 'export': False},
        'coupons': {'view': True, 'create': True, 'edit': True, 'delete': False},
        'payments': {'view': True, 'process': True, 'refund': False},
        
        # Analytics & Reports (Own sales reports)
        'analytics': {'view': True, 'create': False, 'export': True, 'configure': False},
        'reports': {'view': True, 'create': True, 'schedule': False, 'export': True, 'delete': False},
        'audit': {'view': False, 'export': False, 'purge': False},
        
        # System & Settings (View only)
        'settings': {'view': True, 'edit': False, 'configure': False, 'backup': False, 'restore': False},
        'warehouses': {'view': True, 'create': False, 'edit': False, 'delete': False, 'configure': False},
        'automation': {'view': False, 'create': False, 'edit': False, 'delete': False},
        'webhooks': {'view': False, 'create': False, 'edit': False, 'delete': False, 'logs': False},
        'subscriptions': {'view': True, 'manage': False, 'billing': False},
        
        # Support & Messages
        'support': {'view': True, 'create': True, 'assign': False, 'resolve': False, 'delete': False},
        'messaging': {'view': True, 'send': True, 'group': False, 'moderate': False},
        'notifications': {'view': True, 'send': False, 'configure': False},
        
        # Special
        'gamification': {'view': True, 'configure': False, 'award': False},
        'mobile_api': {'view': True, 'access': True},
    },
    
    'guest': {
        # Products & Inventory (public browsing only if enabled)
        'products': {'view': True, 'create': False, 'edit': False, 'delete': False, 'export': False, 'import': False, 'barcode': False},
        'inventory': {'view': False, 'create': False, 'edit': False, 'delete': False, 'export': False, 'transfer': False, 'audit': False},
        'stock': {'view': False, 'adjust': False, 'transfer': False, 'alert': False, 'export': False, 'audit': False},
        'categories': {'view': True, 'create': False, 'edit': False, 'delete': False},
        'barcode': {'view': False, 'generate': False, 'scan': False, 'print': False},
        
        # Orders & Sales (NONE - must login)
        'orders': {'view': False, 'create': False, 'edit': False, 'delete': False, 'approve': False, 'cancel': False, 'export': False},
        'pos': {'view': False, 'create': False, 'process': False, 'refund': False},
        'quotations': {'view': False, 'create': False, 'edit': False, 'convert': False, 'delete': False},
        'returns': {'view': False, 'approve': False, 'refund': False, 'process': False},
        
        # Customers & Suppliers (NO access)
        'customers': {'view': False, 'create': False, 'edit': False, 'delete': False, 'export': False},
        'suppliers': {'view': False, 'create': False, 'edit': False, 'delete': False, 'export': False},
        
        # Team & Users (NO access)
        'users': {'view': False, 'create': False, 'edit': False, 'delete': False, 'promote': False, 'deactivate': False},
        'team': {'view': False, 'create': False, 'assign': False, 'manage': False},
        'permissions': {'view': False, 'create': False, 'edit': False, 'delete': False, 'grant': False},
        
        # Marketplace & Community (public view only)
        'marketplace': {'view': True, 'buy': False, 'manage': False, 'feature': False, 'moderate': False},
        'auctions': {'view': True, 'create': False, 'bid': False, 'moderate': False, 'end': False},
        'forums': {'view': True, 'post': False, 'reply': False, 'moderate': False, 'delete': False, 'pin': False, 'ban': False},
        
        # Rentals & Storage (NO access)
        'rentals': {'view': False, 'create': False, 'book': False, 'checkin': False, 'checkout': False, 'billing': False, 'export': False},
        'storage': {'view': False, 'create': False, 'assign': False, 'billing': False, 'export': False},
        'lockers': {'view': False, 'create': False, 'assign': False, 'access': False},
        
        # Financial (NO access)
        'billing': {'view': False, 'create': False, 'edit': False, 'delete': False, 'pdf': False, 'export': False},
        'expenses': {'view': False, 'create': False, 'approve': False, 'export': False},
        'credit': {'view': False, 'set_limit': False, 'approve': False, 'export': False},
        'coupons': {'view': False, 'create': False, 'edit': False, 'delete': False},
        'payments': {'view': False, 'process': False, 'refund': False},
        
        # Analytics & Reports (NO access)
        'analytics': {'view': False, 'create': False, 'export': False, 'configure': False},
        'reports': {'view': False, 'create': False, 'schedule': False, 'export': False, 'delete': False},
        'audit': {'view': False, 'export': False, 'purge': False},
        
        # System & Settings (NO access)
        'settings': {'view': False, 'edit': False, 'configure': False, 'backup': False, 'restore': False},
        'warehouses': {'view': False, 'create': False, 'edit': False, 'delete': False, 'configure': False},
        'automation': {'view': False, 'create': False, 'edit': False, 'delete': False},
        'webhooks': {'view': False, 'create': False, 'edit': False, 'delete': False, 'logs': False},
        'subscriptions': {'view': False, 'manage': False, 'billing': False},
        
        # Support & Messages (public contact only)
        'support': {'view': False, 'create': False, 'assign': False, 'resolve': False, 'delete': False},
        'messaging': {'view': False, 'send': False, 'group': False, 'moderate': False},
        'notifications': {'view': False, 'send': False, 'configure': False},
        
        # Special
        'gamification': {'view': False, 'configure': False, 'award': False},
        'mobile_api': {'view': False, 'access': False},
    },
}
