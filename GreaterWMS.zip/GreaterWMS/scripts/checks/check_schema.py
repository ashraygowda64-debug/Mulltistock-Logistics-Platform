import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.db import connection

with connection.cursor() as cursor:
    cursor.execute("SELECT sql FROM sqlite_master WHERE type='table' AND name='messaging_message';")
    result = cursor.fetchone()
    if result:
        print("Message Table Schema:")
        print(result[0])
        
    print("\n\nMessage Table Columns:")
    cursor.execute("PRAGMA table_info(messaging_message);")
    columns = cursor.fetchall()
    for col in columns:
        print(f"{col[1]} - {col[2]} - NOT NULL: {col[3]}")
