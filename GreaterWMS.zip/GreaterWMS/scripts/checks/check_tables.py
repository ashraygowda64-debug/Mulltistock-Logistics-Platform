#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.db import connection

with connection.cursor() as cursor:
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'messaging%'")
    tables = cursor.fetchall()
    print("Messaging Tables:")
    for table in tables:
        print(f"  - {table[0]}")
