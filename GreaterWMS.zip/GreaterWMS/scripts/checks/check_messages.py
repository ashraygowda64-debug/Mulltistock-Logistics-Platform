#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from messaging.models import Message, Conversation
from django.contrib.auth.models import User

print('=== DATABASE CHECK ===')
print(f'Total Messages: {Message.objects.count()}')
print(f'Total Conversations: {Conversation.objects.count()}')

system_user = User.objects.filter(username='system_guest_messages').first()
print(f'System User Exists: {system_user is not None}')

if system_user:
    print(f'System User Messages: {Message.objects.filter(sender=system_user).count()}')
    print(f'System User Conversations: {Conversation.objects.filter(members=system_user).count()}')

print('\nRecent Messages:')
for msg in Message.objects.order_by('-timestamp')[:10]:
    print(f'  - From: {msg.sender.username} -> Content: {msg.content[:80]}...')

print('\nAll Conversations:')
for conv in Conversation.objects.all():
    members = ', '.join([u.username for u in conv.members.all()])
    print(f'  - Conv #{conv.id}: {conv.name} | Members: {members} | Messages: {conv.messages.count()}')

print('\nTeam Members:')
team_users = User.objects.filter(is_superuser=True) | User.objects.filter(is_staff=True)
for u in team_users.distinct():
    print(f'  - {u.username} ({u.get_full_name()}) - SuperUser: {u.is_superuser}, Staff: {u.is_staff}')
