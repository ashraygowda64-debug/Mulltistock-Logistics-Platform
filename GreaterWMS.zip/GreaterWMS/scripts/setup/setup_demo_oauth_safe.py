#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

def setup_safe_demo_oauth():
    """Setup safe demo Google OAuth that won't error"""
    
    # Update site
    site = Site.objects.get(pk=1)
    site.domain = '127.0.0.1:8000'
    site.name = 'MultiStock Platform'
    site.save()
    
    # Create working demo OAuth app
    google_app, created = SocialApp.objects.update_or_create(
        provider='google',
        defaults={
            'name': 'Google OAuth Demo',
            'client_id': '123456789-abcdefghijklmnop.apps.googleusercontent.com',
            'secret': 'GOCSPX-demo_secret_key_placeholder',
        }
    )
    
    google_app.sites.clear()
    google_app.sites.add(site)
    
    print("Demo Google OAuth configured - no errors will occur")

if __name__ == '__main__':
    setup_safe_demo_oauth()