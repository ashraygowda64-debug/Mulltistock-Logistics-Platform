@echo off
echo Setting up MultiStock Platform...

echo Creating database migrations...
python manage.py makemigrations auth_system
python manage.py makemigrations multistock
python manage.py makemigrations orders
python manage.py makemigrations expenses
python manage.py makemigrations

echo Applying migrations...
python manage.py migrate

echo Creating demo users and populating data...
python manage.py create_demo_users
python manage.py populate_data

echo Setup complete!
echo.
echo.
echo ================================================
echo            MULTISTOCK USER CREDENTIALS
echo ================================================
echo.
echo TEAM LOGIN ACCOUNTS:
echo - SuperAdmin: superadmin / super123
echo - Admin: admin / admin123
echo - Sub-Admin: subadmin / sub123
echo - Manager: manager / manager123
echo - Senior Staff: seniorstaff / senior123
echo - Staff: staff / staff123
echo.
echo CUSTOMER LOGIN ACCOUNTS:
echo - Customer: customer / customer123
echo.
echo Access: http://127.0.0.1:8000/
echo ================================================
echo.
echo Starting server...
python manage.py runserver