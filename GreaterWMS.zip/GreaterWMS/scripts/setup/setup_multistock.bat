@echo off
echo ========================================
echo   MultiStock - Complete System Setup
echo ========================================
echo.

echo [1/3] Creating migrations...
python manage.py makemigrations cart wishlist orders billing

echo.
echo [2/3] Running migrations...
python manage.py migrate

echo.
echo [3/3] Creating sample data...
python create_sample_data.py

echo.
echo ========================================
echo   Setup Complete!
echo ========================================
pause
