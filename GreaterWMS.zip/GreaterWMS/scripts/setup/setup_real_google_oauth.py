#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

def setup_real_google_oauth():
    """Setup real Google OAuth - you need to provide actual credentials"""
    
    print("=== Google OAuth Setup ===")
    print("\n1. Go to: https://console.cloud.google.com/")
    print("2. Create a new project or select existing")
    print("3. Enable Google+ API")
    print("4. Go to Credentials > Create OAuth 2.0 Client ID")
    print("5. Set authorized redirect URI: http://127.0.0.1:8000/accounts/google/login/callback/")
    print("\nEnter your Google OAuth credentials:")
    
    client_id = input("Client ID: ").strip()
    client_secret = input("Client Secret: ").strip()
    
    if not client_id or not client_secret:
        print("Error: Both Client ID and Secret are required!")
        return
    
    # Update site
    site = Site.objects.get(pk=1)
    site.domain = '127.0.0.1:8000'
    site.name = 'MultiStock Platform'
    site.save()
    
    # Create or update Google OAuth app
    google_app, created = SocialApp.objects.update_or_create(
        provider='google',
        defaults={
            'name': 'Google OAuth',
            'client_id': client_id,
            'secret': client_secret,
        }
    )
    
    google_app.sites.clear()
    google_app.sites.add(site)
    
    print(f"\n✅ Google OAuth configured successfully!")
    print(f"✅ Site: {site.domain}")
    print(f"✅ Client ID: {client_id[:20]}...")
    print("\nGoogle authentication is now ready!")

if __name__ == '__main__':
    setup_real_google_oauth()