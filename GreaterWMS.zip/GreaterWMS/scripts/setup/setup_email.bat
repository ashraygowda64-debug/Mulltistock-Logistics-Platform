@echo off
echo ========================================
echo MultiStock Email Setup
echo ========================================
echo.

REM Install python-decouple
echo Installing python-decouple...
pip install python-decouple
echo.

REM Check if .env exists
if exist .env (
    echo .env file already exists!
    echo.
    choice /C YN /M "Do you want to overwrite it"
    if errorlevel 2 goto :skip_env
)

REM Create .env file
echo Creating .env file...
(
echo # MultiStock Email Configuration
echo # Generated on %date% %time%
echo.
echo # Gmail SMTP Configuration
echo EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
echo EMAIL_HOST=smtp.gmail.com
echo EMAIL_PORT=587
echo EMAIL_USE_TLS=True
echo EMAIL_HOST_USER=your-email@gmail.com
echo EMAIL_HOST_PASSWORD=your-16-char-app-password
echo DEFAULT_FROM_EMAIL=MultiStock Platform ^<your-email@gmail.com^>
) > .env

echo .env file created successfully!
echo.

:skip_env
echo ========================================
echo IMPORTANT: Configure Your Email
echo ========================================
echo.
echo 1. Open .env file in a text editor
echo 2. Replace 'your-email@gmail.com' with your Gmail address
echo 3. Get Gmail App Password:
echo    - Go to: https://myaccount.google.com/apppasswords
echo    - Enable 2-Factor Authentication first
echo    - Generate app password for "Mail"
echo    - Copy the 16-character password
echo 4. Replace 'your-16-char-app-password' with the app password
echo 5. Save the .env file
echo.
echo ========================================
echo Testing Email Configuration
echo ========================================
echo.
echo After configuring .env, run:
echo python manage.py shell
echo.
echo Then test with:
echo from django.core.mail import send_mail
echo send_mail('Test', 'Test message', 'your-email@gmail.com', ['recipient@email.com'])
echo.
echo ========================================
echo Setup Complete!
echo ========================================
pause
