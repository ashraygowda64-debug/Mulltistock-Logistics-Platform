#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import django

# Setup Django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

def setup_google_oauth():
    """Setup Google OAuth application"""
    
    # Get or create the default site
    site, created = Site.objects.get_or_create(
        pk=1,
        defaults={
            'domain': '127.0.0.1:8000',
            'name': 'MultiStock Platform'
        }
    )
    
    # Create Google OAuth app if it doesn't exist
    google_app, created = SocialApp.objects.get_or_create(
        provider='google',
        defaults={
            'name': 'Google OAuth',
            'client_id': 'your-google-client-id',
            'secret': 'your-google-client-secret',
        }
    )
    
    # Add site to the app
    google_app.sites.add(site)
    
    if created:
        print("Google OAuth app created successfully!")
        print("Please update the client_id and secret in Django admin:")
        print("   1. Go to http://127.0.0.1:8000/admin/")
        print("   2. Navigate to Social Applications")
        print("   3. Edit the Google OAuth app")
        print("   4. Add your actual Google OAuth credentials")
    else:
        print("Google OAuth app already exists")
    
    print(f"Site configured: {site.domain}")

if __name__ == '__main__':
    setup_google_oauth()