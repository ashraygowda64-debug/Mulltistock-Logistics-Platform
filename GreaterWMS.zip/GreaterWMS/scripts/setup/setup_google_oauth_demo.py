#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from allauth.socialaccount.models import SocialApp
from django.contrib.sites.models import Site

def setup_demo_google_oauth():
    """Setup demo Google OAuth with placeholder credentials"""
    
    # Update site
    site = Site.objects.get(pk=1)
    site.domain = '127.0.0.1:8000'
    site.name = 'MultiStock Platform'
    site.save()
    
    # Create or update Google OAuth app
    google_app, created = SocialApp.objects.update_or_create(
        provider='google',
        defaults={
            'name': 'Google OAuth',
            'client_id': 'demo-client-id.apps.googleusercontent.com',
            'secret': 'demo-client-secret',
        }
    )
    
    google_app.sites.clear()
    google_app.sites.add(site)
    
    print("Google OAuth configured with demo credentials")
    print("Note: Replace with real credentials for production use")

if __name__ == '__main__':
    setup_demo_google_oauth()