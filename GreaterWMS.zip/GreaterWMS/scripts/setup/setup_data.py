#!/usr/bin/env python
import os
import sys
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.contrib.auth.models import User
from goods.models import ListModel as Product
from warehouse.models import ListModel as Warehouse
from customer.models import ListModel as Customer
from supplier.models import ListModel as Supplier
from orders.models import Order, OrderItem
from multistock.models import Marketplace, Listing
import uuid
import random

def setup_platform():
    print("Setting up MultiStock Platform with sample data...")
    
    # Create sample products
    products_data = [
        {"code": "IPH15P", "desc": "iPhone 15 Pro - Premium smartphone", "price": 999.0},
        {"code": "MBP-M3", "desc": "MacBook Pro M3 - Professional laptop", "price": 1999.0},
        {"code": "SGS24", "desc": "Samsung Galaxy S24 - Android flagship", "price": 899.0},
        {"code": "DXPS13", "desc": "Dell XPS 13 - Ultrabook laptop", "price": 1299.0},
        {"code": "SWXM5", "desc": "Sony WH-1000XM5 - Noise canceling headphones", "price": 399.0},
    ]
    
    print("Creating products...")
    for p in products_data:
        product, created = Product.objects.get_or_create(
            goods_code=p["code"],
            defaults={
                'goods_desc': p["desc"],
                'goods_supplier': 'Global Tech Suppliers',
                'goods_weight': round(random.uniform(0.5, 3.0), 2),
                'goods_w': round(random.uniform(10, 30), 2),
                'goods_d': round(random.uniform(10, 30), 2),
                'goods_h': round(random.uniform(2, 15), 2),
                'goods_unit': 'pcs',
                'goods_class': 'Electronics',
                'goods_brand': 'Premium',
                'safety_stock': random.randint(10, 50),
                'goods_cost': round(p["price"] * 0.7, 2),
                'goods_price': p["price"],
                'bar_code': f"BAR{p['code']}"
            }
        )
        if created:
            print(f"  Created: {product.goods_desc}")
    
    # Create warehouses
    warehouses_data = [
        {"name": "Main Warehouse NYC", "city": "New York", "contact": "+1-555-0101"},
        {"name": "West Coast Hub", "city": "Los Angeles", "contact": "+1-555-0102"},
        {"name": "Central Distribution", "city": "Chicago", "contact": "+1-555-0103"},
    ]
    
    print("Creating warehouses...")
    for w in warehouses_data:
        warehouse, created = Warehouse.objects.get_or_create(
            warehouse_name=w["name"],
            defaults={
                'warehouse_city': w["city"],
                'warehouse_address': f'123 Industrial Blvd, {w["city"]}',
                'warehouse_contact': w["contact"],
                'warehouse_manager': 'Warehouse Manager'
            }
        )
        if created:
            print(f"  Created: {warehouse.warehouse_name}")
    
    # Create customers
    customers_data = [
        {"name": "TechCorp Solutions", "contact": "+1-555-1001"},
        {"name": "Global Retail Inc", "contact": "+1-555-1002"},
        {"name": "Manufacturing Plus", "contact": "+1-555-1003"},
    ]
    
    print("Creating customers...")
    for c in customers_data:
        customer, created = Customer.objects.get_or_create(
            customer_name=c["name"],
            defaults={
                'customer_city': 'Business District',
                'customer_address': '456 Corporate Ave',
                'customer_contact': c["contact"],
                'customer_manager': 'Account Manager',
                'customer_level': random.randint(1, 5)
            }
        )
        if created:
            print(f"  Created: {customer.customer_name}")
    
    # Create suppliers
    suppliers_data = [
        {"name": "Global Tech Suppliers", "contact": "+1-555-2001"},
        {"name": "Electronics Wholesale", "contact": "+1-555-2002"},
    ]
    
    print("Creating suppliers...")
    for s in suppliers_data:
        supplier, created = Supplier.objects.get_or_create(
            supplier_name=s["name"],
            defaults={
                'supplier_city': 'Industrial Zone',
                'supplier_address': '789 Supply Chain Rd',
                'supplier_contact': s["contact"],
                'supplier_manager': 'Supply Manager',
                'supplier_level': random.randint(1, 5)
            }
        )
        if created:
            print(f"  Created: {supplier.supplier_name}")
    
    # Create sample orders
    print("Creating sample orders...")
    admin_user = User.objects.get(username='admin')
    customers = list(Customer.objects.all())
    suppliers = list(Supplier.objects.all())
    products = list(Product.objects.all())
    
    # Create 5 sales orders
    for i in range(5):
        customer = random.choice(customers)
        order = Order.objects.create(
            order_number=f"SO-{uuid.uuid4().hex[:8].upper()}",
            order_type='sale',
            customer=customer,
            status=random.choice(['pending', 'confirmed', 'shipped']),
            created_by=admin_user,
            total_amount=0
        )
        
        # Add 1-3 items per order
        total = 0
        for _ in range(random.randint(1, 3)):
            product = random.choice(products)
            quantity = random.randint(1, 5)
            unit_price = product.goods_price
            total_price = quantity * unit_price
            total += total_price
            
            OrderItem.objects.create(
                order=order,
                product=product,
                quantity=quantity,
                unit_price=unit_price,
                total_price=total_price
            )
        
        order.total_amount = total
        order.save()
        print(f"  Created sales order: {order.order_number} (${total})")
    
    # Create 3 purchase orders
    for i in range(3):
        supplier = random.choice(suppliers)
        order = Order.objects.create(
            order_number=f"PO-{uuid.uuid4().hex[:8].upper()}",
            order_type='purchase',
            supplier=supplier,
            status=random.choice(['pending', 'confirmed']),
            created_by=admin_user,
            total_amount=0
        )
        
        # Add 2-4 items per order
        total = 0
        for _ in range(random.randint(2, 4)):
            product = random.choice(products)
            quantity = random.randint(10, 50)
            unit_price = product.goods_cost
            total_price = quantity * unit_price
            total += total_price
            
            OrderItem.objects.create(
                order=order,
                product=product,
                quantity=quantity,
                unit_price=unit_price,
                total_price=total_price
            )
        
        order.total_amount = total
        order.save()
        print(f"  Created purchase order: {order.order_number} (${total})")
    
    # Create marketplace
    print("Creating marketplace...")
    marketplace, created = Marketplace.objects.get_or_create(
        name="Electronics Hub",
        defaults={
            'description': 'Premium electronics and technology marketplace',
            'owner': admin_user,
            'is_active': True
        }
    )
    if created:
        print(f"  Created marketplace: {marketplace.name}")
    
    # Create listings
    print("Creating marketplace listings...")
    for product in products:
        listing, created = Listing.objects.get_or_create(
            product_code=product.goods_code,
            defaults={
                'marketplace': marketplace,
                'title': f"{product.goods_desc} - Available Now",
                'description': f"High-quality {product.goods_desc}. Fast shipping available.",
                'price': product.goods_price * random.uniform(0.95, 1.15),
                'quantity': random.randint(5, 100),
                'seller': admin_user,
                'is_active': True
            }
        )
        if created:
            print(f"  Created listing: {listing.title}")
    
    print("\nPlatform setup completed successfully!")
    print("\nSummary:")
    print(f"  Products: {Product.objects.count()}")
    print(f"  Warehouses: {Warehouse.objects.count()}")
    print(f"  Customers: {Customer.objects.count()}")
    print(f"  Suppliers: {Supplier.objects.count()}")
    print(f"  Orders: {Order.objects.count()}")
    print(f"  Listings: {Listing.objects.count()}")
    
    print("\nAccess URLs:")
    print("  Dashboard: http://127.0.0.1:8000/")
    print("  Orders: http://127.0.0.1:8000/orders/sales/")
    print("  Marketplace: http://127.0.0.1:8000/multistock/marketplace/")
    print("  Inventory: http://127.0.0.1:8000/inventory/")

if __name__ == "__main__":
    setup_platform()