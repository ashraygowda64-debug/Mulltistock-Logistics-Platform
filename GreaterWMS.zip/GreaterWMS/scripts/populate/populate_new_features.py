import os
import django
from datetime import datetime, timedelta

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from subscriptions.models import SubscriptionPlan
from storage.models import StorageUnit
from coupons.models import Coupon
from credit.models import CreditProfile
from customer.models import ListModel as Customer
from django.utils import timezone

print("Populating Subscription Plans...")
plans_data = [
    {'name': 'free', 'display_name': 'Free Plan', 'price': 0, 'max_products': 50, 'max_warehouses': 1, 'max_users': 2, 'max_orders_per_month': 50, 'max_storage_gb': 1},
    {'name': 'basic', 'display_name': 'Basic Plan', 'price': 29.99, 'max_products': 500, 'max_warehouses': 3, 'max_users': 10, 'max_orders_per_month': 500, 'max_storage_gb': 10},
    {'name': 'pro', 'display_name': 'Pro Plan', 'price': 99.99, 'max_products': 5000, 'max_warehouses': 10, 'max_users': 50, 'max_orders_per_month': 5000, 'max_storage_gb': 100},
    {'name': 'enterprise', 'display_name': 'Enterprise Plan', 'price': 299.99, 'max_products': 999999, 'max_warehouses': 999, 'max_users': 999, 'max_orders_per_month': 999999, 'max_storage_gb': 1000},
]

for plan_data in plans_data:
    SubscriptionPlan.objects.get_or_create(name=plan_data['name'], defaults=plan_data)
print(f"Created {len(plans_data)} subscription plans")

print("\nPopulating Storage Units...")
storage_data = [
    {'unit_number': 'L-001', 'type': 'locker', 'size_sqft': 5, 'location': 'Building A, Floor 1', 'floor': 1, 'zone': 'A1', 'price_per_month': 50, 'is_climate_controlled': False},
    {'unit_number': 'L-002', 'type': 'locker', 'size_sqft': 5, 'location': 'Building A, Floor 1', 'floor': 1, 'zone': 'A1', 'price_per_month': 50, 'is_climate_controlled': False},
    {'unit_number': 'M-001', 'type': 'mini', 'size_sqft': 50, 'location': 'Building B, Floor 2', 'floor': 2, 'zone': 'B2', 'price_per_month': 150, 'is_climate_controlled': True},
    {'unit_number': 'M-002', 'type': 'mini', 'size_sqft': 50, 'location': 'Building B, Floor 2', 'floor': 2, 'zone': 'B2', 'price_per_month': 150, 'is_climate_controlled': True},
    {'unit_number': 'S-001', 'type': 'standard', 'size_sqft': 100, 'location': 'Building C, Floor 1', 'floor': 1, 'zone': 'C1', 'price_per_month': 250, 'is_climate_controlled': True},
    {'unit_number': 'S-002', 'type': 'standard', 'size_sqft': 100, 'location': 'Building C, Floor 1', 'floor': 1, 'zone': 'C1', 'price_per_month': 250, 'is_climate_controlled': True},
    {'unit_number': 'L-001', 'type': 'large', 'size_sqft': 200, 'location': 'Building D, Floor 1', 'floor': 1, 'zone': 'D1', 'price_per_month': 450, 'is_climate_controlled': True},
    {'unit_number': 'L-002', 'type': 'large', 'size_sqft': 200, 'location': 'Building D, Floor 1', 'floor': 1, 'zone': 'D1', 'price_per_month': 450, 'is_climate_controlled': True},
]

for storage in storage_data:
    StorageUnit.objects.get_or_create(unit_number=storage['unit_number'], defaults=storage)
print(f"Created {len(storage_data)} storage units")

print("\nPopulating Coupons...")
now = timezone.now()
coupons_data = [
    {'code': 'WELCOME20', 'description': 'Welcome offer - 20% off on first order', 'discount_type': 'percentage', 'discount_value': 20, 'min_purchase': 100, 'max_uses': 100, 'valid_from': now, 'valid_to': now + timedelta(days=30)},
    {'code': 'SAVE10', 'description': 'Save 10% on all orders', 'discount_type': 'percentage', 'discount_value': 10, 'min_purchase': 50, 'max_uses': 0, 'valid_from': now, 'valid_to': now + timedelta(days=60)},
    {'code': 'FLAT50', 'description': 'Flat $50 off on orders above $200', 'discount_type': 'fixed', 'discount_value': 50, 'min_purchase': 200, 'max_uses': 50, 'valid_from': now, 'valid_to': now + timedelta(days=45)},
    {'code': 'MEGA25', 'description': 'Mega sale - 25% off', 'discount_type': 'percentage', 'discount_value': 25, 'min_purchase': 500, 'max_uses': 200, 'valid_from': now, 'valid_to': now + timedelta(days=15)},
]

for coupon in coupons_data:
    Coupon.objects.get_or_create(code=coupon['code'], defaults=coupon)
print(f"Created {len(coupons_data)} coupons")

print("\nPopulating Credit Profiles...")
customers = Customer.objects.all()[:5]
for customer in customers:
    CreditProfile.objects.get_or_create(
        customer=customer,
        defaults={
            'credit_limit': 10000,
            'available_credit': 10000,
            'used_credit': 0,
            'risk_level': 'low',
            'payment_terms_days': 30
        }
    )
print(f"Created credit profiles for {customers.count()} customers")

print("\nAll data populated successfully!")
