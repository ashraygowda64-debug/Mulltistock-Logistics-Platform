"""
Populate real data for MultiStock WMS:
- 70 products across categories with images
- Suppliers linked via names
- Stock entries with quantities and images
- 20 customers (New/Regular/VIP mapped to levels)
- Orders with items, totals, statuses
- Marketplace listings for products

Safe to run multiple times (idempotent by keys like codes/emails).
"""
import os
import io
import sys
import json
import random
import string
import urllib.request
from datetime import datetime, timedelta

import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.contrib.auth.models import User
from goods.models import ListModel as Product
from supplier.models import ListModel as Supplier
from customer.models import ListModel as Customer
from stock.models import StockListModel
from orders.models import Order, OrderItem
from multistock.models import Marketplace, Listing
from django.db import transaction

MEDIA_DIR = os.path.join(os.getcwd(), 'media', 'stock_images')
os.makedirs(MEDIA_DIR, exist_ok=True)

CATEGORIES = {
    'Electronics': [
        ('Wireless Earbuds', 'High-fidelity Bluetooth 5.3 earbuds with noise cancellation'),
        ('Smartphone 6.5"', '1080p OLED display, 128GB storage, 5G ready'),
        ('Portable Power Bank', '20,000mAh fast charging USB-C PD'),
        ('Gaming Mouse', 'Ergonomic RGB gaming mouse, 16000 DPI'),
        ('4K Action Camera', 'Waterproof 30m, EIS stabilization, 60fps'),
        ('Bluetooth Speaker', 'Portable speaker with deep bass and 12h battery'),
        ('Smartwatch Pro', 'AMOLED, GPS, SpO2, 7-day battery')
    ],
    'Apparel': [
        ('Hoodie Classic', 'Premium cotton hoodie, relaxed fit'),
        ('Running Shoes', 'Lightweight breathable shoes for training'),
        ('Denim Jacket', 'Washed denim with classic cut'),
        ('Athletic T-Shirt', 'Moisture-wicking performance tee'),
        ('Chino Pants', 'Slim fit chinos, stretch fabric'),
        ('Baseball Cap', 'Adjustable cap with curved brim'),
        ('Winter Parka', 'Insulated parka with hood')
    ],
    'Tools': [
        ('Cordless Drill', '18V lithium drill with 2 batteries'),
        ('Toolkit 46pcs', 'Chrome-vanadium hand toolkit set'),
        ('Laser Measure', 'Accurate up to 50m, backlit display'),
        ('Soldering Iron', 'Temperature controlled 60W soldering kit'),
        ('Angle Grinder', '850W grinder with guard'),
        ('Stud Finder', 'Wall scanner for AC and studs'),
        ('Work Gloves', 'Cut-resistant nitrile gloves')
    ],
    'Stationery': [
        ('Notebook A5', 'Hardcover dotted notebook, 200 pages'),
        ('Gel Pen Set', '0.5mm smooth ink pens, 12-pack'),
        ('Desk Organizer', 'Metal mesh organizer tray'),
        ('Mechanical Pencil', '0.7mm with eraser, metal body'),
        ('Highlighter Set', 'Pastel color chisel tip, 6-pack'),
        ('Stapler Heavy-Duty', '50-sheet capacity office stapler'),
        ('Planner 2025', 'Weekly planner with tabs')
    ],
    'Home': [
        ('LED Desk Lamp', 'Dimmable, USB charging, adjustable arm'),
        ('Air Purifier', 'HEPA H13 filter, quiet operation'),
        ('Electric Kettle', '1.7L stainless steel, auto shut-off'),
        ('Vacuum Cleaner', 'Bagless cyclonic vacuum, 1600W'),
        ('Memory Foam Pillow', 'Ergonomic neck support'),
        ('Throw Blanket', 'Ultra-soft fleece, 150x200cm'),
        ('Food Storage Set', 'BPA-free airtight containers, 12pcs')
    ],
    'Sports': [
        ('Yoga Mat', 'Non-slip TPE mat, 6mm'),
        ('Dumbbell Set', 'Adjustable 20kg weight set'),
        ('Cycling Helmet', 'Lightweight with ventilation'),
        ('Resistance Bands', 'Set of 5 with door anchor'),
        ('Skipping Rope', 'Adjustable steel cable rope'),
        ('Football Size 5', 'Match-quality PU ball'),
        ('Hiking Backpack', '35L waterproof daypack')
    ],
    'Beauty': [
        ('Hair Dryer', '2000W ionic dryer with diffuser'),
        ('Facial Cleanser', 'Gentle foaming cleanser 200ml'),
        ('Makeup Brush Set', '12-piece synthetic brushes'),
        ('Electric Toothbrush', 'Sonic brush with 5 modes'),
        ('Nail Kit', 'UV LED lamp with gel set'),
        ('Beard Trimmer', 'Cordless stainless blades'),
        ('Skincare Serum', 'Vitamin C 20% brightening')
    ],
    'Automotive': [
        ('Car Vacuum', 'Portable 120W vacuum for car'),
        ('Tire Inflator', 'Digital portable air compressor'),
        ('Dash Cam', '1080p wide-angle dashboard camera'),
        ('Car Phone Mount', 'MagSafe-compatible vent mount'),
        ('LED Headlights', 'H11 6000K LED bulbs pair'),
        ('Jump Starter', '1000A 12V battery booster'),
        ('Seat Organizer', 'Backseat storage organizer')
    ],
    'Toys': [
        ('Building Blocks', '120-piece educational block set'),
        ('RC Car', '2.4Ghz off-road radio car'),
        ('Plush Bear', 'Soft plush toy 40cm'),
        ('Puzzle 1000pcs', 'Scenic jigsaw puzzle'),
        ('STEM Kit', 'Robotics kit for kids 8+'),
        ('Doll House Set', 'Wooden miniature house'),
        ('Kite', 'Ripstop nylon delta kite')
    ],
    'Books': [
        ('Data Science 101', 'Beginner guide to data science'),
        ('Modern Python', 'Best practices and patterns'),
        ('Leadership Principles', 'Habits of effective leaders'),
        ('Creative Design', 'Visual design fundamentals'),
        ('Investing Basics', 'Personal finance and investing'),
        ('Mindfulness Daily', 'Practical mindfulness exercises'),
        ('Startup Playbook', 'Build and scale startups')
    ]
}

def image_url_for(category: str, seed: str) -> str:
    # Stable, license-free placeholder images
    return f"https://picsum.photos/seed/{category}-{seed}/640/640"

SUPPLIERS = [
    ('NovaElectro Pvt Ltd', 'Mumbai', 'A-102 Tech Park, Mumbai', '+91-22-4000-1234', 'Arjun Mehta', 5),
    ('UrbanWear Co', 'Delhi', '12 Connaught Place, Delhi', '+91-11-4555-6789', 'Priya Sharma', 4),
    ('ProTools India', 'Pune', '88 Industrial Area, Pune', '+91-20-3000-2222', 'Rohit Patil', 5),
    ('DeskMate Stationers', 'Bengaluru', '45 MG Road, BLR', '+91-80-2345-7890', 'Anita Rao', 3),
    ('HomeEase Appliances', 'Chennai', '7 Gandhi Nagar, Chennai', '+91-44-2211-4455', 'S. Narayanan', 4),
    ('FitNation Sports', 'Hyderabad', '21 Banjara Hills, HYD', '+91-40-3344-5566', 'Imran Khan', 4),
    ('GlowCare Beauty', 'Kolkata', '9 Park Street, Kolkata', '+91-33-2233-1122', 'Riya Sen', 3),
    ('AutoPro Components', 'Jaipur', '66 MI Road, Jaipur', '+91-141-2500-3300', 'Vikram Singh', 4),
    ('ToyCraft', 'Ahmedabad', '4 SG Highway, Ahmedabad', '+91-79-2567-3344', 'Neha Patel', 3),
    ('BookWorld', 'Lucknow', '15 Hazratganj, Lucknow', '+91-522-2987-1122', 'Aditya Verma', 4)
]

CUSTOMERS = [
    # name, city, address, contact, manager, tier(New=1, Regular=2, VIP=3)
    ('Aarav Gupta', 'Delhi', '11, CP, Delhi', '+91-98100-12345', 'Self', 1),
    ('Isha Verma', 'Mumbai', '23, Bandra West, Mumbai', '+91-98200-34567', 'Self', 2),
    ('Rohan Mehta', 'Bengaluru', '5, Indiranagar, BLR', '+91-98450-11122', 'Self', 2),
    ('Neha Sharma', 'Pune', '44, Karve Nagar, Pune', '+91-99220-33344', 'Self', 3),
    ('Arjun Singh', 'Chennai', '8, Adyar, Chennai', '+91-99400-55566', 'Self', 2),
    ('Priya Nair', 'Hyderabad', '12, Jubilee Hills, HYD', '+91-99890-77788', 'Self', 3),
    ('Karan Patel', 'Ahmedabad', '3, Satellite, Ahmedabad', '+91-99740-99900', 'Self', 2),
    ('Simran Kaur', 'Chandigarh', '2, Sector 17, CHD', '+91-98765-43210', 'Self', 1),
    ('Vikram Rao', 'Jaipur', '1, Vaishali Nagar, Jaipur', '+91-98290-22334', 'Self', 2),
    ('Ananya Das', 'Kolkata', '14, Salt Lake, Kolkata', '+91-98300-55667', 'Self', 1),
    ('Rahul Jain', 'Delhi', '20, Saket, Delhi', '+91-98110-66778', 'Self', 2),
    ('Meera Pillai', 'Kochi', '9, MG Road, Kochi', '+91-98950-77889', 'Self', 3),
    ('Aditya Gupta', 'Indore', '7, Palasia, Indore', '+91-99816-88990', 'Self', 2),
    ('Pooja Shah', 'Surat', '6, Vesu, Surat', '+91-99250-99101', 'Self', 1),
    ('Nikhil Rao', 'Nagpur', '17, Civil Lines, Nagpur', '+91-98230-11223', 'Self', 2),
    ('Tanya Kapoor', 'Noida', '3, Sector 18, Noida', '+91-98710-22334', 'Self', 3),
    ('Harsh Vardhan', 'Gurgaon', '45, DLF Phase 3, Gurugram', '+91-98990-33445', 'Self', 2),
    ('Ritika Bose', 'Bhopal', '11, Arera Colony, Bhopal', '+91-97555-44556', 'Self', 2),
    ('Devansh Roy', 'Patna', '8, Boring Road, Patna', '+91-93080-55667', 'Self', 1),
    ('Aniket Kulkarni', 'Nashik', '10, College Rd, Nashik', '+91-99703-66778', 'Self', 2),
]

STATUS_CHOICES = ['pending','confirmed','processing','shipped','delivered']


def download_image(url: str, dest_path: str):
    try:
        if not os.path.exists(dest_path):
            # Use unsplash with parameters to keep size small
            if '?' not in url:
                url = url + '?w=640&h=640&fit=crop'
            urllib.request.urlretrieve(url, dest_path)
        return True
    except Exception as e:
        print('Image download failed:', url, e)
        return False


def sku_from_name(name: str) -> str:
    base = ''.join(ch for ch in name.upper() if ch.isalnum())[:8]
    rand = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
    return f"{base}-{rand}"


def pick_supplier(category: str) -> Supplier:
    # Distribute suppliers by index
    idx = abs(hash(category)) % len(SUPPLIERS)
    sup_name = SUPPLIERS[idx][0]
    sup = Supplier.objects.filter(supplier_name=sup_name, is_delete=False).first()
    if sup:
        return sup
    # Fallback to any
    return Supplier.objects.filter(is_delete=False).first()


@transaction.atomic
def populate_suppliers():
    created = 0
    for name, city, addr, phone, manager, level in SUPPLIERS:
        sup, was_created = Supplier.objects.get_or_create(
            supplier_name=name,
            defaults={
                'supplier_city': city,
                'supplier_address': addr,
                'supplier_contact': phone,
                'supplier_manager': manager,
                'supplier_level': level,
                'is_delete': False,
            }
        )
        if was_created:
            created += 1
    print(f"Suppliers ensured: {Supplier.objects.count()} (created {created})")


@transaction.atomic
def populate_products_and_stock():
    # Create or ensure marketplace
    owner = User.objects.filter(is_superuser=True).first() or User.objects.first()
    market, _ = Marketplace.objects.get_or_create(name='Global MultiStock', defaults={'description': 'Official marketplace','owner': owner})

    total_needed = 70
    per_category = max(1, total_needed // len(CATEGORIES))
    products_created = 0
    multistock_marks_per_cat = {}

    for cat, items in CATEGORIES.items():
        # ensure we have enough items; repeat if necessary
        pool = items.copy()
        while len(pool) < per_category:
            pool += items
        random.shuffle(pool)
        chosen = pool[:per_category]

        # Choose 2-3 Multistock-marked products per category
        mcount = random.randint(2, 3)
        multistock_marks = set(random.sample(range(len(chosen)), mcount))
        multistock_marks_per_cat[cat] = mcount

        for idx, (name, desc) in enumerate(chosen):
            sku = sku_from_name(name + cat)
            price = round(random.uniform(5, 500), 2)
            supplier = pick_supplier(cat)

            prod, p_created = Product.objects.get_or_create(
                goods_code=sku,
                defaults={
                    'goods_desc': name,
                    'goods_supplier': supplier.supplier_name,
                    'goods_weight': 0,
                    'goods_w': 0,
                    'goods_d': 0,
                    'goods_h': 0,
                    'goods_unit': 'pcs',
                    'goods_class': cat,
                    'goods_brand': 'Multistock' if idx in multistock_marks else 'Generic',
                    'safety_stock': 5,
                    'goods_cost': float(max(1.0, price * 0.6)),
                    'goods_price': float(price),
                }
            )

            # Stock
            qty = random.randint(0, 120)
            stock, s_created = StockListModel.objects.get_or_create(
                goods_code=sku,
                defaults={
                    'goods_desc': name,
                    'goods_qty': qty,
                    'onhand_stock': qty,
                    'can_order_stock': max(0, qty - random.randint(0, 10)),
                    'ordered_stock': random.randint(0, 10),
                    'damage_stock': random.randint(0, 3),
                    'supplier': supplier.supplier_name,
                    'openid': owner.username if owner else 'system',
                }
            )

            # Image
            fname = f"{sku}.jpg"
            fpath = os.path.join(MEDIA_DIR, fname)
            img_url = image_url_for(cat, sku)
            if download_image(img_url, fpath):
                rel = os.path.join('stock_images', fname)
                if not stock.goods_image or str(stock.goods_image) != rel:
                    stock.goods_image = rel
                    stock.save()

            # Marketplace listing
            Listing.objects.get_or_create(
                marketplace=market,
                product_code=sku,
                defaults={
                    'title': name,
                    'description': desc,
                    'price': price,
                    'quantity': qty if qty > 0 else 10,
                    'category': cat,
                    'seller': owner,
                }
            )

            if p_created:
                products_created += 1
    print(f"Products ensured: {Product.objects.filter(is_delete=False).count()} (created ~{products_created})")


@transaction.atomic
def populate_customers_and_users():
    created_users = 0
    for idx, (name, city, addr, phone, manager, tier) in enumerate(CUSTOMERS):
        cust, c_created = Customer.objects.get_or_create(
            customer_name=name,
            defaults={
                'customer_city': city,
                'customer_address': addr,
                'customer_contact': phone,
                'customer_manager': manager,
                'customer_level': tier,
                'is_delete': False,
            }
        )
        # Create auth user for some customers
        username = f"cust{idx+1}"
        email = f"{username}@example.com"
        user = User.objects.filter(username=username).first()
        if not user:
            user = User.objects.create_user(username=username, email=email, password='Passw0rd!')
            created_users += 1
    print(f"Customers ensured: {Customer.objects.count()} (users created {created_users})")


@transaction.atomic
def populate_orders():
    customers = list(Customer.objects.all())
    products = list(Product.objects.filter(is_delete=False)[:200])
    if not customers or not products:
        print('Skip orders: missing customers or products')
        return

    created_by = User.objects.filter(is_superuser=True).first() or User.objects.first()
    orders_to_create = []
    order_items_to_create = []

    for i in range(60):
        cust = random.choice(customers)
        status = random.choice(STATUS_CHOICES)
        order_number = f"ORD-{datetime.now().strftime('%Y%m%d')}-{i+1:04d}"
        delivery_fee = random.choice([0, 40, 99])

        order = Order(
            order_number=order_number,
            order_type='sale',
            customer=cust,
            status=status,
            payment_status='paid' if status in ['shipped','delivered'] else 'unpaid',
            total_amount=0,
            discount_amount=0,
            delivery_fee=delivery_fee,
            grand_total=0,
            delivery_address=cust.customer_address,
            delivery_phone=cust.customer_contact,
            payment_method=random.choice(['COD','Card','UPI']),
            created_by=created_by,
        )
        orders_to_create.append(order)

    # Bulk create orders to avoid signals and per-save side effects
    created_orders = Order.objects.bulk_create(orders_to_create)

    for order in created_orders:
        total = 0
        items = random.sample(products, k=random.randint(1, 3))
        for p in items:
            qty = random.randint(1, 5)
            price = float(p.goods_price or 0)
            order_items_to_create.append(OrderItem(
                order=order,
                product=p,
                product_name=p.goods_desc,
                quantity=qty,
                unit_price=price,
                total_price=qty*price,
                seller=p.goods_supplier,
            ))
            total += qty*price
        order.total_amount = total
        order.grand_total = total + order.delivery_fee - order.discount_amount

    OrderItem.objects.bulk_create(order_items_to_create)
    # Update totals in bulk
    Order.objects.bulk_update(created_orders, ['total_amount', 'grand_total'])
    print(f"Orders created: {len(created_orders)}")


def main():
    populate_suppliers()
    populate_products_and_stock()
    populate_customers_and_users()
    populate_orders()
    print('\n✅ Real system data population complete.')

if __name__ == '__main__':
    main()
