import os
import django
import random
from datetime import datetime, timedelta
from decimal import Decimal

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.contrib.auth.models import User
from goods.models import ListModel as Product
from customer.models import ListModel as Customer
from supplier.models import ListModel as Supplier
from warehouse.models import ListModel as Warehouse
from orders.models import Order, OrderItem
from multistock.models import Listing

print("Creating Complete Database...")

# Create Warehouses
warehouses = [
    {"warehouse_name": "Main Warehouse", "warehouse_city": "Mumbai", "warehouse_address": "Andheri East", "warehouse_contact": "+91 22 1234 5678", "warehouse_manager": "Rajesh Kumar"},
    {"warehouse_name": "North Hub", "warehouse_city": "Delhi", "warehouse_address": "Connaught Place", "warehouse_contact": "+91 11 2345 6789", "warehouse_manager": "Priya Sharma"},
    {"warehouse_name": "South Center", "warehouse_city": "Bangalore", "warehouse_address": "Whitefield", "warehouse_contact": "+91 80 3456 7890", "warehouse_manager": "Amit Patel"},
]
for w in warehouses:
    Warehouse.objects.create(**w, creater="admin")
print(f"Created {len(warehouses)} warehouses")

# Create Suppliers
suppliers_data = [
    {"supplier_name": "Tech Solutions Ltd", "supplier_city": "Mumbai", "supplier_address": "BKC", "supplier_contact": "+91 98765 43210", "supplier_manager": "Vikram Singh"},
    {"supplier_name": "Fashion Hub Pvt Ltd", "supplier_city": "Delhi", "supplier_address": "Saket", "supplier_contact": "+91 98765 43211", "supplier_manager": "Neha Gupta"},
    {"supplier_name": "Electronics World", "supplier_city": "Bangalore", "supplier_address": "MG Road", "supplier_contact": "+91 98765 43212", "supplier_manager": "Suresh Reddy"},
    {"supplier_name": "Home Essentials Co", "supplier_city": "Pune", "supplier_address": "Koregaon Park", "supplier_contact": "+91 98765 43213", "supplier_manager": "Anjali Desai"},
    {"supplier_name": "Sports Arena", "supplier_city": "Chennai", "supplier_address": "T Nagar", "supplier_contact": "+91 98765 43214", "supplier_manager": "Karthik Raj"},
]
suppliers = []
for s in suppliers_data:
    suppliers.append(Supplier.objects.create(**s, supplier_level=1))
print(f"Created {len(suppliers)} suppliers")

# Product Categories and Data
categories = {
    "Electronics": [
        ("iPhone 15 Pro Max", "Latest Apple flagship smartphone", 134900, "TECH-APL-15PM"),
        ("Samsung Galaxy S24 Ultra", "Premium Android smartphone", 124999, "TECH-SAM-S24U"),
        ("MacBook Pro M3", "Professional laptop", 199900, "TECH-APL-MBP"),
        ("Dell XPS 15", "High-performance laptop", 149900, "TECH-DEL-XPS15"),
        ("Sony WH-1000XM5", "Noise cancelling headphones", 29990, "TECH-SON-WH5"),
        ("iPad Pro 12.9", "Professional tablet", 109900, "TECH-APL-IPAD"),
        ("Samsung 55 QLED TV", "4K Smart TV", 89999, "TECH-SAM-TV55"),
        ("Canon EOS R6", "Mirrorless camera", 219900, "TECH-CAN-R6"),
        ("Bose SoundLink", "Portable speaker", 14990, "TECH-BOS-SL"),
        ("Apple Watch Series 9", "Smartwatch", 44900, "TECH-APL-AW9"),
        ("JBL Flip 6", "Bluetooth speaker", 9999, "TECH-JBL-F6"),
        ("Logitech MX Master 3", "Wireless mouse", 8995, "TECH-LOG-MX3"),
        ("Kindle Paperwhite", "E-reader", 13999, "TECH-AMZ-KPW"),
        ("GoPro Hero 12", "Action camera", 44999, "TECH-GOP-H12"),
    ],
    "Fashion": [
        ("Nike Air Max 270", "Running shoes", 12995, "FASH-NIK-AM270"),
        ("Adidas Ultraboost", "Performance sneakers", 16999, "FASH-ADI-UB"),
        ("Levi's 501 Jeans", "Classic denim", 4999, "FASH-LEV-501"),
        ("Zara Cotton Shirt", "Casual wear", 2999, "FASH-ZAR-CS"),
        ("H&M Summer Dress", "Women's clothing", 3499, "FASH-HM-SD"),
        ("Puma Track Suit", "Sports wear", 5999, "FASH-PUM-TS"),
        ("Ray-Ban Aviator", "Sunglasses", 8999, "FASH-RAY-AV"),
        ("Fossil Gen 6 Watch", "Smartwatch", 24995, "FASH-FOS-G6"),
        ("Tommy Hilfiger Polo", "Men's shirt", 4499, "FASH-TOM-PL"),
        ("Calvin Klein Jeans", "Premium denim", 6999, "FASH-CAL-JN"),
        ("Reebok Sports Shoes", "Training shoes", 4999, "FASH-REE-SS"),
        ("Woodland Boots", "Outdoor footwear", 7999, "FASH-WOD-BT"),
        ("Allen Solly Blazer", "Formal wear", 8999, "FASH-ALL-BL"),
        ("Van Heusen Shirt", "Business casual", 2999, "FASH-VAN-SH"),
    ],
    "Home & Kitchen": [
        ("Philips Air Purifier", "HEPA filter", 18999, "HOME-PHI-AP"),
        ("Bajaj Ceiling Fan", "Energy efficient", 3499, "HOME-BAJ-CF"),
        ("Prestige Cooker 5L", "Pressure cooker", 2499, "HOME-PRE-PC5"),
        ("Havells Iron", "Steam iron", 1999, "HOME-HAV-IR"),
        ("Godrej Almirah", "Steel storage", 12499, "HOME-GOD-AL"),
        ("IKEA Malm Bed", "Queen size bed", 15999, "HOME-IKE-MALM"),
        ("Nilkamal Chair", "Plastic chair", 899, "HOME-NIL-CH"),
        ("Cello Water Bottle", "1 liter", 299, "HOME-CEL-WB"),
        ("Milton Tiffin", "Lunch box", 599, "HOME-MIL-TF"),
        ("Pigeon Gas Stove", "2 burner", 3999, "HOME-PIG-GS"),
        ("Butterfly Mixer", "750W grinder", 4499, "HOME-BUT-MX"),
        ("Usha Table Fan", "High speed", 1999, "HOME-USH-TF"),
        ("Wipro LED Bulb", "9W pack of 4", 399, "HOME-WIP-LED"),
        ("Anchor Socket", "Power strip", 499, "HOME-ANC-PS"),
    ],
    "Sports & Fitness": [
        ("Cosco Cricket Bat", "Kashmir willow", 7999, "SPRT-COS-CB"),
        ("Yonex Badminton Racket", "Professional", 8999, "SPRT-YON-BR"),
        ("Adidas Football Size 5", "Match ball", 2499, "SPRT-ADI-FB5"),
        ("Decathlon Yoga Mat", "6mm thick", 1999, "SPRT-DEC-YM"),
        ("Nivia Gym Bag", "Sports bag", 1299, "SPRT-NIV-GB"),
        ("Strauss Dumbbell Set", "10kg pair", 2999, "SPRT-STR-DB"),
        ("Vector X Cricket Ball", "Leather", 599, "SPRT-VEC-CB"),
        ("Kalenji Running Shoes", "Trail running", 3999, "SPRT-KAL-RS"),
        ("Domyos Resistance Band", "Fitness band", 799, "SPRT-DOM-RB"),
        ("Btwin Cycle 26T", "Mountain bike", 14999, "SPRT-BTW-CY"),
        ("Kipsta Tennis Racket", "Beginner", 2499, "SPRT-KIP-TR"),
        ("Artengo Shuttlecock", "Pack of 6", 499, "SPRT-ART-SC"),
        ("Tarmak Basketball", "Size 7", 1999, "SPRT-TAR-BB"),
        ("Quechua Backpack", "30L hiking", 2999, "SPRT-QUE-BP"),
    ],
    "Books & Stationery": [
        ("Rich Dad Poor Dad", "Robert Kiyosaki", 399, "BOOK-RDP-RK"),
        ("The Alchemist", "Paulo Coelho", 299, "BOOK-ALC-PC"),
        ("Atomic Habits", "James Clear", 499, "BOOK-ATM-JC"),
        ("NCERT Class 12 Physics", "Textbook", 245, "BOOK-NCR-P12"),
        ("Parker Jotter Pen", "Blue ink", 299, "BOOK-PAR-JP"),
        ("Classmate Notebook", "Single line 172 pages", 45, "BOOK-CLA-NB"),
        ("Apsara Pencil Box", "Geometry set", 199, "BOOK-APS-PB"),
        ("Camlin Sketch Pens", "24 colors", 299, "BOOK-CAM-SP"),
        ("Fevicol Glue", "100ml", 49, "BOOK-FEV-GL"),
        ("Staedtler Eraser", "Pack of 2", 99, "BOOK-STA-ER"),
        ("Faber-Castell Colors", "36 shades", 599, "BOOK-FAB-CL"),
        ("Oxford Dictionary", "English", 799, "BOOK-OXF-DIC"),
        ("HP Printer Paper", "A4 500 sheets", 399, "BOOK-HP-PP"),
        ("Post-it Notes", "Sticky notes", 199, "BOOK-POS-SN"),
    ],
}

# Create Products
products = []
product_count = 0
multistock_products = []

for category, items in categories.items():
    supplier = random.choice(suppliers)
    for i, (name, desc, price, sku) in enumerate(items):
        stock = random.randint(50, 500)
        product = Product.objects.create(
            goods_code=sku,
            goods_desc=name,
            goods_supplier=supplier.supplier_name,
            goods_weight=random.uniform(0.1, 5.0),
            goods_w=random.uniform(10, 50),
            goods_d=random.uniform(10, 50),
            goods_h=random.uniform(5, 30),
            goods_unit="pcs",
            goods_class=category,
            goods_brand=name.split()[0],
            safety_stock=10,
            goods_cost=price * 0.7,
            goods_price=price,
            bar_code=sku,
            min_stock_level=20,
            reorder_point=30
        )
        products.append(product)
        product_count += 1
        
        # Mark 2-3 products per category for Multistock
        if i < 3:
            multistock_products.append(product)

print(f"Created {product_count} products across {len(categories)} categories")
print(f"Created {len(multistock_products)} marketplace listings")

# Create Customers
customer_types = [
    ("New", 3, ["Rahul Verma", "Sneha Iyer", "Arjun Mehta"]),
    ("Regular", 13, ["Pooja Shah", "Karan Malhotra", "Divya Nair", "Rohan Joshi", "Meera Kapoor", 
                     "Sanjay Rao", "Kavita Deshmukh", "Aditya Kulkarni", "Ritu Agarwal", "Manish Tiwari",
                     "Swati Bansal", "Nikhil Saxena", "Priyanka Jain"]),
    ("VIP", 4, ["Amit Ambani", "Riya Birla", "Vikram Tata", "Ananya Mittal"])
]

customers = []
for ctype, count, names in customer_types:
    level = 1 if ctype == "New" else (2 if ctype == "Regular" else 3)
    for name in names:
        city = random.choice(["Mumbai", "Delhi", "Bangalore", "Pune", "Chennai"])
        customer = Customer.objects.create(
            customer_name=name,
            customer_city=city,
            customer_address=f"{random.randint(1,999)} {random.choice(['MG Road', 'Park Street', 'Main Road'])}, {city}",
            customer_contact=f"+91 {random.randint(70000,99999)} {random.randint(10000,99999)}",
            customer_manager="Sales Team",
            customer_level=level
        )
        customers.append(customer)

print(f"Created {len(customers)} customers (3 New, 13 Regular, 4 VIP)")

# Create Customer Users
for customer in customers:
    username = customer.customer_name.lower().replace(" ", "")
    if not User.objects.filter(username=username).exists():
        User.objects.create_user(
            username=username,
            email=f"{username}@example.com",
            password="customer123",
            first_name=customer.customer_name.split()[0],
            last_name=customer.customer_name.split()[-1]
        )

print(f"Created customer user accounts")

# Create Orders
from django.db.models.signals import post_save
from notifications import triggers
post_save.disconnect(triggers.order_notification, sender=Order)

admin_user = User.objects.get(username='admin')
for i in range(30):
    customer = random.choice(customers)
    order = Order.objects.create(
        order_type='sale',
        customer=customer,
        status=random.choice(['pending', 'confirmed', 'processing', 'shipped', 'delivered']),
        payment_status=random.choice(['unpaid', 'paid']),
        delivery_address=customer.customer_address,
        delivery_phone=customer.customer_contact,
        payment_method=random.choice(['Card', 'UPI', 'COD']),
        created_by=admin_user
    )
    
    # Add 1-4 items per order
    num_items = random.randint(1, 4)
    total = 0
    for _ in range(num_items):
        product = random.choice(products)
        qty = random.randint(1, 3)
        price = product.goods_price
        OrderItem.objects.create(
            order=order,
            product=product,
            product_name=product.goods_desc,
            quantity=qty,
            unit_price=price,
            total_price=qty * price,
            seller=product.goods_supplier
        )
        total += qty * price
    
    order.total_amount = total
    order.grand_total = total + 40
    order.save()

print(f"Created 30 orders with items")

print("\n" + "="*50)
print("DATABASE POPULATION COMPLETE!")
print("="*50)
print(f"Products: {product_count}")
print(f"Suppliers: {len(suppliers)}")
print(f"Warehouses: {len(warehouses)}")
print(f"Customers: {len(customers)}")
print(f"Orders: 30")
print(f"Marketplace Listings: {len(multistock_products)}")
