import os
import django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from billing.models import Invoice, InvoiceItem, Receipt
from django.contrib.auth.models import User
from datetime import datetime, timedelta

# Get or create admin user
user = User.objects.filter(is_superuser=True).first()
if not user:
    user = User.objects.create_superuser('admin', 'admin@multistock.com', 'admin123')

# Create sample invoices
invoices_data = [
    {
        'invoice_type': 'product',
        'customer_name': 'Rajesh Kumar',
        'customer_email': 'rajesh@example.com',
        'customer_phone': '+91 98765 43210',
        'customer_address': 'Mumbai, Maharashtra, India',
        'status': 'paid',
        'items': [
            {'description': 'Laptop Dell Inspiron', 'quantity': 2, 'price': 45000},
            {'description': 'Wireless Mouse', 'quantity': 5, 'price': 500},
        ]
    },
    {
        'invoice_type': 'service',
        'customer_name': 'Priya Sharma',
        'customer_email': 'priya@example.com',
        'customer_phone': '+91 87654 32109',
        'customer_address': 'Delhi, India',
        'status': 'pending',
        'items': [
            {'description': 'Website Development', 'quantity': 1, 'price': 50000},
            {'description': 'SEO Services', 'quantity': 1, 'price': 15000},
        ]
    },
    {
        'invoice_type': 'marketplace',
        'customer_name': 'Amit Patel',
        'customer_email': 'amit@example.com',
        'customer_phone': '+91 76543 21098',
        'customer_address': 'Bangalore, Karnataka, India',
        'status': 'sent',
        'items': [
            {'description': 'Office Chair Premium', 'quantity': 10, 'price': 8500},
            {'description': 'Desk Lamp LED', 'quantity': 15, 'price': 1200},
        ]
    },
]

for inv_data in invoices_data:
    # Create invoice
    invoice = Invoice.objects.create(
        invoice_type=inv_data['invoice_type'],
        customer_name=inv_data['customer_name'],
        customer_email=inv_data['customer_email'],
        customer_phone=inv_data['customer_phone'],
        customer_address=inv_data['customer_address'],
        due_date=datetime.now().date() + timedelta(days=30),
        tax_rate=18,
        discount_amount=0,
        status=inv_data['status'],
        created_by=user
    )
    
    # Add items
    subtotal = 0
    for item_data in inv_data['items']:
        item = InvoiceItem.objects.create(
            invoice=invoice,
            description=item_data['description'],
            quantity=item_data['quantity'],
            price=item_data['price']
        )
        subtotal += item.amount
    
    # Update totals
    invoice.subtotal = subtotal
    invoice.tax_amount = (subtotal * 18) / 100
    invoice.grand_total = subtotal + invoice.tax_amount
    invoice.save()
    
    print(f"Created invoice: {invoice.invoice_number} - Rs.{invoice.grand_total}")
    
    # Create receipt for paid invoices
    if inv_data['status'] == 'paid':
        receipt = Receipt.objects.create(
            invoice=invoice,
            payment_mode='upi',
            amount_paid=invoice.grand_total
        )
        print(f"  + Created receipt: {receipt.receipt_number}")

print(f"\nCreated {len(invoices_data)} sample invoices successfully!")
