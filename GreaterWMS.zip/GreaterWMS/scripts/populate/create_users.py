#!/usr/bin/env python
import os
import sys
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.contrib.auth.models import User, Group

def create_users():
    print("Creating MultiStock user accounts...")
    
    # Create groups if they don't exist
    groups_data = ['SuperAdmin', 'Admin', 'Staff', 'Customer']
    for group_name in groups_data:
        group, created = Group.objects.get_or_create(name=group_name)
        if created:
            print(f"Created group: {group_name}")
    
    # Create users
    users_data = [
        {
            'username': 'superadmin',
            'password': 'admin123',
            'is_staff': True,
            'is_superuser': True,
            'group': 'SuperAdmin',
            'access': 'Everything'
        },
        {
            'username': 'admin',
            'password': 'admin123',
            'is_staff': True,
            'is_superuser': False,
            'group': 'Admin',
            'access': 'Branch management'
        },
        {
            'username': 'staff',
            'password': 'staff123',
            'is_staff': True,
            'is_superuser': False,
            'group': 'Staff',
            'access': 'Basic operations'
        },
        {
            'username': 'customer',
            'password': 'customer123',
            'is_staff': False,
            'is_superuser': False,
            'group': 'Customer',
            'access': 'Marketplace, orders'
        }
    ]
    
    for user_data in users_data:
        # Delete existing user if exists
        User.objects.filter(username=user_data['username']).delete()
        
        # Create new user
        user = User.objects.create_user(
            username=user_data['username'],
            password=user_data['password'],
            is_staff=user_data['is_staff'],
            is_superuser=user_data['is_superuser']
        )
        
        # Add to group
        group = Group.objects.get(name=user_data['group'])
        user.groups.add(group)
        
        print(f"Created user: {user.username} ({user_data['group']}) - {user_data['access']}")
    
    print("\n" + "="*60)
    print("MULTISTOCK USER CREDENTIALS")
    print("="*60)
    
    print("\n1. SuperAdmin Account")
    print("   Username: superadmin")
    print("   Password: admin123")
    print("   Role: SuperAdmin")
    print("   Access: Everything")
    print("   Portal: /auth/team-login/")
    
    print("\n2. Admin Account")
    print("   Username: admin")
    print("   Password: admin123")
    print("   Role: Admin")
    print("   Access: Branch management")
    print("   Portal: /auth/team-login/")
    
    print("\n3. Staff Account")
    print("   Username: staff")
    print("   Password: staff123")
    print("   Role: Staff")
    print("   Access: Basic operations")
    print("   Portal: /auth/team-login/")
    
    print("\n4. Customer Account")
    print("   Username: customer")
    print("   Password: customer123")
    print("   Role: Customer")
    print("   Access: Marketplace, orders")
    print("   Portal: /auth/customer-login/")
    
    print("\n" + "="*60)
    print("ACCESS URLS:")
    print("  Main Platform: http://127.0.0.1:8000/")
    print("  Team Login: http://127.0.0.1:8000/auth/team-login/")
    print("  Customer Login: http://127.0.0.1:8000/auth/customer-login/")
    print("  Admin Panel: http://127.0.0.1:8000/admin/")
    print("="*60)

if __name__ == "__main__":
    create_users()