"""
Sample Data Creation Script for MultiStock Platform
Run: python create_sample_data.py
"""

import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.contrib.auth.models import User
from notifications.models import Notification
from settings.models import SystemSetting

def create_sample_notifications():
    """Create sample notifications for all users"""
    users = User.objects.all()
    
    for user in users:
        # Create sample notifications
        Notification.objects.get_or_create(
            user=user,
            title='Welcome to MultiStock',
            defaults={
                'message': 'Your account is ready. Start exploring the platform!',
                'type': 'success',
                'category': 'system',
                'icon': 'fa-check-circle',
                'link': '/dashboard/'
            }
        )
        
        Notification.objects.get_or_create(
            user=user,
            title='New Order Received',
            defaults={
                'message': 'Order #ORD-001 from John Doe',
                'type': 'info',
                'category': 'order',
                'icon': 'fa-shopping-cart',
                'link': '/orders/'
            }
        )
        
        Notification.objects.get_or_create(
            user=user,
            title='Low Stock Alert',
            defaults={
                'message': 'Product stock below 10 units',
                'type': 'warning',
                'category': 'stock',
                'icon': 'fa-exclamation-triangle',
                'link': '/products/'
            }
        )
    
    print(f"✅ Created sample notifications for {users.count()} users")

def create_default_settings():
    """Create default system settings"""
    defaults = {
        'auto_refresh': 'true',
        'stock_alerts': 'true',
        'audit_logs': 'true',
        'email_notifications': 'true',
        'sms_notifications': 'false',
        'inapp_notifications': 'true',
        'primary_color': '#0014A8',
        'platform_name': 'MultiStock',
        'two_factor_auth': 'false',
        'data_encryption': 'true'
    }
    
    for key, value in defaults.items():
        SystemSetting.set_setting(key, value, f'Default {key} setting')
    
    print(f"✅ Created {len(defaults)} default settings")

if __name__ == '__main__':
    print("🚀 Creating sample data for MultiStock Platform...\n")
    
    try:
        create_sample_notifications()
        create_default_settings()
        print("\n✅ Sample data created successfully!")
        print("\n📝 Next steps:")
        print("1. Run: python manage.py runserver")
        print("2. Visit: http://127.0.0.1:8000")
        print("3. Login and check notifications (bell icon)")
        print("4. Visit settings page to see saved settings")
    except Exception as e:
        print(f"\n❌ Error: {e}")
        print("\n💡 Make sure to run migrations first:")
        print("   python manage.py migrate")
