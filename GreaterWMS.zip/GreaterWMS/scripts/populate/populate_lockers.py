"""
Populate sample data for Smart Locker System
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from lockers.models import LockerType, Locker
from django.contrib.auth import get_user_model

User = get_user_model()

def populate_lockers():
    print("🔐 Populating Smart Locker System...")
    
    # Create Locker Types
    locker_types = [
        {
            'name': 'Small Locker',
            'size': 'small',
            'description': 'Perfect for small packages and documents (12" x 12" x 18")',
            'hourly_rate': 2.00,
            'daily_rate': 10.00,
            'weekly_rate': 50.00,
            'monthly_rate': 150.00,
        },
        {
            'name': 'Medium Locker',
            'size': 'medium',
            'description': 'Ideal for medium-sized packages and equipment (18" x 18" x 24")',
            'hourly_rate': 3.50,
            'daily_rate': 15.00,
            'weekly_rate': 75.00,
            'monthly_rate': 250.00,
        },
        {
            'name': 'Large Locker',
            'size': 'large',
            'description': 'Great for bulky items and multiple packages (24" x 24" x 36")',
            'hourly_rate': 5.00,
            'daily_rate': 20.00,
            'weekly_rate': 100.00,
            'monthly_rate': 350.00,
        },
        {
            'name': 'Extra Large Locker',
            'size': 'xlarge',
            'description': 'For oversized items and bulk storage (36" x 36" x 48")',
            'hourly_rate': 7.50,
            'daily_rate': 30.00,
            'weekly_rate': 150.00,
            'monthly_rate': 500.00,
        },
        {
            'name': 'Climate-Controlled Locker',
            'size': 'climate',
            'description': 'Temperature and humidity controlled for sensitive items (18" x 18" x 24")',
            'hourly_rate': 5.00,
            'daily_rate': 25.00,
            'weekly_rate': 125.00,
            'monthly_rate': 400.00,
            'has_climate_control': True,
        },
    ]
    
    created_types = []
    for type_data in locker_types:
        locker_type, created = LockerType.objects.get_or_create(
            name=type_data['name'],
            defaults=type_data
        )
        if created:
            print(f"✅ Created locker type: {locker_type.name}")
        else:
            print(f"⚠️ Locker type already exists: {locker_type.name}")
        created_types.append(locker_type)
    
    # Create Lockers
    locker_locations = [
        'Warehouse A - Floor 1',
        'Warehouse A - Floor 2',
        'Warehouse B - Ground Floor',
        'Distribution Center - Loading Dock',
        'Main Office Building',
    ]
    
    locker_count = 0
    for location in locker_locations:
        for idx, locker_type in enumerate(created_types):
            # Create 3-5 lockers of each type per location
            num_lockers = 3 if locker_type.size in ['extra_large', 'large'] else 5
            
            for i in range(1, num_lockers + 1):
                locker_number = f"{location[:3].upper()}-{locker_type.size[:2].upper()}-{idx+1:02d}{i:02d}"
                
                locker, created = Locker.objects.get_or_create(
                    locker_number=locker_number,
                    defaults={
                        'locker_type': locker_type,
                        'location': location,
                        'status': 'available',
                    }
                )
                
                if created:
                    locker_count += 1
                    # Generate access code for some lockers
                    if i % 2 == 0:
                        locker.generate_access_code()
    
    print(f"✅ Created {locker_count} new lockers across {len(locker_locations)} locations")
    
    # Summary
    total_lockers = Locker.objects.count()
    available = Locker.objects.filter(status='available').count()
    occupied = Locker.objects.filter(status='occupied').count()
    maintenance = Locker.objects.filter(status='maintenance').count()
    
    print("\n📊 Locker System Summary:")
    print(f"   Total Lockers: {total_lockers}")
    print(f"   Available: {available}")
    print(f"   Occupied: {occupied}")
    print(f"   Under Maintenance: {maintenance}")
    print(f"   Locker Types: {LockerType.objects.count()}")
    
    print("\n✅ Smart Locker System populated successfully!")
    print("📍 Access the system at: http://127.0.0.1:8000/lockers/")

if __name__ == '__main__':
    populate_lockers()
