import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from rentals.models import RentalCategory, RentalItem

print("Populating Rental Categories...")
categories_data = [
    {'name': 'Construction Equipment', 'category_type': 'equipment', 'description': 'Heavy machinery and construction tools'},
    {'name': 'Vehicles', 'category_type': 'vehicle', 'description': 'Cars, trucks, and vans for rent'},
    {'name': 'Event Equipment', 'category_type': 'event', 'description': 'Tables, chairs, and event supplies'},
]

for cat_data in categories_data:
    RentalCategory.objects.get_or_create(name=cat_data['name'], defaults=cat_data)
print(f"Created {len(categories_data)} categories")

print("\nPopulating Rental Items...")
categories = {cat.name: cat for cat in RentalCategory.objects.all()}

items_data = [
    {'category': categories['Construction Equipment'], 'name': 'Excavator', 'description': 'Heavy-duty excavator', 'hourly_rate': 50, 'daily_rate': 300, 'weekly_rate': 1800, 'monthly_rate': 6000},
    {'category': categories['Construction Equipment'], 'name': 'Forklift', 'description': '5-ton capacity forklift', 'hourly_rate': 30, 'daily_rate': 200, 'weekly_rate': 1200, 'monthly_rate': 4000},
    {'category': categories['Vehicles'], 'name': 'Cargo Van', 'description': 'Large cargo van', 'hourly_rate': 15, 'daily_rate': 80, 'weekly_rate': 500, 'monthly_rate': 1800},
    {'category': categories['Vehicles'], 'name': 'Pickup Truck', 'description': 'Heavy-duty pickup', 'hourly_rate': 20, 'daily_rate': 100, 'weekly_rate': 600, 'monthly_rate': 2200},
    {'category': categories['Event Equipment'], 'name': 'Tables & Chairs Set', 'description': '10 tables + 50 chairs', 'hourly_rate': 0, 'daily_rate': 150, 'weekly_rate': 800, 'monthly_rate': 2500},
    {'category': categories['Event Equipment'], 'name': 'Sound System', 'description': 'Professional PA system', 'hourly_rate': 25, 'daily_rate': 180, 'weekly_rate': 1000, 'monthly_rate': 3500},
]

for item_data in items_data:
    RentalItem.objects.get_or_create(name=item_data['name'], defaults=item_data)
print(f"Created {len(items_data)} rental items")

print("\nRentals data populated successfully!")
