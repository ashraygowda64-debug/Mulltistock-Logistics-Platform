import sqlite3
import os

# Connect to the database
db_path = os.path.join(os.path.dirname(__file__), 'db.sqlite3')
conn = sqlite3.connect(db_path)
cursor = conn.cursor()

try:
    # Check current columns
    cursor.execute("PRAGMA table_info(stocklist)")
    columns = [column[1] for column in cursor.fetchall()]
    
    print("Current columns in stocklist table:", columns)
    print()
    
    # Add missing columns
    columns_to_add = [
        ('goods_image', 'VARCHAR(100)', 'NULL'),
        ('openid', 'VARCHAR(255)', "DEFAULT ''"),
    ]
    
    for col_name, col_type, col_default in columns_to_add:
        if col_name not in columns:
            print(f"Adding {col_name} column to stocklist table...")
            cursor.execute(f"ALTER TABLE stocklist ADD COLUMN {col_name} {col_type} {col_default}")
            conn.commit()
            print(f"✓ {col_name} column added successfully!")
        else:
            print(f"✓ {col_name} column already exists")
    
except Exception as e:
    print(f"Error: {e}")
    conn.rollback()
finally:
    conn.close()

print("\nDone! You can now access the inventory page.")
