#!/usr/bin/env python
"""
Fix the messaging_message table to remove group_id NOT NULL constraint
and add MessageReaction table if missing
"""
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.db import connection

print("=== Fixing Message Table Schema ===")

with connection.cursor() as cursor:
    # First, check if messaging_messagereaction table exists
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messaging_messagereaction'")
    if not cursor.fetchone():
        print("Creating messaging_messagereaction table...")
        cursor.execute("""
            CREATE TABLE "messaging_messagereaction" (
                "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                "emoji" varchar(10) NOT NULL,
                "created_at" datetime NOT NULL,
                "message_id" bigint NOT NULL REFERENCES "messaging_message" ("id") DEFERRABLE INITIALLY DEFERRED,
                "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED,
                UNIQUE("message_id", "user_id")
            )
        """)
        print("✓ Created messaging_messagereaction table")
    
    # Get current table structure
    cursor.execute("PRAGMA table_info(messaging_message);")
    columns = cursor.fetchall()
    print(f"\nCurrent columns: {len(columns)}")
    
    # Create a new table with the correct structure
    print("\nCreating new message table structure...")
    cursor.execute("""
        CREATE TABLE "messaging_message_new" (
            "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
            "content" text NOT NULL,
            "timestamp" datetime NOT NULL,
            "sender_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED,
            "conversation_id" bigint NOT NULL REFERENCES "messaging_conversation" ("id") DEFERRABLE INITIALLY DEFERRED,
            "attachment" varchar(100),
            "attachment_type" varchar(20),
            "is_edited" bool NOT NULL DEFAULT 0,
            "is_pinned" bool NOT NULL DEFAULT 0,
            "reply_to_id" bigint REFERENCES "messaging_message" ("id") DEFERRABLE INITIALLY DEFERRED,
            "forwarded_from_id" bigint REFERENCES "messaging_message" ("id") DEFERRABLE INITIALLY DEFERRED,
            "edited_at" datetime
        )
    """)
    print("✓ Created new table structure")
    
    # Copy data from old table to new table (if any exists)
    print("\nCopying existing data...")
    cursor.execute("""
        INSERT INTO messaging_message_new 
        (id, content, timestamp, sender_id, conversation_id, attachment, attachment_type, is_edited, is_pinned, reply_to_id, forwarded_from_id, edited_at)
        SELECT id, content, timestamp, sender_id, conversation_id, attachment, attachment_type, is_edited, is_pinned, reply_to_id, forwarded_from_id, edited_at
        FROM messaging_message
    """)
    rows_copied = cursor.rowcount
    print(f"✓ Copied {rows_copied} rows")
    
    # Drop old table
    print("\nDropping old table...")
    cursor.execute("DROP TABLE messaging_message")
    print("✓ Dropped old table")
    
    # Rename new table
    print("\nRenaming new table...")
    cursor.execute("ALTER TABLE messaging_message_new RENAME TO messaging_message")
    print("✓ Renamed table")
    
    # Recreate indices
    print("\nCreating indices...")
    cursor.execute("""
        CREATE INDEX "messaging_message_sender_id_idx" 
        ON "messaging_message" ("sender_id")
    """)
    cursor.execute("""
        CREATE INDEX "messaging_message_conversation_id_idx" 
        ON "messaging_message" ("conversation_id")
    """)
    cursor.execute("""
        CREATE INDEX "messaging_message_reply_to_id_idx" 
        ON "messaging_message" ("reply_to_id")
    """)
    print("✓ Created indices")
    
    # Recreate many-to-many tables if needed
    print("\nChecking many-to-many tables...")
    
    # read_by
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messaging_message_read_by'")
    if not cursor.fetchone():
        cursor.execute("""
            CREATE TABLE "messaging_message_read_by" (
                "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                "message_id" bigint NOT NULL REFERENCES "messaging_message" ("id") DEFERRABLE INITIALLY DEFERRED,
                "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED,
                UNIQUE("message_id", "user_id")
            )
        """)
        print("✓ Created messaging_message_read_by")
    
    # deleted_for
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messaging_message_deleted_for'")
    if not cursor.fetchone():
        cursor.execute("""
            CREATE TABLE "messaging_message_deleted_for" (
                "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                "message_id" bigint NOT NULL REFERENCES "messaging_message" ("id") DEFERRABLE INITIALLY DEFERRED,
                "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED,
                UNIQUE("message_id", "user_id")
            )
        """)
        print("✓ Created messaging_message_deleted_for")
    
    # is_starred_by
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='messaging_message_is_starred_by'")
    if not cursor.fetchone():
        cursor.execute("""
            CREATE TABLE "messaging_message_is_starred_by" (
                "id" integer NOT NULL PRIMARY KEY AUTOINCREMENT,
                "message_id" bigint NOT NULL REFERENCES "messaging_message" ("id") DEFERRABLE INITIALLY DEFERRED,
                "user_id" integer NOT NULL REFERENCES "auth_user" ("id") DEFERRABLE INITIALLY DEFERRED,
                UNIQUE("message_id", "user_id")
            )
        """)
        print("✓ Created messaging_message_is_starred_by")

print("\n=== Schema Fix Complete ===")
print("The messaging_message table now matches the current models.")
print("group_id constraint removed, conversation_id is now the main foreign key.")
