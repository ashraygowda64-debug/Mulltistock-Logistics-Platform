@echo off
echo Fixing orders table...
python manage.py makemigrations orders
python manage.py migrate orders
echo Done!
pause
