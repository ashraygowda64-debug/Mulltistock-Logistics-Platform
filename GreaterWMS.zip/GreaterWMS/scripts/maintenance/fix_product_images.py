#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from stock.models import StockListModel
from goods.models import ListModel
import random

print('=== FIXING PRODUCT IMAGES ===')

# Get all stock items that have images
stock_items = StockListModel.objects.filter(goods_image__isnull=False).exclude(goods_image='')
print(f'Found {stock_items.count()} stock items with images')

# Get all products without proper stock images
products = ListModel.objects.filter(is_delete=False)
print(f'Found {products.count()} active products')

fixed_count = 0
missing_images = []

for product in products:
    # Find corresponding stock item
    stock = StockListModel.objects.filter(goods_code=product.goods_code).first()
    
    if stock:
        if not stock.goods_image:
            # Assign a random image from available stock images
            random_stock = random.choice(stock_items)
            stock.goods_image = random_stock.goods_image
            stock.save()
            print(f'✓ Fixed image for {product.goods_code} - {product.goods_desc[:30]}')
            fixed_count += 1
        else:
            print(f'  Already has image: {product.goods_code}')
    else:
        # Create stock entry with random image
        random_stock = random.choice(stock_items)
        StockListModel.objects.create(
            goods_code=product.goods_code,
            goods_desc=product.goods_desc,
            goods_qty=random.randint(10, 100),
            onhand_stock=random.randint(10, 100),
            can_order_stock=random.randint(10, 100),
            supplier=product.goods_supplier or 'Default Supplier',
            goods_image=random_stock.goods_image
        )
        print(f'✓ Created stock with image for {product.goods_code}')
        fixed_count += 1

print(f'\n=== SUMMARY ===')
print(f'Fixed images for {fixed_count} products')
print(f'Total products: {products.count()}')

# Verify results
print('\n=== VERIFICATION ===')
stock_with_images = StockListModel.objects.filter(goods_image__isnull=False).exclude(goods_image='').count()
print(f'Stock items with images: {stock_with_images}')

print('\nSample products with images:')
for stock in StockListModel.objects.filter(goods_image__isnull=False).exclude(goods_image='')[:10]:
    print(f'  - {stock.goods_code}: {stock.goods_image}')