@echo off
echo ========================================
echo MULTISTOCK - CLEANUP DUPLICATE FILES
echo ========================================
echo.
echo This will delete redundant template files
echo Press Ctrl+C to cancel, or
pause

echo.
echo Deleting duplicate dashboards...
del templates\dashboard.html
del templates\customer_dashboard.html
del templates\staff_dashboard.html
del templates\superadmin_dashboard.html
del templates\dashboard_superadmin.html
del templates\unified_dashboard.html

echo Deleting duplicate POS templates...
del templates\pos\interface.html
del templates\pos\enhanced_pos.html
del templates\pos\sales.html

echo Deleting duplicate order templates...
del templates\orders\sales_orders.html
del templates\orders\enterprise_orders.html

echo Deleting duplicate product templates...
del templates\products\grid_products.html
del templates\products\analytics.html

echo Deleting duplicate expense templates...
del templates\expenses\list.html
del templates\expenses\create.html

echo Deleting duplicate report templates...
del templates\reports\create.html
del templates\reports\export.html

echo Deleting duplicate warehouse templates...
del templates\warehouse\visual_warehouse.html

echo Deleting duplicate customer templates...
del templates\customers\advanced_customers.html

echo Deleting duplicate supplier templates...
del templates\suppliers\complete_suppliers.html

echo.
echo Cleanup complete!
echo Saved approximately 150KB
pause
