import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from django.core.management import call_command

print("Running migrations...")
try:
    call_command('makemigrations', 'orders', interactive=False)
    call_command('migrate', 'orders', interactive=False)
    print("✅ Orders migrations completed")
except Exception as e:
    print(f"❌ Error: {e}")

print("\nDone!")
