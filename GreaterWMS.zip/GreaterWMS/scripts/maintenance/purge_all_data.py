import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from goods.models import ListModel as Product
from stock.models import StockListModel, StockMovement, StockAlert
from orders.models import Order, OrderItem, OrderStatusHistory
from customer.models import ListModel as Customer
from supplier.models import ListModel as Supplier
from warehouse.models import ListModel as Warehouse
from multistock.models import Listing, Auction, Bid
from billing.models import Invoice, InvoiceItem, Receipt
from expenses.models import Expense
from credit.models import CreditProfile, CreditTransaction
from coupons.models import Coupon, CouponUsage
from pos.models import POSSale, POSSaleItem
from rentals.models import RentalItem, RentalBooking, MaintenanceSchedule
from storage.models import StorageUnit, StorageBooking

print("PURGING ALL DATA FROM DATABASE...")
print("=" * 50)

try:
    print("Deleting Products...", end=" ")
    count = Product.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Stocks...", end=" ")
    count = StockListModel.objects.all().delete()[0]
    StockMovement.objects.all().delete()
    StockAlert.objects.all().delete()
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Orders...", end=" ")
    OrderItem.objects.all().delete()
    OrderStatusHistory.objects.all().delete()
    count = Order.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Customers...", end=" ")
    count = Customer.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Suppliers...", end=" ")
    count = Supplier.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Warehouses...", end=" ")
    count = Warehouse.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Marketplace Listings...", end=" ")
    count = Listing.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Auctions...", end=" ")
    Bid.objects.all().delete()
    count = Auction.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Invoices...", end=" ")
    InvoiceItem.objects.all().delete()
    Receipt.objects.all().delete()
    count = Invoice.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Expenses...", end=" ")
    count = Expense.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Credit Entries...", end=" ")
    CreditTransaction.objects.all().delete()
    count = CreditProfile.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Coupons...", end=" ")
    CouponUsage.objects.all().delete()
    count = Coupon.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting POS Sales...", end=" ")
    POSSaleItem.objects.all().delete()
    count = POSSale.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Rental Items...", end=" ")
    RentalBooking.objects.all().delete()
    MaintenanceSchedule.objects.all().delete()
    count = RentalItem.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

try:
    print("Deleting Storage Units...", end=" ")
    StorageBooking.objects.all().delete()
    count = StorageUnit.objects.all().delete()[0]
    print(f"OK - {count} deleted")
except Exception as e:
    print(f"SKIP - {e}")

print("=" * 50)
print("PURGE COMPLETE - ALL DATA REMOVED FROM DATABASE")
