#!/usr/bin/env python
import os
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'greaterwms.settings')
django.setup()

from stock.models import StockListModel
from goods.models import ListModel
import random

print('=== FIXING MISSING PRODUCT IMAGES ===')

# Get available images
available_images = list(StockListModel.objects.filter(
    goods_image__isnull=False
).exclude(goods_image='').values_list('goods_image', flat=True))

print(f'Available images: {len(available_images)}')

# Get products without images
products = ListModel.objects.filter(is_delete=False)
fixed_count = 0

for product in products:
    stock = StockListModel.objects.filter(goods_code=product.goods_code).first()
    
    if not stock:
        # Create stock entry with random image
        random_image = random.choice(available_images)
        StockListModel.objects.create(
            goods_code=product.goods_code,
            goods_desc=product.goods_desc,
            goods_qty=random.randint(10, 100),
            onhand_stock=random.randint(10, 100),
            can_order_stock=random.randint(10, 100),
            supplier=product.goods_supplier or 'Default Supplier',
            goods_image=random_image
        )
        print(f'Created stock for {product.goods_code}')
        fixed_count += 1
    elif not stock.goods_image:
        # Add image to existing stock
        random_image = random.choice(available_images)
        stock.goods_image = random_image
        stock.save()
        print(f'Added image to {product.goods_code}')
        fixed_count += 1

print(f'\nFixed {fixed_count} products')

# Verify
total_with_images = StockListModel.objects.filter(
    goods_image__isnull=False
).exclude(goods_image='').count()
print(f'Total products with images: {total_with_images}')