@echo off
echo Fixing database schema...
python manage.py makemigrations orders
python manage.py migrate orders
echo Done!
pause
