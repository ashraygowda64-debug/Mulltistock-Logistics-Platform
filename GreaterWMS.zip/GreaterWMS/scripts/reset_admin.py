import os, sys
import django
BASE_DIR = os.path.dirname(os.path.dirname(__file__))
sys.path.append(BASE_DIR)
os.environ.setdefault('DJANGO_SETTINGS_MODULE','greaterwms.settings')
django.setup()
from django.contrib.auth.models import User

username = 'admin'
password = 'admin123'
email = 'admin@example.com'

u, created = User.objects.get_or_create(username=username, defaults={'email': email, 'is_superuser': True, 'is_staff': True})
u.is_superuser = True
u.is_staff = True
u.email = email
u.set_password(password)
u.save()
print(f"Admin user '{username}' ready. Created={created}. Password reset to '{password}'.")
