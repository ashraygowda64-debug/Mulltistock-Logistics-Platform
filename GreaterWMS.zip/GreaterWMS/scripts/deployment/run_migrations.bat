@echo off
echo Creating migrations for new modules...
python manage.py makemigrations webhooks
python manage.py makemigrations support
echo.
echo Running migrations...
python manage.py migrate
echo.
echo Done! Press any key to exit.
pause
