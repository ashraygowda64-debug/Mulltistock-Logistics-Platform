@echo off
echo Installing psutil for system monitoring...
pip install psutil==5.9.6
echo Done!
pause
