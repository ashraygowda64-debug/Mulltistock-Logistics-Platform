@echo off
echo Starting MultiStock Production Deployment...

echo Step 1: Installing dependencies...
pip install -r requirements-production.txt

echo Step 2: Collecting static files...
python manage.py collectstatic --noinput

echo Step 3: Running migrations...
python manage.py migrate

echo Step 4: Creating superuser (if needed)...
python manage.py shell -c "from django.contrib.auth import get_user_model; User = get_user_model(); User.objects.filter(username='admin').exists() or User.objects.create_superuser('admin', 'admin@multistock.com', 'admin123')"

echo Step 5: Starting backup...
python backup/backup_script.py

echo Step 6: Starting production server...
echo Production deployment complete!
echo Access the application at: http://localhost:8000
echo Admin panel: http://localhost:8000/admin/
echo API Documentation: http://localhost:8000/mobile/api-docs/

pause