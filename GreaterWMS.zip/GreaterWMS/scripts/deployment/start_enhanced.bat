@echo off
echo ========================================
echo    MultiStock Enterprise Platform
echo ========================================
echo.

echo Starting enhanced MultiStock platform...
echo.

echo [1/3] Running migrations...
python manage.py makemigrations
python manage.py migrate

echo.
echo [2/3] Setting up sample data...
python setup_data.py

echo.
echo [3/3] Starting development server...
echo.
echo ========================================
echo    Platform Ready!
echo ========================================
echo.
echo Access URLs:
echo   Main Dashboard: http://127.0.0.1:8000/
echo   Admin Panel:    http://127.0.0.1:8000/admin/
echo   Marketplace:    http://127.0.0.1:8000/multistock/marketplace/
echo   Orders:         http://127.0.0.1:8000/orders/sales/
echo   Inventory:      http://127.0.0.1:8000/inventory/
echo.
echo Login Credentials:
echo   SuperAdmin: admin / admin123
echo   Admin:      admin_user / admin123
echo   Staff:      staff_user / staff123
echo   Customer:   customer_user / customer123
echo.
echo ========================================

python manage.py runserver