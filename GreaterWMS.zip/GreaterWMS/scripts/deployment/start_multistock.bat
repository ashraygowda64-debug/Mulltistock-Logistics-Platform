@echo off
echo ========================================
echo    MultiStock Platform Startup
echo ========================================
echo.
echo Starting MultiStock Enterprise Inventory Management Platform...
echo.
echo Login Credentials:
echo Username: admin@example.com
echo Password: 123456
echo.
echo Platform will be available at: http://127.0.0.1:8000
echo.
echo Press Ctrl+C to stop the server
echo ========================================
echo.

cd /d "c:\Users\ASHISH\Downloads\GreaterWMS"
python manage.py runserver
pause