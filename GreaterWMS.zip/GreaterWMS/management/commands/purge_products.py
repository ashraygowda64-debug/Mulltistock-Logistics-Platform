from django.core.management.base import BaseCommand
from apps.goods.models import ListModel as Product
from apps.stock.models import StockListModel
from django.db import transaction

class Command(BaseCommand):
    help = 'Purge 181 products from database'

    def handle(self, *args, **options):
        self.stdout.write("🔍 Starting purge...")
        
        with transaction.atomic():
            total = Product.objects.filter(is_delete=False).count()
            self.stdout.write(f"Total products: {total}")
            
            if total <= 100:
                self.stdout.write(self.style.SUCCESS("✅ Already 100 or fewer products"))
                return
            
            to_delete = Product.objects.filter(is_delete=False).order_by('id')[100:]
            count = 0
            
            for product in to_delete:
                StockListModel.objects.filter(goods_code=product.goods_code).delete()
                product.is_delete = True
                product.save()
                count += 1
            
            remaining = Product.objects.filter(is_delete=False).count()
            self.stdout.write(self.style.SUCCESS(f"✅ Deleted {count} products"))
            self.stdout.write(self.style.SUCCESS(f"📊 Remaining: {remaining}"))
